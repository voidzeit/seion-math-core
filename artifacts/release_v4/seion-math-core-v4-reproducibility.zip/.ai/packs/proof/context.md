# Deterministic SEION context pack

Task: SEION v4 proof context
Category: proof
Estimated tokens: 17856/18000

## claims/claim_evidence_matrix_v2.csv

claim_id,status,claim_text,theorem_or_proposition_evidence,experiment_evidence,counterexample_evidence,run_index,figures_or_tables,release_impact
CLM_V2_001,ESTABLISHED_KNOWN_RESULT,"Exact invariant reduction commutes with every declared full ordered tree composition.",THM_EXACT_TYPED_REDUCTION_V2,exact symbolic artifact and parity tests,,artifacts/symbolic_v2/exact_invariant_reduction.json,fig03_exact_reduction_diagram.pdf,No novelty claim; theorem is auditable and reusable.
CLM_V2_002,ESTABLISHED_KNOWN_RESULT,"Multilinear polynomial identities built from the declared operation descend under exact invariance.",THM_OPERADIC_IDENTITY_INHERITANCE_V2,tests/research_v2/test_theorem_examples.py,,artifacts/symbolic_v2/exact_invariant_reduction.json,fig02_ternary_composition_trees.pdf,No novelty claim; convention-dependent scope is explicit.
CLM_V2_003,PROVED_AUXILIARY,"For a tree with k internal nodes, projected evaluation error is at most k rho M^(k-1) times the product of leaf norms.",THM_APPROXIMATE_TREE_BOUND_V2,60 registered runs with five seeds per tree/epsilon group,,artifacts/index/bound_tightness_v2.csv,fig08_closure_convergence.pdf;tables/bound_tightness.tex,Auxiliary certificate; not submission-grade novelty by itself.
CLM_V2_004,ESTABLISHED_KNOWN_RESULT,"Hermitian threshold snapping is stable under a positive gap with a conservative min(1,4||E||/gamma) bound.",THM_SPECTRAL_SNAPPING_GAP_V2,60 positive-gap runs with five seeds per control cell,CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,artifacts/index/spectral_gap_v2.csv,fig07_spectral_gap_stability.pdf;tables/spectral_gap.tex,Standard perturbation consequence; no novelty claim.
CLM_V2_005,VERIFIED_COUNTEREXAMPLE,"Without exact invariance, reduction need not commute with partial composition.",,test_no_invariance_counterexample_breaks_composition,CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2,artifacts/counterexamples_v2/no_invariance_composition.json,fig04_closure_leakage_geometry.pdf,Supports the stated hypothesis boundary.
CLM_V2_006,VERIFIED_COUNTEREXAMPLE,"Without a positive spectral gap, snapping can change by O(1) under perturbations tending to zero.",,test_no_gap_counterexample_has_small_perturbation_but_large_snap_change,CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,artifacts/counterexamples_v2/spectral_gap_sweep.json,fig07_spectral_gap_stability.pdf,Supports fail-closed gap requirement.
CLM_V2_007,VERIFIED_IMPLEMENTATION,"Reference coordinate-loop evaluation, NumPy accelerated evaluation, dense composition, and CP rank-one evaluation agree to floating-point tolerance.",,13 research_v2 tests plus CP parity and five CPU/GPU parity runs,,,tests/research_v2/t

## claims/claim_evidence_matrix_v3.csv

claim_id,status,claim_text,theorem_or_proposition_evidence,implementation_evidence,numerical_or_exact_evidence,limitation,release_impact
CLM_V3_001,PROVED_UNDER_ASSUMPTIONS,"The four named root errors obey Pythagorean and reduced/projected identities.",THM_V3_ROOT_ERROR_ORTHOGONALITY,src/seion_core/research_v3/projected_evaluation.py,tests/research_v3/unit/test_evaluation.py,"Finite Hilbert spaces and orthogonal projectors only.",Supports exact semantics
CLM_V3_002,PROVED,"Every node error has an exact nonempty-subset expansion plus its local normal residual.",THM_V3_EXACT_SUBSET_EXPANSION,src/seion_core/research_v3/error_expansion.py,tests/research_v3/symbolic/test_error_expansion.py,"Identity is algebraic and not a sharpness theorem.",Supports all certificates
CLM_V3_003,PROVED_UNDER_ASSUMPTIONS,"Ambient error has universal coefficient k.",THM_V3_HOMOGENEOUS_AMBIENT_K,src/seion_core/research_v3/certificates.py,tests/research_v3/certificates/test_certificates.py,"Fixed-eta optimality remains open.",Upper-bound theorem only
CLM_V3_004,PROVED_UNDER_ASSUMPTIONS,"Projected-root and reduced error have universal coefficient k-1.",THM_V3_PROJECTED_ROOT_K_MINUS_ONE,src/seion_core/research_v3/certificates.py,tests/research_v3/regression/test_projected_k_minus_one.py,"Novelty and fixed-eta sharpness are not established.",Central v3 result pending human review
CLM_V3_005,PROVED_UNDER_ASSUMPTIONS,"A sign-partitioned ratio sort minimizes the declared telescoping certificate.",THM_V3_OPTIMAL_TELESCOPING_ORDER,src/seion_core/research_v3/telescoping_order.py,tests/research_v3/property/test_telescoping_order.py,"Optimizes this scalar upper bound, not fixed-law error.",Algorithmic certificate
CLM_V3_006,PROVED_UNDER_ASSUMPTIONS,"Nodewise mixed-mask and path-sum certificates are computable for typed heterogeneous trees.",THM_V3_NODEWISE_MIXED_CERTIFICATE;THM_V3_NODEWISE_PATH_SUM,src/seion_core/research_v3/certificates.py,tests/research_v3/certificates/test_certificates.py,"Information-optimality is open.",Candidate contribution; novelty fail-closed
CLM_V3_007,CERTIFIED_LOWER_BOUND,"Planar gated rotations provide explicit admissible lower constructions.",,src/seion_core/research_v3/extremizers.py,src/seion_core/research_v3/interval_certification.py,"They do not match every fixed-eta upper bound.",Sharpness evidence only
CLM_V3_008,EMPIRICAL_LOWER_BOUND,"Gradient and derivative-free searches provide empirical lower bounds.",,src/seion_core/research_v3/adversarial_search.py,tests/research_v3/adversarial/test_searches.py,"No global optimality follows from optimizer output.",Numerical diagnostic
CLM_V3_009,PROVED_UNDER_ASSUMPTIONS,"The proje

## claims/claims_registry.yaml

claims:
  - id: DEF_NARY_LAW_V1
    title: Typed finite-dimensional n-ary law
    status: definition
    statement: "A structural tensor K of shape (d_out,d_1,...,d_n) defines an n-linear map with explicit input and output dimensions."
    assumptions: [finite-dimensional coordinate spaces, numeric field]
    evidence: [src/seion_core/algebra/nary_law.py, tests/unit/test_nary_law.py]
  - id: DEF_ASSOCIATOR_CONVENTIONS_V1
    title: Distinct ternary composition conventions
    status: definition
    statement: "The five-input, anchored binary, and operadic partial-composition objects are represented by separate functions and recorded conventions."
    assumptions: [ternary arity for specialized formulas]
    evidence: [src/seion_core/algebra/ternary_law.py, tests/unit/test_associators.py]
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    title: Standard left-action curvature expansion
    status: proved
    statement: "For any bilinear product, [L_x,L_y]-L_[x,y] applied to z equals A(y,x,z)-A(x,y,z), with [x,y]=x circ y-y circ x."
    assumptions: [finite-dimensional bilinear product, stated commutator convention]
    proof: docs/theorems/curvature_associator.md
    symbolic_checks: [artifacts/symbolic/curvature_identity.json]
    counterexamples: [docs/counterexamples/curvature_without_symmetry.md]
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    title: Commuting finite operator descends to cohomology
    status: proved_under_assumptions
    statement: "If a finite operator commutes with the differential, it preserves cycles and boundaries and therefore induces a map on the quotient cohomology space."
    assumptions: [d squared equals zero, same-degree linear operator, exact commutation]
    proof: docs/theorems/cohomology_descent.md
    numerical_checks: [tests/unit/test_cohomology.py]
  - id: NUM_KNOWN_INVARIANT_CLOSURE_V1
    title: Known block subspace closure
    status: numerically_verified
    statement: "For the declared block-supported example, the coordinate projector has zero closure leakage up to floating-point evaluation."
    assumptions: [example definition, finite samples, float64]
    evidence: [experiments/configs/finite_ternary_v1.yaml]
  - id: EMP_PROJECTOR_RECOVERY_V1
    title: Empirical closure-minimizing recovery
    status: empirical
    statement: "A small stochastic Stiefel search can reduce sampled closure leakage on some declared examples; no general recovery or superiority claim is made."
    assumptions: [seed, sample distribution, optimizer steps]
    evidence: [src/seion_core/variational/optimizers.py]
  - id: CONJ_CONTINUUM_LIMIT_V1
    title: Uniform continuum limit for kernel-

## claims/conjecture_registry.yaml

conjectures:
  - id: CONJ_CLOSURE_RECOVERY
    statement: "Under identifiable spectral separation and adequate sampling, closure-minimizing projectors may recover invariant subspaces more reliably than generic baselines."
    status: CONJECTURE
    blockers: [identifiability, optimizer global behavior, sample complexity]
  - id: CONJ_MULTISCALE_PERSISTENCE
    statement: "Gauge-aligned finite tensor features may persist across a suitable resolution sequence."
    status: CONJECTURE
    blockers: [choice of maps, topology, uniform estimates]



## claims/counterexample_registry.yaml

counterexamples:
  - id: CE_SNAPPING_NO_GAP
    claim: REFUTED_SNAPPING_NO_GAP_V1
    construction: "Diagonal matrices with eigenvalues on opposite sides of 1/2 and arbitrarily small perturbation."
    status: REFUTED
  - id: CE_CURVATURE_NOT_RAW_ASSOCIATOR
    claim: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    construction: "A product with A(y,x,z) nonzero shows standard curvature is a difference of associators, not one raw associator."
    status: REFUTED



## claims/counterexample_registry_v2.yaml

version: 2
scope: "Exact assumption-removal counterexamples for the v2 theorem ledger."
counterexamples:
  - id: CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2
    target: THM_EXACT_TYPED_REDUCTION_V2
    removed_assumption: exact invariance of the selected subspace
    construction: "On R^2 with W=span(e0), mu(e0,e0)=e1 and mu(e1,e0)=e0; the reduced binary law is zero but the ambient partial composition at (e0,e0,e0) equals e0."
    exact_artifact: artifacts/counterexamples_v2/no_invariance_composition.json
    test: tests/research_v2/test_theorem_examples.py
    status: REFUTED_WITHOUT_HYPOTHESIS
  - id: CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2
    target: THM_SPECTRAL_SNAPPING_GAP_V2
    removed_assumption: positive uniform spectral gap around the threshold
    construction: "A_delta=diag(1/2-delta,1/2+delta) and E_delta=diag(2delta,-2delta) swap the snapped coordinate projectors while ||E_delta|| tends to zero."
    exact_artifact: artifacts/counterexamples_v2/spectral_gap_sweep.json
    test: tests/research_v2/test_theorem_examples.py
    status: REFUTED_WITHOUT_HYPOTHESIS
  - id: CE_LEGACY_DUPLICATE_RUNS_NOT_INDEPENDENT_V2
    target: experimental_aggregation
    removed_assumption: independent scientific instances
    construction: "Historical run records share identical experiment/config/seed/precision/backend/device identities and must not be counted as independent observations."
    exact_artifact: artifacts/research_audit/run_deduplication_report.csv
    status: GOVERNANCE_COUNTEREXAMPLE


## claims/novelty_registry.yaml

novelty:
  - area: non-associative algebra
    known_component: associators and non-associative identities
    new_component: none claimed in the definitions
    new_combination: typed computational evidence ledger linking a declared law to reductions
    evidence: docs/prior_art_matrix.md
    references: [Filippov1985, Sabinin1999, MostovoyPerezIzquierdoShestakov2014]
    theorem_level_novelty: none currently claimed
    computational_novelty: convention-aware finite residual evaluation
    limitations: "The repository does not claim a new algebraic identity by renaming these objects."
  - area: operads and polynomial identities
    known_component: algebras over operads and partial compositions
    new_component: explicit finite ternary insertion conventions
    new_combination: composition metadata linked to theorem/evidence records
    evidence: docs/prior_art_matrix.md
    references: [LodayVallette2012]
    theorem_level_novelty: proposed invariant-reduction functoriality, not yet proved
    computational_novelty: typed insertion checks
    limitations: "No novelty is claimed for operadic composition itself."
  - area: structure-preserving model reduction
    known_component: invariant subspaces, PCA, SVD, spectral projectors
    new_component: finite closure-leakage certificate with convention metadata
    new_combination: common artifact contract for algebraic and reduction diagnostics
    evidence: src/seion_core/projectors
    references: [BennerGugercinWillcox2015, ChaturantabutBeattieGugercin2016]
    theorem_level_novelty: explicit approximate-closure bound remains open
    computational_novelty: traceable closure-leakage comparison
    limitations: "Empirical optimizer results are not a superiority theorem."
  - area: tensor decomposition and identifiability
    known_component: CP/Tucker/HOSVD representations and gauge non-uniqueness
    new_component: law-level parity and gauge-alignment evidence
    new_combination: factorization, associator, and reduction provenance
    evidence: src/seion_core/algebra/cp_law.py
    references: [KoldaBader2009, BaderKolda2007, Kruskal1977]
    theorem_level_novelty: none claimed
    computational_novelty: deterministic finite parity and error records
    limitations: "No CP uniqueness or optimal approximation theorem is claimed."
  - area: spectral projector perturbation
    known_component: eigenspace perturbation bounds under spectral separation
    new_component: threshold snapping control and no-gap counterexample
    new_combination: snapping diagnostics attached to reduced-law evidence
    evidence: src/seion_core/projectors/snapping.py
    references: [DavisKah

## claims/prior_art_registry.yaml

version: 1
scope: "Conservative prior-art map for the finite-dimensional structure-preserving reduction v2 track."
novelty_policy:
  - "A standard restriction, identity inheritance, or Davis-Kahan estimate is not a new theorem here."
  - "Terminology and a software implementation do not establish mathematical novelty."
  - "Any future novelty claim must name a theorem-level difference and a primary-source comparison."
entries:
  - id: PA_OPERAD_ALGEBRAS
    area: operads_and_algebras
    source: "Loday and Vallette, Algebraic Operads"
    source_url: "https://doi.org/10.1007/978-3-642-30362-3"
    established_result: "Algebraic operations and their compositions are organized by operads; algebras over an operad satisfy the declared compositional identities."
    closest_known_construction: "Restriction of an algebraic operation to an invariant subspace, expressed through partial compositions."
    exact_overlap: "The exact reduction theorem uses the same composition and identity inheritance mechanism."
    genuine_difference: "This repository gives a finite-dimensional coordinate certificate and tests it against an independent evaluator."
    theorem_level_novelty: "none established"
    computational_novelty: "typed parity and artifact contracts"
    limitation_of_novelty_claim: "No new operad or subalgebra theorem is claimed."
  - id: PA_FILIPPOV
    area: n_ary_and_filippov
    source: "Filippov, n-Lie algebras"
    source_url: "https://doi.org/10.1007/BF00969110"
    established_result: "The n-Lie/Filippov identity defines a class of alternating n-ary algebras."
    closest_known_construction: "Represent the fundamental identity as a signed polynomial in two n-ary operations."
    exact_overlap: "The v2 polynomial residual bookkeeping applies once the same arity and sign convention is encoded."
    genuine_difference: "The software handles generic finite n-linear laws, including laws that are not Filippov algebras."
    theorem_level_novelty: "none established"
    computational_novelty: "explicit convention registry"
    limitation_of_novelty_claim: "No classification, deformation theorem, or new Filippov identity is proved."
  - id: PA_AKIVIS_SABININ
    area: nonassociative_algebra
    source: "Mostovoy, Perez-Izquierdo, and Shestakov, Hopf algebras in non-associative Lie theory"
    source_url: "https://doi.org/10.1007/s13373-013-0049-8"
    established_result: "Akivis and Sabinin structures record nonassociative brackets, associators, and related operations."
    closest_known_construction: "Associator and polynomial identity tracking for a nonassociative product."
    exact_overlap: "The associator is treated 

## claims/prior_art_registry_v3.yaml

version: 3
scope: finite typed multilinear trees with recursive orthogonal projection
search_date: 2026-07-29
policy:
  - Absence from a bounded search is not evidence of novelty.
  - Standard operad semantics, telescoping, and norm products are not claimed as new.
  - Software and exhaustive finite checks cannot establish theorem-level novelty.
entries:
  - id: PA_V3_COLORED_OPERADS
    source: "Yau, Colored Operads"
    source_url: https://doi.org/10.1090/gsm/170
    established_result: Typed operations and rooted-tree partial composition are standard colored-operad semantics.
    exact_overlap: The v3 type grammar and ordered tree model.
    genuine_difference: Orthogonal projection defects and quantitative nodewise certificates are additional analytic data.
    candidate_theorems: [THM_V3_EXACT_SUBSET_EXPANSION]
    novelty_status: STANDARD_RESTRICTION_RESULT
  - id: PA_V3_ALGEBRAIC_OPERADS
    source: "Loday and Vallette, Algebraic Operads"
    source_url: https://doi.org/10.1007/978-3-642-30362-3
    established_result: Treewise composition and polynomial identities for algebras over operads.
    exact_overlap: Signed forests and insertion-tree syntax.
    genuine_difference: Quantitative normal leakage is not the monograph's central problem.
    candidate_theorems: [COR_V3_PROJECTED_TERNARY_ASSOCIATOR_TWO]
    novelty_status: KNOWN_BOUND_NEW_SPECIALIZATION
  - id: PA_V3_APPROXIMATE_HOMOMORPHISMS
    source: "Johnson, Approximately multiplicative maps between Banach algebras"
    source_url: https://doi.org/10.1112/jlms/s2-37.2.294
    established_result: Approximate multiplicativity can imply proximity to exact homomorphisms under Banach-algebra hypotheses.
    exact_overlap: Quantitative stability language for algebraic structure.
    genuine_difference: V3 propagates nodewise normal projection defects on a fixed finite tree rather than correcting a map globally.
    candidate_theorems: [THM_V3_PROJECTED_ROOT_K_MINUS_ONE]
    novelty_status: NOVELTY_NOT_ESTABLISHED
  - id: PA_V3_BACKWARD_ERROR
    source: "Higham, Accuracy and Stability of Numerical Algorithms"
    source_url: https://doi.org/10.1137/1.9780898718027
    established_result: Compositional forward/backward error analysis and order-sensitive arithmetic bounds are standard.
    exact_overlap: Local error propagation and evaluation-order comparisons.
    genuine_difference: Exact multilinear projector residuals and typed tree topology.
    candidate_theorems: [THM_V3_OPTIMAL_TELESCOPING_ORDER, THM_V3_NODEWISE_PATH_SUM]
    novelty_status: KNOWN_BOUND_NEW_SPECIALIZATION
  - id: PA_V3_LAYERED_LIPSCHITZ
    source: "Combettes and Pesquet, Lipschitz Cert

## claims/scope_registry_v4.yaml

version: 4
canonical_repository: seion-math-core
classes:
  CANONICAL_FINITE_CORE: [src/seion_core, tests, claims, experiments]
  ACTIVE_RESEARCH_TRACK: [papers/tree_stability_v3, artifacts/research_v3]
  SUPPORTING_MATHEMATICS: [foundations, projector_reduction, truncated_cohomology]
  EXTERNAL_APPLICATION: []
  HISTORICAL: [artifacts/checkpoints]
  SUPERSEDED: []
  SPECULATIVE: [claims/conjecture_registry.yaml]
  OUT_OF_SCOPE: [other repositories]


## claims/scope_registry_v4.yaml.json

{
  "branches": {
    "ACTIVE_RESEARCH_TRACK": [
      "research_v3",
      "papers/tree_stability_v3"
    ],
    "CANONICAL_FINITE_CORE": [
      "src/seion_core",
      "tests",
      "claims",
      "experiments"
    ],
    "EXTERNAL_APPLICATION": [],
    "HISTORICAL": [
      "artifacts/checkpoints"
    ],
    "OUT_OF_SCOPE": [
      "other repositories"
    ],
    "SPECULATIVE": [
      "claims/conjecture_registry.yaml"
    ],
    "SUPERSEDED": [],
    "SUPPORTING_MATHEMATICS": [
      "truncated_cohomology",
      "foundations",
      "projector_reduction"
    ]
  },
  "canonical_repository": "seion-math-core",
  "version": 4
}


## claims/theorem_dependency_matrix_v2.csv

theorem_id,kind,depends_on,required_assumptions,proof_or_definition,independent_evidence,cycle_status,epistemic_status,novelty_status
THM_EXACT_TYPED_REDUCTION_V2,theorem,,"finite-dimensional Hilbert spaces; isometric Q; compatible dimensions; exact closure at every node",docs/theorems_v2/exact_reduction.md,tests/research_v2/test_theorem_examples.py;artifacts/symbolic_v2/exact_invariant_reduction.json,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
THM_OPERADIC_IDENTITY_INHERITANCE_V2,theorem,THM_EXACT_TYPED_REDUCTION_V2,"same declared operation and tree convention for every polynomial term",docs/theorems_v2/polynomial_identities.md,tests/research_v2/test_theorem_examples.py,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
THM_APPROXIMATE_TREE_BOUND_V2,theorem,,"bounded n-linear law; uniform closure residual rho; projection at every reduced internal node",docs/theorems_v2/approximate_closure.md,tests/research_v2/test_theorem_examples.py;artifacts/index/bound_tightness_v2.csv,acyclic,PROVED_AUXILIARY,NOT_ESTABLISHED
THM_SPECTRAL_SNAPPING_GAP_V2,theorem,,"Hermitian A and E; threshold 1/2; gap gamma>0; ||E||<=gamma/2",docs/theorems_v2/spectral_snapping.md,tests/research_v2/test_theorem_examples.py;artifacts/counterexamples_v2/spectral_gap_sweep.json,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
PROP_FINITE_COHOMOLOGY_DESCENT_V2,proposition,,"finite cochain spaces; d^2=0; exact commutation",docs/theorems/cohomology_descent.md,legacy theorem registry,acyclic,PROVED_UNDER_ASSUMPTIONS,SUPPORTING_ONLY
CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2,counterexample,THM_EXACT_TYPED_REDUCTION_V2,"exact invariance removed",claims/counterexample_registry_v2.yaml,tests/research_v2/test_theorem_examples.py,acyclic,REFUTED_WITHOUT_HYPOTHESIS,BOUNDARY_CONTROL
CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,counterexample,THM_SPECTRAL_SNAPPING_GAP_V2,"positive gap removed",claims/counterexample_registry_v2.yaml,tests/research_v2/test_theorem_examples.py,acyclic,REFUTED_WITHOUT_HYPOTHESIS,BOUNDARY_CONTROL


## claims/theorem_dependency_matrix_v3.csv

theorem_id,dependency_id,relation,dependency_status,circular,proof_evidence
THM_V3_ROOT_ERROR_ORTHOGONALITY,DEF_V3_TYPED_TREE_EVALUATIONS,uses typed ambient/projected definitions,DEFINITION,false,docs/theorems_v3/typed_model.md
THM_V3_EXACT_SUBSET_EXPANSION,DEF_V3_TYPED_TREE_EVALUATIONS,expands the recursive node definitions,DEFINITION,false,docs/theorems_v3/exact_subset_expansion.md
THM_V3_HOMOGENEOUS_AMBIENT_K,THM_V3_EXACT_SUBSET_EXPANSION,bounds every exact subset term,PROVED,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_PROJECTED_ROOT_K_MINUS_ONE,THM_V3_EXACT_SUBSET_EXPANSION,projects away the root local residual,PROVED,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_PROJECTED_ROOT_K_MINUS_ONE,THM_V3_ROOT_ERROR_ORTHOGONALITY,identifies projected and reduced root error,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_OPTIMAL_TELESCOPING_ORDER,,independent adjacent-exchange theorem,NOT_APPLICABLE,false,docs/theorems_v3/telescoping_order.md
THM_V3_NODEWISE_MIXED_CERTIFICATE,THM_V3_EXACT_SUBSET_EXPANSION,enumerates mixed child-error masks,PROVED,false,docs/theorems_v3/nodewise_certificates.md
THM_V3_NODEWISE_MIXED_CERTIFICATE,THM_V3_OPTIMAL_TELESCOPING_ORDER,uses the optimal scalar order as one sound candidate,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/nodewise_certificates.md
THM_V3_NODEWISE_PATH_SUM,THM_V3_OPTIMAL_TELESCOPING_ORDER,propagates local sources along ordered ancestor paths,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/nodewise_certificates.md
COR_V3_PROJECTED_TERNARY_ASSOCIATOR_TWO,THM_V3_PROJECTED_ROOT_K_MINUS_ONE,applies the k-1 coefficient to two signed two-node trees,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/signed_forests.md


## claims/theorem_registry.yaml

theorems:
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    statement: "R_standard(x,y)z = A(y,x,z)-A(x,y,z)."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [finite-dimensional bilinear product, stated bracket]
    proof_location: docs/theorems/curvature_associator.md
    symbolic_verification: artifacts/symbolic/curvature_identity.json
    epistemic_status: PROVED
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    statement: "T d = d T implies a well-defined action on finite cohomology."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [d^2=0, degree-preserving T]
    proof_location: docs/theorems/cohomology_descent.md
    symbolic_verification: null
    epistemic_status: PROVED_UNDER_ASSUMPTIONS



## claims/theorem_registry_v2.yaml

version: 2
scope: "Finite-dimensional structure-preserving reduction research track."
novelty_policy: "Standard consequences are registered as such; no submission-ready novelty claim is active."
theorems:
  - id: THM_EXACT_TYPED_REDUCTION_V2
    title: Exact invariant reduction commutes with declared tree composition
    statement: "For an isometric embedding Q and an exactly invariant subspace, Q times the reduced tree evaluation equals the ambient tree evaluation on lifted leaves."
    assumptions:
      - finite-dimensional Hilbert spaces
      - Q*Q = I
      - every law used at an internal node maps the selected subspaces into the selected output subspace
      - declared slot order and compatible dimensions
    proof_location: docs/theorems_v2/exact_reduction.md
    implementation:
      reference: src/seion_core/research_v2/reference.py
      accelerated: src/seion_core/research_v2/accelerated.py
    evidence:
      tests: tests/research_v2/test_reference_parity.py
      artifacts: artifacts/symbolic_v2/exact_invariant_reduction.json
    epistemic_status: ESTABLISHED_KNOWN_RESULT
    novelty_status: NOT_CLAIMED
  - id: THM_OPERADIC_IDENTITY_INHERITANCE_V2
    title: Exact inheritance of declared multilinear polynomial identities
    statement: "Every finite signed polynomial in declared tree compositions vanishing for the ambient law vanishes for the exactly reduced law."
    assumptions:
      - assumptions of THM_EXACT_TYPED_REDUCTION_V2
      - every term uses the same declared operations and convention
    proof_location: docs/theorems_v2/polynomial_identities.md
    implementation: src/seion_core/research_v2/reference.py
    evidence: tests/research_v2/test_theorem_examples.py
    epistemic_status: ESTABLISHED_KNOWN_RESULT
    novelty_status: NOT_CLAIMED
  - id: THM_APPROXIMATE_TREE_BOUND_V2
    title: Explicit approximate-closure tree recurrence
    statement: "For k internal nodes, ||F_T-R_T|| <= k rho M^(k-1) product leaf norms."
    assumptions:
      - finite-dimensional Hilbert space
      - bounded n-linear law with operator norm M
      - uniform closure residual rho for projected inputs
      - every internal output is projected in the reduced evaluation
    proof_location: docs/theorems_v2/approximate_closure.md
    implementation: src/seion_core/research_v2/reference.py
    evidence:
      tests: tests/research_v2/test_theorem_examples.py
      artifacts: artifacts/index/bound_tightness_v2.csv
    epistemic_status: PROVED_AUXILIARY
    novelty_status: NOT_ESTABLISHED
  - id: THM_SPECTRAL_SNAPPING_GAP_V2
    title: Threshold snapping stability under a positive gap
    statement: "For Hermitian thr

## claims/theorem_registry_v3.yaml

version: 3
track: nodewise_tree_constants
governance_note: >-
  Mathematical proofs and deterministic checks are present, but AI output does
  not constitute official theorem approval; independent human review is pending.
theorems:
  - id: THM_V3_ROOT_ERROR_ORTHOGONALITY
    title: Exact orthogonal decomposition of the four named root errors
    statement: "E_amb^2 = E_proj^2 + E_normal^2 and E_red = E_proj."
    scope: [finite typed Hilbert spaces, orthogonal projectors, arbitrary finite typed trees]
    dependencies: [DEF_V3_TYPED_TREE_EVALUATIONS]
    proof_location: docs/theorems_v3/typed_model.md
    implementation: src/seion_core/research_v3/projected_evaluation.py
    tests: [tests/research_v3/unit/test_evaluation.py]
    epistemic_status: PROVED_UNDER_ASSUMPTIONS
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_EXACT_SUBSET_EXPANSION
    title: Exact local child-error subset expansion
    statement: >-
      Delta_v equals the local normal residual plus one multilinear term for
      every nonempty subset of erroneous child branches.
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities]
    dependencies: [DEF_V3_TYPED_TREE_EVALUATIONS]
    proof_location: docs/theorems_v3/exact_subset_expansion.md
    implementation: src/seion_core/research_v3/error_expansion.py
    tests: [tests/research_v3/symbolic/test_error_expansion.py]
    epistemic_status: PROVED
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_HOMOGENEOUS_AMBIENT_K
    title: Universal ambient coefficient k
    statement: "E_amb <= k rho M^(k-1) product_l ||z_l||."
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities, uniform M and rho]
    dependencies: [THM_V3_EXACT_SUBSET_EXPANSION]
    proof_location: docs/theorems_v3/homogeneous_constants.md
    implementation: src/seion_core/research_v3/certificates.py
    tests: [tests/research_v3/certificates/test_certificates.py]
    epistemic_status: PROVED_UNDER_ASSUMPTIONS
    sharpness_status: OPEN_AT_FIXED_ETA
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_PROJECTED_ROOT_K_MINUS_ONE
    title: Projected-root coefficient k minus one
    statement: "E_proj = E_red <= (k-1) rho M^(k-1) product_l ||z_l||."
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities, uniform M and rho]
    dependencies: [THM_V3_EXACT_SUBSET_EXPANSION, THM_V3_ROOT_ERROR_ORTHOGONALITY]
    proof_location: docs/theorems_v3/homogeneous_constants.md
    implementation: src/seion_core/research_v3/certificates.py

## docs/theorems_v3/README.md

# V3 theorem dossier

This directory is the proof authority for the finite typed-tree track.  The
scope is finite-dimensional real or complex Hilbert spaces, orthogonal
projectors, bounded multilinear laws, and finite ordered trees.  It does not
assert a continuum, infinite-tree, tensor-identifiability, or physical result.

The proof chain is:

1. [`typed_model.md`](typed_model.md) fixes the four inequivalent errors and
   their exact Hilbert-space relationships.
2. [`exact_subset_expansion.md`](exact_subset_expansion.md) gives the exact
   local identity before inequalities.
3. [`homogeneous_constants.md`](homogeneous_constants.md) proves the universal
   ambient coefficient (k) and projected-root coefficient (k-1).
4. [`telescoping_order.md`](telescoping_order.md) proves the optimal replacement
   order for the declared scalar telescoping certificate.
5. [`nodewise_certificates.md`](nodewise_certificates.md) derives the mixed-mask
   dynamic program and residual path sum.
6. [`signed_forests.md`](signed_forests.md) states what cancellation is and is
   not captured for polynomial identities.
7. [`cp_projection_budget.md`](cp_projection_budget.md) separates representation
   and closure error.

The proofs are mathematically marked `PROVED_UNDER_ASSUMPTIONS`; governance
approval remains pending independent human review.  Sharpness at a fixed
(eta=
ho/M>0) is not inferred from the upper bounds.


## docs/theorems_v3/cp_projection_budget.md

# Approximation plus projection

Let (widehat\mu_v) approximate (mu_v) with
(delta_v=\lVert\mu_v-widehat\mu_v\rVert_{\rm op}).  Insert the ambient
(widehat\mu)-tree between the exact ambient tree and the recursively
projected approximate tree.  The triangle inequality separates

\[
\lVert F_\mu-R_{\widehat\mu}\rVert
\le
\underbrace{\lVert F_\mu-F_{\widehat\mu}\rVert}_{\text{representation}}
+
\underbrace{\lVert F_{\widehat\mu}-R_{\widehat\mu}\rVert}_{\text{projection/closure}}.
\]

In the homogeneous case (lVert\mu\rVert\le M),
(lVert\mu-widehat\mu\rVert\le\delta), and (widehat M\le M+delta).
For (k) nodes the implemented transparent budget is

\[
\begin{aligned}
E_{\rm repr}&\le k\delta(M+\delta)^{k-1}L,\\
E_{\rm closure,base}&\le c\rho M^{k-1}L,\\
E_{\rm interaction}&\le c\rho\bigl[(M+\delta)^{k-1}-M^{k-1}\bigr]L,
\end{aligned}
\]

where (c=k) for ambient error and (c=k-1) for projected-root error.  The
interaction term is the extra recursive amplification of closure caused by
the representation perturbation.  CP reconstruction error, operator-output
error, and closure residual remain separate metrics; CP error is never folded
into (
ho).


## docs/theorems_v3/exact_subset_expansion.md

# Exact local subset expansion

Fix an internal vertex (v), write (P=P_{\tau(v)}), and abbreviate
(R_i=R_{c_i}), (F_i=F_{c_i}), and (Delta_i=F_i-R_i).  Multilinearity gives

\[
\mu_v(F_1,\ldots,F_a)
=\sum_{S\subseteq\{1,\ldots,a\}}
  \mu_v(y_1^S,\ldots,y_a^S),
\quad
y_i^S=\begin{cases}\Delta_i&i\in S,\\R_i&i\notin S.\end{cases}
\]

Because (R_v=P\mu_v(R_1,\ldots,R_a)), subtraction yields the exact identity

\[
\boxed{
\Delta_v
=r_v(R_1,\ldots,R_a)
+\sum_{\varnothing\ne S\subseteq[a]}
  \mu_v(y_1^S,\ldots,y_a^S),
}
\]

where (r_v=(I-P)\mu_v(P\cdot,\ldots,P\cdot)).  The first term is the local
normal residual.  Cardinality-one subsets are propagated child errors;
larger subsets are genuine branch-interaction terms.  Applying (P) removes
the local residual exactly, whereas applying (I-P) retains it:

\[
P\Delta_v=\sum_{S\ne\varnothing}P\mu_v(y^S),\qquad
(I-P)\Delta_v=r_v(R)+(I-P)\sum_{S\ne\varnothing}\mu_v(y^S).
\]

No triangle inequality has been used.  The (2^a-1) terms are generated and
reconstructed numerically by `error_expansion.py`; symbolic tests verify the
term count and numerical tests compare the identity to direct contraction.


## docs/theorems_v3/homogeneous_constants.md

# Universal homogeneous coefficients (k) and (k-1)

## Theorem

Let (T) be any finite typed ordered tree, with heterogeneous types, laws, and
arities allowed.  Suppose every node law has operator norm at most (M), and
every node closure map has norm at most (
ho).  Let (k(T)) be the number of
internal vertices and (L_T=\prod_\ell\lVert z_\ell\rVert).  Then

\[
\begin{aligned}
E_T^{\rm amb}&\le k(T)\rho M^{k(T)-1}L_T,\\
E_T^{\rm proj}&=E_T^{\rm red}
  \le (k(T)-1)\rho M^{k(T)-1}L_T,\\
E_T^{\rm normal}&\le k(T)\rho M^{k(T)-1}L_T.
\end{aligned}
\]

For (k=0), all errors are zero.  For (k=1), the projected and reduced
errors are exactly zero.

## Proof

For a subtree rooted at (v), let (k_v) be its internal-node count and
(L_v) its leaf-norm product.  Orthogonal projection is contractive, so a
first induction gives

\[
\lVert F_v\rVert,\lVert R_v\rVert\le M^{k_v}L_v.
\]

Assume the ambient claim for all children.  Multilinear telescoping, in any
slot order, gives

\[
\lVert\mu_v(F_1,\ldots,F_a)-\mu_v(R_1,\ldots,R_a)\rVert
\le M\sum_j\lVert F_j-R_j\rVert
  \prod_{i<j}\lVert R_i\rVert\prod_{i>j}\lVert F_i\rVert.
\]

The (j)-th term is at most
(k_{c_j}\rho M^{k_v-1}L_v).  Since
(sum_jk_{c_j}=k_v-1), propagated child error contributes at most
((k_v-1)\rho M^{k_v-1}L_v).  The local closure residual contributes at most

\[
\rho\prod_j\lVert R_j\rVert\le\rho M^{k_v-1}L_v.
\]

Their sum proves the ambient estimate.  For the projected error,

\[
P_v(F_v-R_v)
=P_v\bigl(\mu_v(F_1,\ldots,F_a)-\mu_v(R_1,\ldots,R_a)\bigr),
\]

so the root residual is absent and only the (k_v-1) propagated terms remain.
For the normal error, apply (I-P_v) and retain the local residual, obtaining
coefficient (k_v).  Induction closes all three estimates. (square)

## What this proves—and what it does not

The coefficient (k-1) is therefore a universal upper bound, not a numerical
conjecture.  This proof does **not** establish that (k) or (k-1) is attained
for each fixed (eta=\rho/M>0), dimension, rank, topology, or repeated-law
class.  Explicit rotation families give certified lower bounds and approach
some uniform coefficients as (eta\downarrow0), but fixed-(eta) optimality
remains an optimization problem.  Accordingly the registry does not label the
fixed-(eta) constants `EXACT_OPTIMAL_CONSTANT`.

For a five-input ternary associator (the difference of two two-node trees),
the projected triangle certificate improves from (2+2=4) to (1+1=2).
Whether cancellation lowers the best associator constant below two is kept
separate.


## docs/theorems_v3/nodewise_certificates.md

# Mixed-mask dynamic program and residual path sums

For each node (v), record (M_v), (m_v), (
ho_v), and, when available,
the block norms obtained by restricting every input slot to its projected
(`P`) or normal (`N`) subspace and the output to full, projected, or normal
coordinates.  Decompose every child error orthogonally as
(Delta_i=P_i\Delta_i+(I-P_i)\Delta_i).

The exact subset identity then has three possible states per slot:

- `R`: the recursively projected child;
- `DP`: its projected error;
- `DN`: its normal error.

For every state vector other than all `R`, multiply the corresponding child
bounds and the certified mixed-block norm.  This gives subset bounds
(S_v^F,S_v^P,S_v^N).  With
(lambda_v=
ho_v\prod_iB_{c_i}^R), define

\[
\begin{aligned}
B_v^F&=M_v\prod_iB_{c_i}^F,\\
B_v^R&=m_v\prod_iB_{c_i}^R,\\
B_v^P&\le S_v^P,\\
B_v^N&\le\lambda_v+S_v^N,\\
B_v^A&\le\min\{\lambda_v+S_v^F,
  \sqrt{(B_v^P)^2+(B_v^N)^2}\}.
\end{aligned}
\]

The implementation also computes arbitrary, left/right, and provably optimal
telescoping certificates and takes a minimum only among independently valid
upper bounds.  The subset cost is (O(3^{a_v})); hence total complexity is
(O(|T|3^{a_{\max}}+|T|a_{\max}\log a_{\max})), linear in (|T|) for the
declared bounded arities two through four.

## Path-sum form

Fix an optimal telescoping order at each ancestor.  If child (j) is replaced
at ancestor (a), define

\[
h_{a,j}=G_{a,j}
\prod_{i\text{ before }j}B_{c_i}^R
\prod_{i\text{ after }j}B_{c_i}^F.
\]

Expanding the scalar recurrence gives the rigorous source-resolved certificate

\[
B_{T,\mathrm{path}}^A
=\sum_{v\in\operatorname{Int}T}
\lambda_v\prod_{(a,j)\in\operatorname{path}(v,\mathrm{root})}h_{a,j}.
\]

For projected-root error, the source (v=\mathrm{root}) is omitted and the
last propagation gain is the projected-output gain.  For normal-root error it
is retained with the normal-output gain.  The artifact table records every
source contribution rather than only their sum.

The path-sum, mixed-subset, and optimized telescoping bounds use different
information and are not asserted to dominate one another universally.  The
engine reports observed dominance cell by cell and proves only minima of valid
certificates.


## docs/theorems_v3/signed_forests.md

# Signed forests and cancellation-aware scope

A polynomial expression is a finite signed forest
(mathcal F=\sum_\alpha c_\alpha T_\alpha) whose terms have a common typed
input/output signature.  A per-tree triangle certificate is always valid, but
it can discard exact cancellation.

The v3 engine applies three progressively stronger operations:

1. syntactically identical trees are grouped and their coefficients summed
   exactly;
2. shared subtree evaluations are represented as an expression DAG;
3. adversarial evaluation optimizes the whole signed expression rather than
   independent terms.

Only the first operation is an unconditional symbolic cancellation theorem in
the current implementation.  A lower adversarial ratio for the whole forest is
an `EMPIRICAL_LOWER_BOUND`, not an optimal constant.  The projected five-input
ternary associator has unconditional triangle coefficient two by the
(k-1) theorem.  A matching fixed-(eta) construction has not been certified,
so coefficient two is not labeled exact-optimal.  Filippov, GJI, and Jacobiator
experiments preserve their exact named sign and insertion conventions.


## docs/theorems_v3/telescoping_order.md

# Optimal telescoping order

For one multilinear replacement step, let (e_i\ge0) bound the error in slot
(i), (r_i\ge0) the recursively projected child magnitude, (f_i\ge0) the
ambient child magnitude, and (G_i\ge0) a slot/output-specific gain.  Put
(w_i=G_ie_i).  For an order (pi), define

\[
C(\pi)=\sum_t w_{\pi_t}
  \prod_{s<t}r_{\pi_s}\prod_{s>t}f_{\pi_s}.
\]

Consider adjacent slots (i,j).  All prefix and suffix factors are common, so
(i) before (j) is no worse exactly when

\[
w_i f_j+r_iw_j\le w_jf_i+r_jw_i
\iff
w_i(f_j-r_j)\le w_j(f_i-r_i).
\]

Let (d_i=f_i-r_i).  A globally optimal order is obtained as follows:

1. slots with (d_i>0), sorted by (w_i/d_i) increasingly;
2. slots with (d_i=0,w_i>0);
3. slots with (d_i<0), again sorted by (w_i/d_i) increasingly.

Slots with (d_i=w_i=0) are indifferent and receive a deterministic position.
The cross-sign order follows directly from the exchange inequality: positive
(d) precedes negative (d), with the nonzero zero-denominator class between.
Within either nonzero sign class, division by (d_id_j>0) yields increasing
(w_i/d_i).  Repeatedly exchanging adjacent inversions cannot increase the
cost and terminates at the stated order, proving global optimality for this
scalar certificate.

This theorem optimizes the declared telescoping upper bound; it does not claim
that the resulting bound is the exact error of a fixed law.  Deterministic
tests compare the sorted order with all permutations for random positive,
zero, and negative denominators through arity seven.


## docs/theorems_v3/typed_model.md

# Typed trees and exact root-error relationships

Let (Tau) be finite.  For each color (	au), let (V_	au) be a
finite-dimensional real or complex Hilbert space and let
(P_	au=Q_	au Q_	au^*), where (Q_	au:W_	au\to V_	au) is an isometry.
A typed ordered tree assigns to every internal vertex (v) a bounded
(a_v)-linear map


\[
  \mu_v:\prod_{j=1}^{a_v}V_{\tau(v,j)}\longrightarrow V_{\tau(v)}.
\]

For reduced leaf data (z_\ell\in W_{\tau(\ell)}), define

\[
F_\ell=R_\ell=Q_{\tau(\ell)}z_\ell,
\quad
F_v=\mu_v(F_{c_1},\ldots,F_{c_{a_v}}),
\quad
R_v=P_{\tau(v)}\mu_v(R_{c_1},\ldots,R_{c_{a_v}}).
\]

At the root put (Delta=F-R).  Since (R\in\operatorname{ran}P),

\[
  \Delta=P\Delta+(I-P)\Delta
        =(PF-R)+(I-P)F,
\]

and the two summands are orthogonal.  Consequently the four named errors obey
the exact identities

\[
 (E_T^{\rm amb})^2=(E_T^{\rm proj})^2+(E_T^{\rm normal})^2,
 \qquad E_T^{\rm red}=E_T^{\rm proj}.
\]

The second equality follows from
(Q^*F-Q^*R=Q^*(PF-R)) and the fact that (Q^*) is an isometry on
(operatorname{ran}P).  These are identities, not bounds.  The implementation
checks both residuals in
`src/seion_core/research_v3/projected_evaluation.py` against independent
coordinate-loop and NumPy evaluations.

Every edge is checked against the input color declared by its node law before
evaluation.  A type-invalid tree has no numerical semantics and is rejected.


## papers/tree_stability_v3/proofs/full_proofs.tex

\section{Full proof appendices}
\label{app:proofs}

This appendix records the complete finite-dimensional arguments used by the
claim registry. No statement below depends on an optimizer, a conjecture, or
a numerical plot.

\subsection{Magnitude induction and exact root geometry}

For a subtree rooted at \(v\), let \(k_v\) be its number of internal
vertices and let \(L_v\) be the product of the reduced leaf norms below it.

\begin{lemma}[Subtree magnitudes]
\label{lem:magnitudes}
If every node law has multilinear operator norm at most \(M\), then
\[
  \lVert F_v\rVert\le M^{k_v}L_v,
  \qquad
  \lVert R_v\rVert\le M^{k_v}L_v.
\]
\end{lemma}

\begin{proof}
At a leaf, \(F_v=R_v=Q_vz_v\), and \(Q_v\) is an isometry. Suppose the
claim holds for the children \(c_1,\ldots,c_a\). Multilinearity and the
definition of the operator norm give
\[
 \lVert F_v\rVert
 \le M\prod_i \lVert F_{c_i}\rVert
 \le M^{1+\sum_i k_{c_i}}\prod_iL_{c_i}
 =M^{k_v}L_v.
\]
The same argument applies to
\(R_v=P_v\mu_v(R_{c_1},\ldots,R_{c_a})\), because an orthogonal projector
is contractive. Induction proves both claims.
\end{proof}

\begin{proposition}[Root-error orthogonality]
\label{prop:rootgeometry}
For every valid typed tree,
\[
 (E_T^{\rm amb})^2=(E_T^P)^2+(E_T^N)^2,
 \qquad E_T^{\rm red}=E_T^P.
\]
\end{proposition}

\begin{proof}
At the root, write \(P=QQ^*\), \(F=F_T\), and
\(R=R_T\in\operatorname{ran}P\). Then
\[
 F-R=(PF-R)+(I-P)F.
\]
The first summand belongs to \(\operatorname{ran}P\) and the second to its
orthogonal complement. Pythagoras gives the first identity. Moreover,
\[
 Q^*F-Q^*R=Q^*(PF-R).
\]
The restriction of \(Q^*\) to \(\operatorname{ran}P\) is an isometry,
which proves the second identity.
\end{proof}

\subsection{Exact subset expansion}

\begin{theorem}[Local child-error expansion]
\label{thm:subset-full}
Let \(v\) have arity \(a\), children \(c_i\), recursively projected values
\(R_i\), and errors \(D_i=F_i-R_i\). For
\[
 y_i^S=\begin{cases}D_i,&i\in S,\\R_i,&i\notin S,\end{cases}
 \qquad
 r_v=(I-P_v)\mu_v(P_{c_1}\,\cdot,\ldots,P_{c_a}\,\cdot),
\]
one has the exact identity
\[
 D_v=r_v(R_1,\ldots,R_a)
 +\sum_{\varnothing\ne S\subseteq[a]}
 \mu_v(y_1^S,\ldots,y_a^S).
\]
\end{theorem}

\begin{proof}
Since \(F_i=R_i+D_i\), repeated multilinearity yields
\[
 \mu_v(F_1,\ldots,F_a)
 =\sum_{S\subseteq[a]}\mu_v(y_1^S,\ldots,y_a^S).
\]
The term indexed by the empty set is \(\mu_v(R_1,\ldots,R_a)\), while
\(R_v=P_v\mu_v(R_1,\ldots,R_a)\). Subtracting \(R_v\) separates the
empty-set term into its normal component \(r_v(R_1,\ldots,R_a)\); all
nonempty terms remain unchanged. No inequality has been used.
\end{proof}

Applying \(P_v\) t

## src/seion_core/research_v3/__init__.py

"""Nodewise stability tools for typed recursively projected trees.

The v3 namespace is intentionally independent of :mod:`research_v2`.  Its
public objects distinguish ambient, projected-root, normal, and reduced
coordinate errors and never attach an optimality claim to an uncertified
numerical search.
"""

from .certificates import BoundCertificate, LocalSummary, certify_tree
from .local_constants import TypedLaw
from .typed_tree import Leaf, Node, Tree, validate_tree
from .types import TypeSystem, TypedSpace

__all__ = [
    "BoundCertificate",
    "Leaf",
    "LocalSummary",
    "Node",
    "Tree",
    "TypeSystem",
    "TypedLaw",
    "TypedSpace",
    "certify_tree",
    "validate_tree",
]


## tests/research_v3/adversarial/test_searches.py

import pytest

from seion_core.research_v3.adversarial_search import (
    SearchConfig,
    derivative_free_search,
    gradient_search,
)
from seion_core.research_v3.typed_tree import Leaf, Node


def _tree():
    inner = Node("mu", "tau", (Leaf(0, "tau"), Leaf(1, "tau")))
    return Node("mu", "tau", (inner, Leaf(2, "tau")))


def test_tiny_gradient_search_is_explicitly_empirical():
    result = gradient_search(
        _tree(),
        SearchConfig(
            eta=0.1,
            seeds=(0,),
            restarts_per_seed=1,
            adam_steps=3,
            lbfgs_steps=1,
            device="cpu",
        ),
    )
    assert result.best_lower_bound >= 0.0
    assert result.status == "EMPIRICAL_LOWER_BOUND"
    assert not result.globally_certified


@pytest.mark.slow
def test_tiny_derivative_free_search_is_independent_and_empirical():
    result = derivative_free_search(
        _tree(), eta=0.1, maximum_iterations=1, population_size=2, seed=1
    )
    assert result.best_lower_bound >= 0.0
    assert "differential" in result.optimizer.lower()
    assert not result.globally_certified

