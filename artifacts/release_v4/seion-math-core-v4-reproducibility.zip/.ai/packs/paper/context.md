# Deterministic SEION context pack

Task: SEION v4 paper context
Category: paper
Estimated tokens: 17999/18000

## artifacts/qa_v3/hardware_v3.json

{
  "cuda_available": true,
  "cuda_version": "12.8",
  "gpus": [
    {
      "capability": [
        12,
        0
      ],
      "index": 0,
      "name": "NVIDIA RTX PRO 5000 Blackwell Generation Laptop GPU",
      "total_memory_bytes": 25650855936
    }
  ],
  "logical_cpu_count": 24,
  "machine": "AMD64",
  "processor": "Intel64 Family 6 Model 198 Stepping 2, GenuineIntel",
  "ram_bytes": 136856682496
}


## artifacts/qa_v3/pdf_manifest_v3.json

{
  "documents": {
    "mathematical_paper": {
      "blank_pages": [],
      "bytes": 790425,
      "contact_sheets": [
        "artifacts\\qa_v3\\contact_sheets\\mathematical_paper_01-16.png",
        "artifacts\\qa_v3\\contact_sheets\\mathematical_paper_17-31.png"
      ],
      "metadata": {
        "Author": "Eliuth Chavero Jasso",
        "Keywords": "multilinear tree, recursive projection, closure residual, nodewise certificate, operad, interval certification",
        "Subject": "Finite-dimensional multilinear tree error certificates under recursive orthogonal projection",
        "Title": "Nodewise Error Certificates for Recursively Projected N-Ary Composition Trees"
      },
      "page_sizes": [
        [
          612.0,
          792.0
        ]
      ],
      "pages": 31,
      "pdf": "papers\\tree_stability_v3\\build\\main.pdf",
      "pdfinfo": "Title:           Nodewise Error Certificates for Recursively Projected N-Ary Composition Trees\nSubject:         Finite-dimensional multilinear tree error certificates under recursive orthogonal projection\nKeywords:        multilinear tree, recursive projection, closure residual, nodewise certificate, operad, interval certification\nAuthor:          Eliuth Chavero Jasso\nCreator:         LaTeX with hyperref\nProducer:        MiKTeX pdfTeX-1.40.29\nCreationDate:    Wed Jul 29 14:13:05 2026 Eastern Daylight Time\nModDate:         Wed Jul 29 14:13:05 2026 Eastern Daylight Time\nCustom Metadata: yes\nMetadata Stream: no\nTagged:          no\nUserProperties:  no\nSuspects:        no\nForm:            none\nJavaScript:      no\nPages:           31\nEncrypted:       no\nPage size:       612 x 792 pts (letter)\nPage rot:        0\nFile size:       790425 bytes\nOptimized:       no\nPDF version:     1.5\n",
      "render_status": "PASS",
      "rendered_pages": 31,
      "sha256": "c67106c478e660741c1ac71d2fadc31ef270636141e36e5732896ce8533574eb",
      "text_characters": 122062
    },
    "software_companion": {
      "blank_pages": [],
      "bytes": 258142,
      "contact_sheets": [
        "artifacts\\qa_v3\\contact_sheets\\software_companion_01-06.png"
      ],
      "metadata": {
        "Author": "Eliuth Chavero Jasso",
        "Keywords": "research software, typed tree, multilinear tensor, CUDA parity, interval arithmetic, reproducibility",
        "Subject": "Reproducible software and artifact protocol for finite typed multilinear tree certificates",
        "Title": "SEION Math Core v3: Typed Tree Certificates and Reproducible Experiments"
      },
      "page_sizes": [
        [
          612.0,
          792.0
        ]
      ],
      "pages": 6,
      "pdf": "papers\\software_v3\\build\\main.pdf",
      "pdfinfo": "Title:           SEION Math Core v3: Typed Tree Certificates and Reproducible Experiments\nSubject:         Reproducible software and artifact protocol fo

## artifacts/qa_v3/visual_inspection_v3.json

{
  "epistemic_note": "This is a layout inspection record, not independent mathematical review or publication authorization.",
  "generated_utc": "2026-07-29T18:13:47.762764+00:00",
  "human_release_approval": false,
  "inspector": "Codex visual inspection",
  "notes": "Post-canonical inspection of all 37 rendered pages and the 18-figure contact sheet at source commit b718f4e5178590d1f8b6a090fb696545eb3bfcd4. Detailed prior-art page 11 was rechecked after ragged-right rebuild. No clipping, overlap, blank page, missing asset, illegible equation, or broken visual hierarchy observed. This is visual QA only, not human peer review or publication approval.",
  "pdf_hashes": {
    "mathematical_paper": "c67106c478e660741c1ac71d2fadc31ef270636141e36e5732896ce8533574eb",
    "software_companion": "6a4bdce3b504bf244b9514c7bcc76aa5b0aa6d84f78cb96b41803405417837b3"
  },
  "scope": "all rendered pages in both contact-sheet sets",
  "source_commit": "b718f4e5178590d1f8b6a090fb696545eb3bfcd4",
  "status": "PASS"
}


## claims/claim_evidence_matrix_v2.csv

claim_id,status,claim_text,theorem_or_proposition_evidence,experiment_evidence,counterexample_evidence,run_index,figures_or_tables,release_impact
CLM_V2_001,ESTABLISHED_KNOWN_RESULT,"Exact invariant reduction commutes with every declared full ordered tree composition.",THM_EXACT_TYPED_REDUCTION_V2,exact symbolic artifact and parity tests,,artifacts/symbolic_v2/exact_invariant_reduction.json,fig03_exact_reduction_diagram.pdf,No novelty claim; theorem is auditable and reusable.
CLM_V2_002,ESTABLISHED_KNOWN_RESULT,"Multilinear polynomial identities built from the declared operation descend under exact invariance.",THM_OPERADIC_IDENTITY_INHERITANCE_V2,tests/research_v2/test_theorem_examples.py,,artifacts/symbolic_v2/exact_invariant_reduction.json,fig02_ternary_composition_trees.pdf,No novelty claim; convention-dependent scope is explicit.
CLM_V2_003,PROVED_AUXILIARY,"For a tree with k internal nodes, projected evaluation error is at most k rho M^(k-1) times the product of leaf norms.",THM_APPROXIMATE_TREE_BOUND_V2,60 registered runs with five seeds per tree/epsilon group,,artifacts/index/bound_tightness_v2.csv,fig08_closure_convergence.pdf;tables/bound_tightness.tex,Auxiliary certificate; not submission-grade novelty by itself.
CLM_V2_004,ESTABLISHED_KNOWN_RESULT,"Hermitian threshold snapping is stable under a positive gap with a conservative min(1,4||E||/gamma) bound.",THM_SPECTRAL_SNAPPING_GAP_V2,60 positive-gap runs with five seeds per control cell,CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,artifacts/index/spectral_gap_v2.csv,fig07_spectral_gap_stability.pdf;tables/spectral_gap.tex,Standard perturbation consequence; no novelty claim.
CLM_V2_005,VERIFIED_COUNTEREXAMPLE,"Without exact invariance, reduction need not commute with partial composition.",,test_no_invariance_counterexample_breaks_composition,CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2,artifacts/counterexamples_v2/no_invariance_composition.json,fig04_closure_leakage_geometry.pdf,Supports the stated hypothesis boundary.
CLM_V2_006,VERIFIED_COUNTEREXAMPLE,"Without a positive spectral gap, snapping can change by O(1) under perturbations tending to zero.",,test_no_gap_counterexample_has_small_perturbation_but_large_snap_change,CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,artifacts/counterexamples_v2/spectral_gap_sweep.json,fig07_spectral_gap_stability.pdf,Supports fail-closed gap requirement.
CLM_V2_007,VERIFIED_IMPLEMENTATION,"Reference coordinate-loop evaluation, NumPy accelerated evaluation, dense composition, and CP rank-one evaluation agree to floating-point tolerance.",,13 research_v2 tests plus CP parity and five CPU/GPU parity runs,,,tests/research_v2/test_reference_parity.py;tests/research_v2/test_gpu_parity.py,Software evidence only; not mathematical novelty.
CLM_V2_008,VERIFIED_REPRODUCIBILITY,"Every v2 numerical row carries source/config/object/input/seed/bac

## claims/claim_evidence_matrix_v3.csv

claim_id,status,claim_text,theorem_or_proposition_evidence,implementation_evidence,numerical_or_exact_evidence,limitation,release_impact
CLM_V3_001,PROVED_UNDER_ASSUMPTIONS,"The four named root errors obey Pythagorean and reduced/projected identities.",THM_V3_ROOT_ERROR_ORTHOGONALITY,src/seion_core/research_v3/projected_evaluation.py,tests/research_v3/unit/test_evaluation.py,"Finite Hilbert spaces and orthogonal projectors only.",Supports exact semantics
CLM_V3_002,PROVED,"Every node error has an exact nonempty-subset expansion plus its local normal residual.",THM_V3_EXACT_SUBSET_EXPANSION,src/seion_core/research_v3/error_expansion.py,tests/research_v3/symbolic/test_error_expansion.py,"Identity is algebraic and not a sharpness theorem.",Supports all certificates
CLM_V3_003,PROVED_UNDER_ASSUMPTIONS,"Ambient error has universal coefficient k.",THM_V3_HOMOGENEOUS_AMBIENT_K,src/seion_core/research_v3/certificates.py,tests/research_v3/certificates/test_certificates.py,"Fixed-eta optimality remains open.",Upper-bound theorem only
CLM_V3_004,PROVED_UNDER_ASSUMPTIONS,"Projected-root and reduced error have universal coefficient k-1.",THM_V3_PROJECTED_ROOT_K_MINUS_ONE,src/seion_core/research_v3/certificates.py,tests/research_v3/regression/test_projected_k_minus_one.py,"Novelty and fixed-eta sharpness are not established.",Central v3 result pending human review
CLM_V3_005,PROVED_UNDER_ASSUMPTIONS,"A sign-partitioned ratio sort minimizes the declared telescoping certificate.",THM_V3_OPTIMAL_TELESCOPING_ORDER,src/seion_core/research_v3/telescoping_order.py,tests/research_v3/property/test_telescoping_order.py,"Optimizes this scalar upper bound, not fixed-law error.",Algorithmic certificate
CLM_V3_006,PROVED_UNDER_ASSUMPTIONS,"Nodewise mixed-mask and path-sum certificates are computable for typed heterogeneous trees.",THM_V3_NODEWISE_MIXED_CERTIFICATE;THM_V3_NODEWISE_PATH_SUM,src/seion_core/research_v3/certificates.py,tests/research_v3/certificates/test_certificates.py,"Information-optimality is open.",Candidate contribution; novelty fail-closed
CLM_V3_007,CERTIFIED_LOWER_BOUND,"Planar gated rotations provide explicit admissible lower constructions.",,src/seion_core/research_v3/extremizers.py,src/seion_core/research_v3/interval_certification.py,"They do not match every fixed-eta upper bound.",Sharpness evidence only
CLM_V3_008,EMPIRICAL_LOWER_BOUND,"Gradient and derivative-free searches provide empirical lower bounds.",,src/seion_core/research_v3/adversarial_search.py,tests/research_v3/adversarial/test_searches.py,"No global optimality follows from optimizer output.",Numerical diagnostic
CLM_V3_009,PROVED_UNDER_ASSUMPTIONS,"The projected five-input ternary associator has triangle coefficient two.",COR_V3_PROJECTED_TERNARY_ASSOCIATOR_TWO,src/seion_core/research_v3/polynomial_forests.py,tests/research_v3/unit/test_forests_and_cp_budget.py,"Sharp

## claims/claims_registry.yaml

claims:
  - id: DEF_NARY_LAW_V1
    title: Typed finite-dimensional n-ary law
    status: definition
    statement: "A structural tensor K of shape (d_out,d_1,...,d_n) defines an n-linear map with explicit input and output dimensions."
    assumptions: [finite-dimensional coordinate spaces, numeric field]
    evidence: [src/seion_core/algebra/nary_law.py, tests/unit/test_nary_law.py]
  - id: DEF_ASSOCIATOR_CONVENTIONS_V1
    title: Distinct ternary composition conventions
    status: definition
    statement: "The five-input, anchored binary, and operadic partial-composition objects are represented by separate functions and recorded conventions."
    assumptions: [ternary arity for specialized formulas]
    evidence: [src/seion_core/algebra/ternary_law.py, tests/unit/test_associators.py]
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    title: Standard left-action curvature expansion
    status: proved
    statement: "For any bilinear product, [L_x,L_y]-L_[x,y] applied to z equals A(y,x,z)-A(x,y,z), with [x,y]=x circ y-y circ x."
    assumptions: [finite-dimensional bilinear product, stated commutator convention]
    proof: docs/theorems/curvature_associator.md
    symbolic_checks: [artifacts/symbolic/curvature_identity.json]
    counterexamples: [docs/counterexamples/curvature_without_symmetry.md]
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    title: Commuting finite operator descends to cohomology
    status: proved_under_assumptions
    statement: "If a finite operator commutes with the differential, it preserves cycles and boundaries and therefore induces a map on the quotient cohomology space."
    assumptions: [d squared equals zero, same-degree linear operator, exact commutation]
    proof: docs/theorems/cohomology_descent.md
    numerical_checks: [tests/unit/test_cohomology.py]
  - id: NUM_KNOWN_INVARIANT_CLOSURE_V1
    title: Known block subspace closure
    status: numerically_verified
    statement: "For the declared block-supported example, the coordinate projector has zero closure leakage up to floating-point evaluation."
    assumptions: [example definition, finite samples, float64]
    evidence: [experiments/configs/finite_ternary_v1.yaml]
  - id: EMP_PROJECTOR_RECOVERY_V1
    title: Empirical closure-minimizing recovery
    status: empirical
    statement: "A small stochastic Stiefel search can reduce sampled closure leakage on some declared examples; no general recovery or superiority claim is made."
    assumptions: [seed, sample distribution, optimizer steps]
    evidence: [src/seion_core/variational/optimizers.py]
  - id: CONJ_CONTINUUM_LIMIT_V1
    title: Uniform continuum limit for kernel-integrated laws
    status: open
    statement: "A sequence of finite laws may converge in a specified topology under uniform estimates; this repository does not prove a general theorem."
    assumptions: [resoluti

## claims/conjecture_registry.yaml

conjectures:
  - id: CONJ_CLOSURE_RECOVERY
    statement: "Under identifiable spectral separation and adequate sampling, closure-minimizing projectors may recover invariant subspaces more reliably than generic baselines."
    status: CONJECTURE
    blockers: [identifiability, optimizer global behavior, sample complexity]
  - id: CONJ_MULTISCALE_PERSISTENCE
    statement: "Gauge-aligned finite tensor features may persist across a suitable resolution sequence."
    status: CONJECTURE
    blockers: [choice of maps, topology, uniform estimates]



## claims/counterexample_registry.yaml

counterexamples:
  - id: CE_SNAPPING_NO_GAP
    claim: REFUTED_SNAPPING_NO_GAP_V1
    construction: "Diagonal matrices with eigenvalues on opposite sides of 1/2 and arbitrarily small perturbation."
    status: REFUTED
  - id: CE_CURVATURE_NOT_RAW_ASSOCIATOR
    claim: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    construction: "A product with A(y,x,z) nonzero shows standard curvature is a difference of associators, not one raw associator."
    status: REFUTED



## claims/counterexample_registry_v2.yaml

version: 2
scope: "Exact assumption-removal counterexamples for the v2 theorem ledger."
counterexamples:
  - id: CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2
    target: THM_EXACT_TYPED_REDUCTION_V2
    removed_assumption: exact invariance of the selected subspace
    construction: "On R^2 with W=span(e0), mu(e0,e0)=e1 and mu(e1,e0)=e0; the reduced binary law is zero but the ambient partial composition at (e0,e0,e0) equals e0."
    exact_artifact: artifacts/counterexamples_v2/no_invariance_composition.json
    test: tests/research_v2/test_theorem_examples.py
    status: REFUTED_WITHOUT_HYPOTHESIS
  - id: CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2
    target: THM_SPECTRAL_SNAPPING_GAP_V2
    removed_assumption: positive uniform spectral gap around the threshold
    construction: "A_delta=diag(1/2-delta,1/2+delta) and E_delta=diag(2delta,-2delta) swap the snapped coordinate projectors while ||E_delta|| tends to zero."
    exact_artifact: artifacts/counterexamples_v2/spectral_gap_sweep.json
    test: tests/research_v2/test_theorem_examples.py
    status: REFUTED_WITHOUT_HYPOTHESIS
  - id: CE_LEGACY_DUPLICATE_RUNS_NOT_INDEPENDENT_V2
    target: experimental_aggregation
    removed_assumption: independent scientific instances
    construction: "Historical run records share identical experiment/config/seed/precision/backend/device identities and must not be counted as independent observations."
    exact_artifact: artifacts/research_audit/run_deduplication_report.csv
    status: GOVERNANCE_COUNTEREXAMPLE


## claims/novelty_registry.yaml

novelty:
  - area: non-associative algebra
    known_component: associators and non-associative identities
    new_component: none claimed in the definitions
    new_combination: typed computational evidence ledger linking a declared law to reductions
    evidence: docs/prior_art_matrix.md
    references: [Filippov1985, Sabinin1999, MostovoyPerezIzquierdoShestakov2014]
    theorem_level_novelty: none currently claimed
    computational_novelty: convention-aware finite residual evaluation
    limitations: "The repository does not claim a new algebraic identity by renaming these objects."
  - area: operads and polynomial identities
    known_component: algebras over operads and partial compositions
    new_component: explicit finite ternary insertion conventions
    new_combination: composition metadata linked to theorem/evidence records
    evidence: docs/prior_art_matrix.md
    references: [LodayVallette2012]
    theorem_level_novelty: proposed invariant-reduction functoriality, not yet proved
    computational_novelty: typed insertion checks
    limitations: "No novelty is claimed for operadic composition itself."
  - area: structure-preserving model reduction
    known_component: invariant subspaces, PCA, SVD, spectral projectors
    new_component: finite closure-leakage certificate with convention metadata
    new_combination: common artifact contract for algebraic and reduction diagnostics
    evidence: src/seion_core/projectors
    references: [BennerGugercinWillcox2015, ChaturantabutBeattieGugercin2016]
    theorem_level_novelty: explicit approximate-closure bound remains open
    computational_novelty: traceable closure-leakage comparison
    limitations: "Empirical optimizer results are not a superiority theorem."
  - area: tensor decomposition and identifiability
    known_component: CP/Tucker/HOSVD representations and gauge non-uniqueness
    new_component: law-level parity and gauge-alignment evidence
    new_combination: factorization, associator, and reduction provenance
    evidence: src/seion_core/algebra/cp_law.py
    references: [KoldaBader2009, BaderKolda2007, Kruskal1977]
    theorem_level_novelty: none claimed
    computational_novelty: deterministic finite parity and error records
    limitations: "No CP uniqueness or optimal approximation theorem is claimed."
  - area: spectral projector perturbation
    known_component: eigenspace perturbation bounds under spectral separation
    new_component: threshold snapping control and no-gap counterexample
    new_combination: snapping diagnostics attached to reduced-law evidence
    evidence: src/seion_core/projectors/snapping.py
    references: [DavisKahan1970]
    theorem_level_novelty: no new perturbation theorem currently claimed
    computational_novelty: finite positive-gap and zero-gap controls
    limitations: "Observed stability is not a sharp general boun

## claims/prior_art_registry.yaml

version: 1
scope: "Conservative prior-art map for the finite-dimensional structure-preserving reduction v2 track."
novelty_policy:
  - "A standard restriction, identity inheritance, or Davis-Kahan estimate is not a new theorem here."
  - "Terminology and a software implementation do not establish mathematical novelty."
  - "Any future novelty claim must name a theorem-level difference and a primary-source comparison."
entries:
  - id: PA_OPERAD_ALGEBRAS
    area: operads_and_algebras
    source: "Loday and Vallette, Algebraic Operads"
    source_url: "https://doi.org/10.1007/978-3-642-30362-3"
    established_result: "Algebraic operations and their compositions are organized by operads; algebras over an operad satisfy the declared compositional identities."
    closest_known_construction: "Restriction of an algebraic operation to an invariant subspace, expressed through partial compositions."
    exact_overlap: "The exact reduction theorem uses the same composition and identity inheritance mechanism."
    genuine_difference: "This repository gives a finite-dimensional coordinate certificate and tests it against an independent evaluator."
    theorem_level_novelty: "none established"
    computational_novelty: "typed parity and artifact contracts"
    limitation_of_novelty_claim: "No new operad or subalgebra theorem is claimed."
  - id: PA_FILIPPOV
    area: n_ary_and_filippov
    source: "Filippov, n-Lie algebras"
    source_url: "https://doi.org/10.1007/BF00969110"
    established_result: "The n-Lie/Filippov identity defines a class of alternating n-ary algebras."
    closest_known_construction: "Represent the fundamental identity as a signed polynomial in two n-ary operations."
    exact_overlap: "The v2 polynomial residual bookkeeping applies once the same arity and sign convention is encoded."
    genuine_difference: "The software handles generic finite n-linear laws, including laws that are not Filippov algebras."
    theorem_level_novelty: "none established"
    computational_novelty: "explicit convention registry"
    limitation_of_novelty_claim: "No classification, deformation theorem, or new Filippov identity is proved."
  - id: PA_AKIVIS_SABININ
    area: nonassociative_algebra
    source: "Mostovoy, Perez-Izquierdo, and Shestakov, Hopf algebras in non-associative Lie theory"
    source_url: "https://doi.org/10.1007/s13373-013-0049-8"
    established_result: "Akivis and Sabinin structures record nonassociative brackets, associators, and related operations."
    closest_known_construction: "Associator and polynomial identity tracking for a nonassociative product."
    exact_overlap: "The associator is treated as an operadic polynomial of the underlying operation."
    genuine_difference: "The v2 code is a finite tensor verification suite rather than a loop/Hopf-envelope construction."
    theorem_level_novelty: "none es

## claims/prior_art_registry_v3.yaml

version: 3
scope: finite typed multilinear trees with recursive orthogonal projection
search_date: 2026-07-29
policy:
  - Absence from a bounded search is not evidence of novelty.
  - Standard operad semantics, telescoping, and norm products are not claimed as new.
  - Software and exhaustive finite checks cannot establish theorem-level novelty.
entries:
  - id: PA_V3_COLORED_OPERADS
    source: "Yau, Colored Operads"
    source_url: https://doi.org/10.1090/gsm/170
    established_result: Typed operations and rooted-tree partial composition are standard colored-operad semantics.
    exact_overlap: The v3 type grammar and ordered tree model.
    genuine_difference: Orthogonal projection defects and quantitative nodewise certificates are additional analytic data.
    candidate_theorems: [THM_V3_EXACT_SUBSET_EXPANSION]
    novelty_status: STANDARD_RESTRICTION_RESULT
  - id: PA_V3_ALGEBRAIC_OPERADS
    source: "Loday and Vallette, Algebraic Operads"
    source_url: https://doi.org/10.1007/978-3-642-30362-3
    established_result: Treewise composition and polynomial identities for algebras over operads.
    exact_overlap: Signed forests and insertion-tree syntax.
    genuine_difference: Quantitative normal leakage is not the monograph's central problem.
    candidate_theorems: [COR_V3_PROJECTED_TERNARY_ASSOCIATOR_TWO]
    novelty_status: KNOWN_BOUND_NEW_SPECIALIZATION
  - id: PA_V3_APPROXIMATE_HOMOMORPHISMS
    source: "Johnson, Approximately multiplicative maps between Banach algebras"
    source_url: https://doi.org/10.1112/jlms/s2-37.2.294
    established_result: Approximate multiplicativity can imply proximity to exact homomorphisms under Banach-algebra hypotheses.
    exact_overlap: Quantitative stability language for algebraic structure.
    genuine_difference: V3 propagates nodewise normal projection defects on a fixed finite tree rather than correcting a map globally.
    candidate_theorems: [THM_V3_PROJECTED_ROOT_K_MINUS_ONE]
    novelty_status: NOVELTY_NOT_ESTABLISHED
  - id: PA_V3_BACKWARD_ERROR
    source: "Higham, Accuracy and Stability of Numerical Algorithms"
    source_url: https://doi.org/10.1137/1.9780898718027
    established_result: Compositional forward/backward error analysis and order-sensitive arithmetic bounds are standard.
    exact_overlap: Local error propagation and evaluation-order comparisons.
    genuine_difference: Exact multilinear projector residuals and typed tree topology.
    candidate_theorems: [THM_V3_OPTIMAL_TELESCOPING_ORDER, THM_V3_NODEWISE_PATH_SUM]
    novelty_status: KNOWN_BOUND_NEW_SPECIALIZATION
  - id: PA_V3_LAYERED_LIPSCHITZ
    source: "Combettes and Pesquet, Lipschitz Certificates for Layered Network Structures"
    source_url: https://doi.org/10.1137/19M1272780
    established_result: Architecture-sensitive composition can improve products of individual Lipschitz bounds.
    exact_

## claims/scope_registry_v4.yaml

version: 4
canonical_repository: seion-math-core
classes:
  CANONICAL_FINITE_CORE: [src/seion_core, tests, claims, experiments]
  ACTIVE_RESEARCH_TRACK: [papers/tree_stability_v3, artifacts/research_v3]
  SUPPORTING_MATHEMATICS: [foundations, projector_reduction, truncated_cohomology]
  EXTERNAL_APPLICATION: []
  HISTORICAL: [artifacts/checkpoints]
  SUPERSEDED: []
  SPECULATIVE: [claims/conjecture_registry.yaml]
  OUT_OF_SCOPE: [other repositories]


## claims/scope_registry_v4.yaml.json

{
  "branches": {
    "ACTIVE_RESEARCH_TRACK": [
      "research_v3",
      "papers/tree_stability_v3"
    ],
    "CANONICAL_FINITE_CORE": [
      "src/seion_core",
      "tests",
      "claims",
      "experiments"
    ],
    "EXTERNAL_APPLICATION": [],
    "HISTORICAL": [
      "artifacts/checkpoints"
    ],
    "OUT_OF_SCOPE": [
      "other repositories"
    ],
    "SPECULATIVE": [
      "claims/conjecture_registry.yaml"
    ],
    "SUPERSEDED": [],
    "SUPPORTING_MATHEMATICS": [
      "truncated_cohomology",
      "foundations",
      "projector_reduction"
    ]
  },
  "canonical_repository": "seion-math-core",
  "version": 4
}


## claims/theorem_dependency_matrix_v2.csv

theorem_id,kind,depends_on,required_assumptions,proof_or_definition,independent_evidence,cycle_status,epistemic_status,novelty_status
THM_EXACT_TYPED_REDUCTION_V2,theorem,,"finite-dimensional Hilbert spaces; isometric Q; compatible dimensions; exact closure at every node",docs/theorems_v2/exact_reduction.md,tests/research_v2/test_theorem_examples.py;artifacts/symbolic_v2/exact_invariant_reduction.json,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
THM_OPERADIC_IDENTITY_INHERITANCE_V2,theorem,THM_EXACT_TYPED_REDUCTION_V2,"same declared operation and tree convention for every polynomial term",docs/theorems_v2/polynomial_identities.md,tests/research_v2/test_theorem_examples.py,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
THM_APPROXIMATE_TREE_BOUND_V2,theorem,,"bounded n-linear law; uniform closure residual rho; projection at every reduced internal node",docs/theorems_v2/approximate_closure.md,tests/research_v2/test_theorem_examples.py;artifacts/index/bound_tightness_v2.csv,acyclic,PROVED_AUXILIARY,NOT_ESTABLISHED
THM_SPECTRAL_SNAPPING_GAP_V2,theorem,,"Hermitian A and E; threshold 1/2; gap gamma>0; ||E||<=gamma/2",docs/theorems_v2/spectral_snapping.md,tests/research_v2/test_theorem_examples.py;artifacts/counterexamples_v2/spectral_gap_sweep.json,acyclic,ESTABLISHED_KNOWN_RESULT,NOT_CLAIMED
PROP_FINITE_COHOMOLOGY_DESCENT_V2,proposition,,"finite cochain spaces; d^2=0; exact commutation",docs/theorems/cohomology_descent.md,legacy theorem registry,acyclic,PROVED_UNDER_ASSUMPTIONS,SUPPORTING_ONLY
CE_NO_INVARIANCE_BREAKS_COMPOSITION_V2,counterexample,THM_EXACT_TYPED_REDUCTION_V2,"exact invariance removed",claims/counterexample_registry_v2.yaml,tests/research_v2/test_theorem_examples.py,acyclic,REFUTED_WITHOUT_HYPOTHESIS,BOUNDARY_CONTROL
CE_NO_SPECTRAL_GAP_BREAKS_SNAPPING_CONTINUITY_V2,counterexample,THM_SPECTRAL_SNAPPING_GAP_V2,"positive gap removed",claims/counterexample_registry_v2.yaml,tests/research_v2/test_theorem_examples.py,acyclic,REFUTED_WITHOUT_HYPOTHESIS,BOUNDARY_CONTROL


## claims/theorem_dependency_matrix_v3.csv

theorem_id,dependency_id,relation,dependency_status,circular,proof_evidence
THM_V3_ROOT_ERROR_ORTHOGONALITY,DEF_V3_TYPED_TREE_EVALUATIONS,uses typed ambient/projected definitions,DEFINITION,false,docs/theorems_v3/typed_model.md
THM_V3_EXACT_SUBSET_EXPANSION,DEF_V3_TYPED_TREE_EVALUATIONS,expands the recursive node definitions,DEFINITION,false,docs/theorems_v3/exact_subset_expansion.md
THM_V3_HOMOGENEOUS_AMBIENT_K,THM_V3_EXACT_SUBSET_EXPANSION,bounds every exact subset term,PROVED,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_PROJECTED_ROOT_K_MINUS_ONE,THM_V3_EXACT_SUBSET_EXPANSION,projects away the root local residual,PROVED,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_PROJECTED_ROOT_K_MINUS_ONE,THM_V3_ROOT_ERROR_ORTHOGONALITY,identifies projected and reduced root error,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/homogeneous_constants.md
THM_V3_OPTIMAL_TELESCOPING_ORDER,,independent adjacent-exchange theorem,NOT_APPLICABLE,false,docs/theorems_v3/telescoping_order.md
THM_V3_NODEWISE_MIXED_CERTIFICATE,THM_V3_EXACT_SUBSET_EXPANSION,enumerates mixed child-error masks,PROVED,false,docs/theorems_v3/nodewise_certificates.md
THM_V3_NODEWISE_MIXED_CERTIFICATE,THM_V3_OPTIMAL_TELESCOPING_ORDER,uses the optimal scalar order as one sound candidate,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/nodewise_certificates.md
THM_V3_NODEWISE_PATH_SUM,THM_V3_OPTIMAL_TELESCOPING_ORDER,propagates local sources along ordered ancestor paths,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/nodewise_certificates.md
COR_V3_PROJECTED_TERNARY_ASSOCIATOR_TWO,THM_V3_PROJECTED_ROOT_K_MINUS_ONE,applies the k-1 coefficient to two signed two-node trees,PROVED_UNDER_ASSUMPTIONS,false,docs/theorems_v3/signed_forests.md


## claims/theorem_registry.yaml

theorems:
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    statement: "R_standard(x,y)z = A(y,x,z)-A(x,y,z)."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [finite-dimensional bilinear product, stated bracket]
    proof_location: docs/theorems/curvature_associator.md
    symbolic_verification: artifacts/symbolic/curvature_identity.json
    epistemic_status: PROVED
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    statement: "T d = d T implies a well-defined action on finite cohomology."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [d^2=0, degree-preserving T]
    proof_location: docs/theorems/cohomology_descent.md
    symbolic_verification: null
    epistemic_status: PROVED_UNDER_ASSUMPTIONS



## claims/theorem_registry_v2.yaml

version: 2
scope: "Finite-dimensional structure-preserving reduction research track."
novelty_policy: "Standard consequences are registered as such; no submission-ready novelty claim is active."
theorems:
  - id: THM_EXACT_TYPED_REDUCTION_V2
    title: Exact invariant reduction commutes with declared tree composition
    statement: "For an isometric embedding Q and an exactly invariant subspace, Q times the reduced tree evaluation equals the ambient tree evaluation on lifted leaves."
    assumptions:
      - finite-dimensional Hilbert spaces
      - Q*Q = I
      - every law used at an internal node maps the selected subspaces into the selected output subspace
      - declared slot order and compatible dimensions
    proof_location: docs/theorems_v2/exact_reduction.md
    implementation:
      reference: src/seion_core/research_v2/reference.py
      accelerated: src/seion_core/research_v2/accelerated.py
    evidence:
      tests: tests/research_v2/test_reference_parity.py
      artifacts: artifacts/symbolic_v2/exact_invariant_reduction.json
    epistemic_status: ESTABLISHED_KNOWN_RESULT
    novelty_status: NOT_CLAIMED
  - id: THM_OPERADIC_IDENTITY_INHERITANCE_V2
    title: Exact inheritance of declared multilinear polynomial identities
    statement: "Every finite signed polynomial in declared tree compositions vanishing for the ambient law vanishes for the exactly reduced law."
    assumptions:
      - assumptions of THM_EXACT_TYPED_REDUCTION_V2
      - every term uses the same declared operations and convention
    proof_location: docs/theorems_v2/polynomial_identities.md
    implementation: src/seion_core/research_v2/reference.py
    evidence: tests/research_v2/test_theorem_examples.py
    epistemic_status: ESTABLISHED_KNOWN_RESULT
    novelty_status: NOT_CLAIMED
  - id: THM_APPROXIMATE_TREE_BOUND_V2
    title: Explicit approximate-closure tree recurrence
    statement: "For k internal nodes, ||F_T-R_T|| <= k rho M^(k-1) product leaf norms."
    assumptions:
      - finite-dimensional Hilbert space
      - bounded n-linear law with operator norm M
      - uniform closure residual rho for projected inputs
      - every internal output is projected in the reduced evaluation
    proof_location: docs/theorems_v2/approximate_closure.md
    implementation: src/seion_core/research_v2/reference.py
    evidence:
      tests: tests/research_v2/test_theorem_examples.py
      artifacts: artifacts/index/bound_tightness_v2.csv
    epistemic_status: PROVED_AUXILIARY
    novelty_status: NOT_ESTABLISHED
  - id: THM_SPECTRAL_SNAPPING_GAP_V2
    title: Threshold snapping stability under a positive gap
    statement: "For Hermitian threshold snapping with gap gamma and ||E|| <= gamma/2, a conservative Davis-Kahan bound is min(1,4||E||/gamma)."
    assumptions:
      - Hermitian A and E
      - threshold 1/2
      - positive distance gamma from t

## claims/theorem_registry_v3.yaml

version: 3
track: nodewise_tree_constants
governance_note: >-
  Mathematical proofs and deterministic checks are present, but AI output does
  not constitute official theorem approval; independent human review is pending.
theorems:
  - id: THM_V3_ROOT_ERROR_ORTHOGONALITY
    title: Exact orthogonal decomposition of the four named root errors
    statement: "E_amb^2 = E_proj^2 + E_normal^2 and E_red = E_proj."
    scope: [finite typed Hilbert spaces, orthogonal projectors, arbitrary finite typed trees]
    dependencies: [DEF_V3_TYPED_TREE_EVALUATIONS]
    proof_location: docs/theorems_v3/typed_model.md
    implementation: src/seion_core/research_v3/projected_evaluation.py
    tests: [tests/research_v3/unit/test_evaluation.py]
    epistemic_status: PROVED_UNDER_ASSUMPTIONS
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_EXACT_SUBSET_EXPANSION
    title: Exact local child-error subset expansion
    statement: >-
      Delta_v equals the local normal residual plus one multilinear term for
      every nonempty subset of erroneous child branches.
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities]
    dependencies: [DEF_V3_TYPED_TREE_EVALUATIONS]
    proof_location: docs/theorems_v3/exact_subset_expansion.md
    implementation: src/seion_core/research_v3/error_expansion.py
    tests: [tests/research_v3/symbolic/test_error_expansion.py]
    epistemic_status: PROVED
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_HOMOGENEOUS_AMBIENT_K
    title: Universal ambient coefficient k
    statement: "E_amb <= k rho M^(k-1) product_l ||z_l||."
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities, uniform M and rho]
    dependencies: [THM_V3_EXACT_SUBSET_EXPANSION]
    proof_location: docs/theorems_v3/homogeneous_constants.md
    implementation: src/seion_core/research_v3/certificates.py
    tests: [tests/research_v3/certificates/test_certificates.py]
    epistemic_status: PROVED_UNDER_ASSUMPTIONS
    sharpness_status: OPEN_AT_FIXED_ETA
    novelty_status: STANDARD_MULTILINEAR_BOUND
    approval_status: PENDING_HUMAN_REVIEW
  - id: THM_V3_PROJECTED_ROOT_K_MINUS_ONE
    title: Projected-root coefficient k minus one
    statement: "E_proj = E_red <= (k-1) rho M^(k-1) product_l ||z_l||."
    scope: [heterogeneous laws, heterogeneous types, heterogeneous arities, uniform M and rho]
    dependencies: [THM_V3_EXACT_SUBSET_EXPANSION, THM_V3_ROOT_ERROR_ORTHOGONALITY]
    proof_location: docs/theorems_v3/homogeneous_constants.md
    implementation: src/seion_core/research_v3/certificates.py
    tests:
      - tests/research_v3/certificates/test_certificates.py
      - tests/research_v3/regression/test_projected_k_minus_one.py
    epistemic_status: PROVED_UNDER_ASSUMPTIONS
    sharpness_status: CERTIF

## papers/software_v3/README.md

# V3 reproducibility companion

This manuscript documents the typed-tree API, enumerator, evaluators,
certificate engine, exact and empirical optimizer interfaces, run schema,
performance calibration, and one-command rebuild. It does not claim that
software completeness establishes mathematical novelty.

Build both v3 manuscripts:

    .\scripts\build_tree_constants_v3_paper.ps1

Canonical PDF:

    papers/software_v3/build/main.pdf


## papers/software_v3/main.tex

\documentclass[11pt]{amsart}
\input{glyphtounicode}
\pdfgentounicode=1

\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{amsmath,amssymb}
\usepackage{array,booktabs,tabularx}
\usepackage{siunitx}
\usepackage{graphicx}
\usepackage{geometry}
\usepackage{xcolor}
\usepackage{hyperref}
\usepackage{enumitem}
\geometry{margin=1in}
\setlength{\emergencystretch}{3em}
\graphicspath{{../tree_stability_v3/figures/}}
\sisetup{detect-all,group-separator={,},group-minimum-digits=4}
\hypersetup{
  colorlinks=true,
  linkcolor=blue!45!black,
  citecolor=blue!45!black,
  urlcolor=blue!45!black,
  pdftitle={SEION Math Core v3: Typed Tree Certificates and Reproducible Experiments},
  pdfauthor={Eliuth Chavero Jasso},
  pdfsubject={Reproducible software and artifact protocol for finite typed multilinear tree certificates},
  pdfkeywords={research software, typed tree, multilinear tensor, CUDA parity, interval arithmetic, reproducibility}
}
\input{../tree_stability_v3/generated_results}

\title[Typed tree verification software]{SEION Math Core v3: A Reproducible Verification Suite for Typed Multilinear Tree Certificates}
\author{Eliuth Chavero Jasso}
\address{Independent Researcher, Apizaco, Tlaxcala, Mexico}
\thanks{Software/reproducibility companion. Contact metadata and release authorization remain pending author and human-review gates.}
\date{29 July 2026}

\begin{document}

\begin{abstract}
This companion specifies the software and artifact protocol used to evaluate finite typed multilinear composition trees under recursive orthogonal projection.  The implementation separates explicit-coordinate and vectorized NumPy evaluators, a float64 CUDA evaluator, exact ordered-tree enumeration, dynamic-programming certificates, directed interval lower constructions, independent gradient and derivative-free search, signed forests, and CP/projection budgets.  The base registry contains \VThreeScientificInstances{} deduplicated scientific instances, \VThreeTreeOccurrences{} enumerated tree occurrences, and \VThreeLeakageMasks{} exhaustive leakage-mask evaluations; the maximum registered CPU/GPU difference is \VThreeMaxParity{}.  Every run records source, resolved configuration, mathematical-object and input hashes, tensors, hardware, environment, metrics, certificates, logs, and artifact hashes.  The companion documents a resource-gated extended optimizer grid rather than presenting unexecuted seeds as evidence.  It makes no mathematical novelty claim and does not substitute software completeness for independent theorem review.
\end{abstract}

\subjclass[2020]{68N30, 65Y05, 65G50, 15A69}
\keywords{research software, multilinear tensor, typed tree, reproducibility, CUDA parity, interval arithmetic}
\maketitle

\section{Scope and separation from the mathematics paper}

The mathematical manuscript proves finite error identities and upper bounds.

## papers/supplement_v4/main.tex

\documentclass[10pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,booktabs,graphicx,hyperref,xcolor}
\title{SEION Math Core v4 Supplementary Atlas}
\author{Eliuth Chavero Jasso\\Independent Researcher, Apizaco, Tlaxcala, Mexico}
\date{29 July 2026}
\begin{document}\maketitle
\begin{abstract}This atlas records the finite-dimensional evidence, artifact contracts, negative controls, and reproducibility boundaries associated with the canonical SEION Math Core v4 research draft. It is a companion record, not an independent proof of universal or continuum statements.\end{abstract}
\section{Scope and authority}
The mathematical paper separates definitions, conditional results, observed numerical residuals, and unresolved claims. The authority ladder is recorded in \texttt{governance/AUTHORITY\_LADDER.yaml}; the machine graph and source hashes are in \texttt{.ai/machine}.
\section{Canonical artifact map}
\begin{center}\begin{tabular}{ll}\toprule
Artifact family & Authority\\\midrule
Theorem/proof & theorem registry and proof source\\
Executed result & run manifest, metrics, certificate, hashes\\
Experiment design & registered experiment matrix\\
Figure/table & generated output with provenance\\
Release status & independent gate report and human decisions\\\bottomrule
\end{tabular}\end{center}
\section{Required controls}
The registry distinguishes known invariant projectors, random projectors, PCA/SVD, spectral projectors, and closure-minimizing projectors. Exact dense laws and CP rank sweeps are controls; negative spectral-gap controls remain mandatory. Repeated executions are deduplicated by scientific-instance identity and are not counted as independent experiments.
\section{Mathematical blockers}
The v4 program does not silently promote the current tree-level certificates to a universal theorem. Sharpness extremizers, a complete prior-art novelty audit, cancellation-aware FI/GJI/Jacobiator constants, and a full extended optimizer grid remain explicit blockers until independently completed.
\section{Reproducibility manifest}
\begin{verbatim}
python -m pytest -q
python scripts/build_v4_foundation.py
python scripts/seion_campaign_v4.ps1
\end{verbatim}
    The last command is a PowerShell orchestrator; all stages report status and preserve failed evidence.
\section{Selected figures}
Figures are generated from registered v3 runs and copied into the v4 paper tree. Their captions state the metric, seed count, baseline, and limitation. No categorical dtype progression is treated as a continuous variable.
\section{Reviewer checklist}
\begin{itemize}
\item Claims map to theorem, experiment, counterexample, or blocker records.
\item No numerical residual upgrades a claim to \texttt{PROVED}.
\item Tables obey lower/upper and operator/Frobenius metric invariants.
\item PDF and source checksums are emitted by the release 

## papers/tree_stability_v3/README.md

# Nodewise tree-certificate paper

This directory is the mathematical v3 manuscript. Its scope is finite typed
multilinear composition trees, exact local error expansion, nodewise
certificates, the universal ambient coefficient \(k\), the projected-root
coefficient \(k-1\), and conservative sharpness evidence.

Build from the repository root:

    .\scripts\build_tree_constants_v3_paper.ps1

Canonical PDF:

    papers/tree_stability_v3/build/main.pdf

The title deliberately avoids the word “sharp.” Fixed-\(\eta\) optimality,
information-optimality, novelty, extended optimizer completion, and independent
human review remain release-gated.


## papers/tree_stability_v3/generated_results.tex

% Generated by scripts/build_tree_constants_v3_tables.py.
\newcommand{\VThreeScientificInstances}{15{,}493}
\newcommand{\VThreeTreeOccurrences}{81{,}445}
\newcommand{\VThreeUniqueTrees}{80{,}870}
\newcommand{\VThreeLeakageMasks}{1{,}530}
\newcommand{\VThreeExactCells}{60}
\newcommand{\VThreeMaxAbsoluteGap}{\num{32}}
\newcommand{\VThreeMaxRelativeGap}{\num{1}}
\newcommand{\VThreeMaxParity}{\num{1.922e-08}}
\newcommand{\VThreeCoreWallSeconds}{\num{20.62}}
\newcommand{\VThreeExtendedTrajectories}{460{,}800}
\newcommand{\VThreeSourceCommit}{\texttt{b718f4e51785}}
\newcommand{\VThreeFigureCount}{18}
\newcommand{\VThreeTableCount}{16}
\newcommand{\VThreeReleaseStatus}{\texttt{FAIL\_CLOSED\_NOVELTY}}


## papers/tree_stability_v3/tables/topology_statistics.tex

\begin{tabular}{@{}lrrrr@{}}
\toprule
grammar & occurrences & unique hashes & internal nodes & max depth \\
\midrule
binary & 2055 & 2055 & 1--8 & 8 \\
mixed\allowbreak\_2\allowbreak\_3\allowbreak\_4 & 78879 & 78879 & 1--5 & 5 \\
quaternary & 167 & 167 & 1--4 & 4 \\
ternary & 344 & 344 & 1--5 & 5 \\
\bottomrule
\end{tabular}

