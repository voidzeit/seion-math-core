# Deterministic SEION context pack

Task: SEION v4 bugfix context
Category: bugfix
Estimated tokens: 17994/18000

## .ai/KNOWN_BLOCKERS.md

# Known blockers

| ID | Blocker | Impact | Evidence | Resolution condition |
|---|---|---|---|---|
| B-0001 | The current paper's theorem program is too modest for a competitive research paper. | Research-paper release is blocked. | `paper/quality/paper_quality_report.*`, `claims/theorem_registry.yaml` | A nontrivial central theorem is proved with complete assumptions and counterexamples. |
| B-0002 | Historical run indexes contain repeated executions of identical configurations. | Naive aggregate statistics are invalid. | `artifacts/index/run_index.csv` | Use `seion-core governance dedupe-runs` and report unique-instance counts. |
| B-0003 | Several figures are diagnostic or illustrative rather than dense multi-seed experiments. | Quantitative visual claims are limited. | `paper/generated/figures/`, `claims/claims_registry.yaml` | Rebuild figures from registered multi-seed runs with uncertainty and provenance. |
| B-0004 | Author ORCID and contact metadata are not available in the repository. | Submission metadata is incomplete. | `paper/metadata.tex`, `CITATION.cff` | Add verified author metadata explicitly. |

These blockers are not silently downgraded by successful software tests.

## V3 strict-gate blockers

| ID | Blocker | Impact | Evidence | Resolution condition |
|---|---|---|---|---|
| B-0005 | Fixed-eta sharpness is open for several nodewise, associator, FI/GJI, and signed-forest constants. | Sharp/optimal theorem language is blocked. | `claims/theorem_registry_v3.yaml`, `artifacts/index/optimality_gaps_v3.csv` | Supply matching constructions or downgrade every affected claim. |
| B-0006 | The bounded prior-art review does not establi

## docs/incidents/INC-V4-001.md

# INC-V4-001 — table_12_schema

Root cause: schema drift. Regression: table invariant validator. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-002.md

# INC-V4-002 — table_3_telescoping

Root cause: aggregation mismatch. Regression: telescoping identity test. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-003.md

# INC-V4-003 — path_sum_terms

Root cause: abbreviated factors. Regression: full-term symbolic check. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-004.md

# INC-V4-004 — count_ledger

Root cause: duplicate execution rows. Regression: dedupe audit. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-005.md

# INC-V4-005 — exact_near_optimal

Root cause: label ambiguity. Regression: label schema. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-006.md

# INC-V4-006 — bound_direction

Root cause: lower/upper naming. Regression: inequality gate. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-007.md

# INC-V4-007 — dtype_semantics

Root cause: categorical precision plot. Regression: paper claim linter. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-008.md

# INC-V4-008 — operator_frobenius

Root cause: metric conflation. Regression: metric schema. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-009.md

# INC-V4-009 — pdf_type3_unicode

Root cause: font pipeline. Regression: PDF audit. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-010.md

# INC-V4-010 — main_supplement_scope

Root cause: artifact placement. Regression: paper manifest. Status: **repaired**. Eligibility: eligible after rerun. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-011.md

# INC-V4-011 — extended_grid

Root cause: resource budget. Regression: terminal-row gate. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-012.md

# INC-V4-012 — sharpness

Root cause: extremizer unresolved. Regression: counterexample registry. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-013.md

# INC-V4-013 — novelty

Root cause: prior-art audit pending. Regression: primary-source matrix. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## docs/incidents/INC-V4-014.md

# INC-V4-014 — human_review

Root cause: no independent reviewer record. Regression: review packet. Status: **blocked**. Eligibility: not eligible. Historical evidence is preserved; no pass is retroactively rewritten.


## src/seion_core/__init__.py

"""SEION Math Core.

The public API is intentionally finite-dimensional and explicit.  Objects in
this package carry their arity, dimensions, field/dtype, and conventions so
that a certificate can distinguish a definition from an observed residual.
"""

from .algebra.nary_law import NaryLaw, SparseNaryLaw
from .algebra.ternary_law import TernaryLaw
from .algebra.cp_law import CPLaw
from .projectors.projector import Projector

__all__ = ["NaryLaw", "SparseNaryLaw", "TernaryLaw", "CPLaw", "Projector"]
__version__ = "0.1.0"



## src/seion_core/algebra/__init__.py

from .nary_law import NaryLaw, SparseNaryLaw
from .ternary_law import TernaryLaw
from .cp_law import CPLaw
from .typed_law import TypedNaryLaw
from .associators import (
    DefectSummary,
    anchored_associator,
    five_input_associator,
    normalized_defect,
    sample_associator_defect,
)

__all__ = [
    "NaryLaw",
    "SparseNaryLaw",
    "TernaryLaw",
    "CPLaw",
    "TypedNaryLaw",
    "DefectSummary",
    "anchored_associator",
    "five_input_associator",
    "normalized_defect",
    "sample_associator_defect",
]



## src/seion_core/algebra/akivis.py

"""Akivis identity components for a binary product."""

from __future__ import annotations


def associator(product, x, y, z):
    return product(product(x, y), z) - product(x, product(y, z))


def akivis_residual(product, x, y, z):
    bracket = lambda a, b: product(a, b) - product(b, a)
    jac = bracket(x, bracket(y, z)) + bracket(y, bracket(z, x)) + bracket(z, bracket(x, y))
    associator_sum = (
        associator(product, x, y, z)
        + associator(product, y, z, x)
        + associator(product, z, x, y)
        - associator(product, y, x, z)
        - associator(product, z, y, x)
        - associator(product, x, z, y)
    )
    return jac - associator_sum



## src/seion_core/algebra/associators.py

"""Associator conventions, exact contractions, and sampled defect summaries."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np

from ..exceptions import ConventionError
from .nary_law import NaryLaw
from .ternary_law import TernaryLaw


@dataclass
class DefectSummary:
    convention: str
    squared_energy: float
    normalized_defect: float
    samples: int
    seed: int | None
    dtype: str
    exact: bool
    input_distribution: str
    normalization: str

    def to_dict(self) -> dict:
        return asdict(self)


def five_input_associator(law: TernaryLaw, *vectors: np.ndarray) -> np.ndarray:
    if len(vectors) != 5:
        raise ConventionError("five-input ternary associator requires exactly five vectors")
    return law.five_input_associator(*vectors)


def anchored_associator(
    law: TernaryLaw, anchor: np.ndarray, x: np.ndarray, y: np.ndarray, z: np.ndarray
) -> np.ndarray:
    return law.anchored_associator(anchor, x, y, z)


def normalized_defect(residuals: np.ndarray, scales: np.ndarray | None = None, eps: float = 1e-15) -> float:
    residuals = np.asarray(residuals)
    numerator = float(np.mean(np.abs(residuals) ** 2))
    denominator = float(np.mean(np.abs(scales) ** 2)) if scales is not None else 1.0
    return numerator / max(denominator, eps)


def sample_associator_defect(
    law: TernaryLaw,
    convention: str = "five_input",
    samples: int = 128,
    seed: int = 0,
    dtype: str | np.dtype | None = None,
    anchor: np.ndarray | None = None,
    distribution: str = "standard_normal",
) -> DefectSummary:
    if law.input_dims != (law.out

## src/seion_core/algebra/compositions.py

"""Explicit operadic partial compositions."""

from __future__ import annotations

import numpy as np

from ..exceptions import ShapeError
from .nary_law import NaryLaw


def partial_compose(outer: NaryLaw, inner: NaryLaw, slot: int) -> NaryLaw:
    if not 0 <= slot < outer.arity:
        raise ValueError("slot outside outer arity")
    if outer.input_dims[slot] != inner.output_dim:
        raise ShapeError("inner output dimension must equal inserted outer input dimension")
    input_dims = outer.input_dims[:slot] + inner.input_dims + outer.input_dims[slot + 1 :]
    result = np.zeros((outer.output_dim, *input_dims), dtype=np.result_type(outer.tensor, inner.tensor))
    for full_index in np.ndindex(result.shape):
        output_index = full_index[0]
        inner_indices = full_index[1 + slot : 1 + slot + inner.arity]
        outer_inputs = []
        cursor = 1
        for j, dim in enumerate(outer.input_dims):
            if j == slot:
                cursor += inner.arity
                continue
            outer_inputs.append(np.eye(dim, dtype=result.dtype)[full_index[cursor]])
            cursor += 1
        inner_inputs = [np.eye(dim, dtype=result.dtype)[i] for dim, i in zip(inner.input_dims, inner_indices)]
        inserted = inner(*inner_inputs)
        ordered = outer_inputs[:slot] + [inserted] + outer_inputs[slot:]
        result[full_index] = outer(*ordered)[output_index]
    return NaryLaw(result, outer.arity + inner.arity - 1, name=f"{outer.name}_circ_{slot}_{inner.name}")



## src/seion_core/algebra/cp_law.py

"""CP-factorized n-ary laws and explicit gauge handling."""

from __future__ import annotations

from itertools import permutations

import numpy as np

from ..exceptions import ShapeError
from .nary_law import NaryLaw


class CPLaw:
    """Represent ``K = sum_r o_r o a_r^(1) o ... o a_r^(n)``.

    ``output_factor`` has shape ``(d_out, rank)`` and each input factor has
    shape ``(rank, d_i)``.  Weights are stored separately to make gauge tests
    explicit.
    """

    def __init__(
        self,
        output_factor: np.ndarray,
        input_factors: list[np.ndarray] | tuple[np.ndarray, ...],
        weights: np.ndarray | None = None,
        name: str = "cp_law",
    ) -> None:
        self.output_factor = np.asarray(output_factor)
        self.input_factors = [np.asarray(a) for a in input_factors]
        if self.output_factor.ndim != 2 or not self.input_factors:
            raise ShapeError("CP factors must be a 2-D output factor and non-empty input factors")
        self.rank = int(self.output_factor.shape[1])
        self.arity = len(self.input_factors)
        if any(a.shape != (self.rank, a.shape[1]) or a.ndim != 2 for a in self.input_factors):
            raise ShapeError("input factors must have shape (rank, dimension)")
        if weights is None:
            self.weights = np.ones(self.rank, dtype=np.result_type(self.output_factor, *self.input_factors))
        else:
            self.weights = np.asarray(weights)
            if self.weights.shape != (self.rank,):
                raise ShapeError("weights must have shape (rank,)")
        self.name = name

    @property
    def output_dim(self) -> int:
        return int(self.out

## src/seion_core/algebra/filippov.py

"""Filippov fundamental identity evaluator for ternary laws."""

from __future__ import annotations


def fundamental_identity_residual(law, x1, x2, y1, y2, y3):
    lhs = law(x1, x2, law(y1, y2, y3))
    rhs = law(law(x1, x2, y1), y2, y3) + law(y1, law(x1, x2, y2), y3) + law(y1, y2, law(x1, x2, y3))
    return lhs - rhs



## src/seion_core/algebra/gauge.py

"""Gauge utilities for CP representations."""

from .cp_law import CPLaw


def gauge_equivalent(left: CPLaw, right: CPLaw, tolerance: float = 1e-10) -> bool:
    if left.arity != right.arity or left.rank != right.rank:
        return False
    return left.gauge_aligned_distance(right) <= tolerance



## src/seion_core/algebra/jacobi.py

"""Jacobi-type residuals with explicit convention names."""

from __future__ import annotations

import numpy as np


def commutator(product, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    return product(x, y) - product(y, x)


def binary_jacobiator(product, x: np.ndarray, y: np.ndarray, z: np.ndarray) -> np.ndarray:
    bracket = lambda a, b: commutator(product, a, b)
    return bracket(x, bracket(y, z)) + bracket(y, bracket(z, x)) + bracket(z, bracket(x, y))


def generalized_jacobiator_ternary(law, x1, x2, x3, x4, x5) -> np.ndarray:
    """One named GJI variant: cyclic sum of outer slots.

    This is a convention, not a universal synonym for every generalized
    Jacobi identity in the literature.
    """
    return (
        law(law(x1, x2, x3), x4, x5)
        + law(law(x1, x2, x4), x5, x3)
        + law(law(x1, x2, x5), x3, x4)
    )



## src/seion_core/algebra/nary_law.py

"""Finite-dimensional n-linear internal laws."""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Iterable

import numpy as np

from ..exceptions import ShapeError
from .structural_tensor import StructuralTensor


@dataclass
class NaryLaw:
    """An n-linear map represented by a structural tensor.

    Coordinates always use ``K[a, i_1, ..., i_n]`` and vectors are one
    dimensional arrays.  Shape validation is strict by design.
    """

    tensor: np.ndarray
    arity: int
    name: str = "nary_law"

    def __post_init__(self) -> None:
        self.tensor = np.asarray(self.tensor)
        if self.arity < 2:
            raise ValueError("arity must satisfy n >= 2")
        if self.tensor.ndim != self.arity + 1:
            raise ShapeError(
                f"tensor for arity {self.arity} must have rank {self.arity + 1}; "
                f"got shape {self.tensor.shape}"
            )
        if any(d <= 0 for d in self.tensor.shape):
            raise ShapeError("law dimensions must be positive")
        if not np.issubdtype(self.tensor.dtype, np.number):
            raise TypeError("law tensor must have a numeric dtype")

    @classmethod
    def from_tensor(cls, tensor: np.ndarray, arity: int, name: str = "nary_law") -> "NaryLaw":
        return cls(np.asarray(tensor), arity=arity, name=name)

    @property
    def output_dim(self) -> int:
        return int(self.tensor.shape[0])

    @property
    def input_dims(self) -> tuple[int, ...]:
        return tuple(int(x) for x in self.tensor.shape[1:])

    @property
    def dtype(self) -> np.dtype:
        return self.tensor.

## src/seion_core/algebra/structural_tensor.py

"""Dense structural tensors with explicit coordinate conventions."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..exceptions import ShapeError


@dataclass
class StructuralTensor:
    """Tensor with shape ``(output, input_1, ..., input_n)``."""

    data: np.ndarray
    arity: int

    def __post_init__(self) -> None:
        self.data = np.asarray(self.data)
        if self.arity < 2:
            raise ValueError("arity must be at least two")
        if self.data.ndim != self.arity + 1:
            raise ShapeError(
                f"expected rank {self.arity + 1} structural tensor, got {self.data.ndim}"
            )
        if any(dim <= 0 for dim in self.data.shape):
            raise ShapeError("all structural tensor dimensions must be positive")

    @property
    def output_dim(self) -> int:
        return int(self.data.shape[0])

    @property
    def input_dims(self) -> tuple[int, ...]:
        return tuple(int(x) for x in self.data.shape[1:])

    def contract(self, *vectors: np.ndarray) -> np.ndarray:
        if len(vectors) != self.arity:
            raise ShapeError(f"expected {self.arity} vectors, got {len(vectors)}")
        out = self.data
        for axis, vector in enumerate(vectors):
            vec = np.asarray(vector)
            expected = self.input_dims[axis]
            if vec.ndim != 1 or vec.shape[0] != expected:
                raise ShapeError(f"input {axis} must have shape ({expected},), got {vec.shape}")
            out = np.tensordot(out, vec, axes=([1], [0]))
        return np.asarray(out)

    def frobenius_norm(self) -> float:
        return float(np.linalg.n

## src/seion_core/algebra/symmetry.py

"""Symmetry constraints are evaluated separately and never conflated."""

from __future__ import annotations

from itertools import permutations

import numpy as np

from .nary_law import NaryLaw


def permutation_residual(law: NaryLaw, vectors: tuple[np.ndarray, ...], permutation: tuple[int, ...]) -> np.ndarray:
    return law(*vectors) - law(*[vectors[i] for i in permutation])


def symmetry_defect(
    law: NaryLaw, vectors: tuple[np.ndarray, ...], permutations_to_test: list[tuple[int, ...]] | None = None
) -> float:
    if permutations_to_test is None:
        permutations_to_test = list(permutations(range(law.arity)))
    values = [np.linalg.norm(permutation_residual(law, vectors, p)) ** 2 for p in permutations_to_test]
    return float(np.mean(values))


def cyclic_defect(law: NaryLaw, vectors: tuple[np.ndarray, ...]) -> float:
    if law.arity < 2:
        return 0.0
    rotated = vectors[1:] + vectors[:1]
    return float(np.linalg.norm(law(*vectors) - law(*rotated)) ** 2)


def antisymmetry_defect(law: NaryLaw, vectors: tuple[np.ndarray, ...]) -> float:
    if law.arity != 2:
        raise ValueError("antisymmetry_defect currently targets binary laws")
    return float(np.linalg.norm(law(*vectors) + law(vectors[1], vectors[0])) ** 2)


def cyclic_symmetrize(law: NaryLaw) -> NaryLaw:
    if law.arity == 1:
        return law
    tensor = law.tensor.copy()
    result = np.zeros_like(tensor)
    for shift in range(law.arity):
        result += np.transpose(tensor, axes=(0, *([1 + ((i + shift) % law.arity) for i in range(law.arity)])))
    return NaryLaw(result / law.arity, law.arity, name=f"cyclic({law.name})")


def full_symmetrize(law: Na

## src/seion_core/algebra/ternary_law.py

"""Ternary specialization and explicit composition conventions."""

from __future__ import annotations

import numpy as np

from ..exceptions import ConventionError, ShapeError
from .nary_law import NaryLaw


class TernaryLaw(NaryLaw):
    """A law ``mu: V_1 x V_2 x V_3 -> W`` with ternary conventions."""

    def __init__(self, tensor: np.ndarray, name: str = "ternary_law") -> None:
        super().__init__(np.asarray(tensor), arity=3, name=name)

    def astype(self, dtype: np.dtype | str) -> "TernaryLaw":
        return TernaryLaw(self.tensor.astype(dtype), name=self.name)

    def five_input_associator(
        self, x1: np.ndarray, x2: np.ndarray, x3: np.ndarray, x4: np.ndarray, x5: np.ndarray
    ) -> np.ndarray:
        """Return ``mu(mu(x1,x2,x3),x4,x5)-mu(x1,x2,mu(x3,x4,x5))``."""
        if self.input_dims != (self.output_dim,) * 3:
            raise ConventionError("five-input internal associator requires V -> V in every slot")
        return self(self(x1, x2, x3), x4, x5) - self(x1, x2, self(x3, x4, x5))

    def anchored_product(self, anchor: np.ndarray):
        anchor = np.asarray(anchor)
        if self.input_dims[2] != anchor.shape[0] or self.input_dims[:2] != (self.output_dim,) * 2:
            raise ConventionError("anchored binary reduction requires a common internal space")

        def product(x: np.ndarray, y: np.ndarray) -> np.ndarray:
            return self(x, y, anchor)

        return product

    def anchored_associator(
        self, anchor: np.ndarray, x: np.ndarray, y: np.ndarray, z: np.ndarray
    ) -> np.ndarray:
        product = self.anchored_product(anchor)
        return product(product(x, y), z) - product(x,

## src/seion_core/algebra/typed_law.py

"""Multisorted/typed n-ary laws."""

from __future__ import annotations

import numpy as np

from ..typing import VectorSpace
from .nary_law import NaryLaw


class TypedNaryLaw:
    def __init__(
        self, law: NaryLaw, inputs: tuple[VectorSpace, ...], output: VectorSpace
    ) -> None:
        if len(inputs) != law.arity:
            raise ValueError("number of input spaces must equal law arity")
        if tuple(s.dimension for s in inputs) != law.input_dims:
            raise ValueError("input space dimensions do not match law tensor")
        if output.dimension != law.output_dim:
            raise ValueError("output space dimension does not match law tensor")
        self.law = law
        self.inputs = inputs
        self.output = output

    @property
    def arity(self) -> int:
        return self.law.arity

    def __call__(self, *vectors: np.ndarray) -> np.ndarray:
        return self.law(*vectors)



## src/seion_core/canonical/__init__.py

"""Canonical repository operating-system services for SEION Math Core v4."""

from .models import AuthorityLevel, EvidenceEvent, RepositoryState
from .state_machines import TransitionError, transition

__all__ = ["AuthorityLevel", "EvidenceEvent", "RepositoryState", "TransitionError", "transition"]


## src/seion_core/canonical/atomic.py

"""Safe file-backed mutation primitives for canonical repository services."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


class LockError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


class FileLock:
    def __init__(self, path: Path, stale_seconds: int = 3600) -> None:
        self.path = path
        self.stale_seconds = stale_seconds
        self.acquired = False

    def __enter__(self) -> "FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({"pid": os.getpid(), "created_utc": datetime.now(timezone.utc).isoformat()}) + "\n"
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
            self.acquired = True
            return self
        except FileExistsError as exc:
            age = time.time() - self.path.stat().st_mtime if self.path.exists() else 0
            raise LockError(f"Lock exists ({age:.1f}s old): {self.path}") from exc

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        if self.acquired:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
            self.acquired = False


def atomic_write_bytes(path: Path, data: bytes, expected_sha256: str | None =

## src/seion_core/canonical/context_compiler.py

"""Deterministic, explainable task-context compilation."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


TASK_HINTS = {
    "proof": ["claims", "docs/theorems_v3", "papers/tree_stability_v3/proofs", "src/seion_core/research_v3", "tests/research_v3"],
    "experiment": ["experiments", "artifacts/research_v3", "scripts/tree_constants_v3", "src/seion_core/research_v3", "tests/research_v3"],
    "paper": ["papers/tree_stability_v3", "papers/software_v3", "papers/supplement_v4", "claims", "artifacts/qa_v3"],
    "release": ["governance", ".ai", "scripts", ".github", "artifacts/research_v3", "artifacts/release_v4"],
    "bugfix": ["src", "tests", "docs/incidents", ".ai/KNOWN_BLOCKERS.md"],
    "onboarding": ["README.md", ".ai/README.md", "docs/onboarding", "docs/maps", "governance"],
}


def classify_task(task: str) -> str:
    value = task.lower()
    for category, words in {
        "proof": ("proof", "theorem", "lemma", "sharpness"),
        "experiment": ("run", "experiment", "gpu", "optimizer", "matrix"),
        "paper": ("paper", "figure", "table", "latex", "render"),
        "release": ("release", "package", "wheel", "sbom", "security", "ci"),
        "bugfix": ("bug", "fix", "failure", "regression", "inconsistency"),
        "onboarding": ("onboard", "recover", "context", "new agent"),
    }.items():
        if any(word in value for word in words):
            return category
    return "onboarding"


def compile_context(root: Path, task: str, output_dir: Path, token_budget: int = 12000, workstream: str | None = None, extra: list[str] | None = None) -> dict[str, Any]

## src/seion_core/canonical/graph.py

"""Stable repository graph construction and multi-format exports."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable
from xml.etree.ElementTree import Element, SubElement, tostring

import yaml


NODE_TYPES = {
    "mathematics": "MathematicalObject",
    "definition": "Definition",
    "notation": "Notation",
    "assumption": "Assumption",
    "lemma": "Lemma",
    "theorem": "Theorem",
    "corollary": "Corollary",
    "conjecture": "Conjecture",
    "counterexample": "Counterexample",
    "open_problem": "OpenProblem",
    "source": "SourceModule",
    "function": "Function",
    "test": "Test",
    "experiment": "ExperimentPlan",
    "instance": "ScientificInstance",
    "run": "Run",
    "certificate": "Certificate",
    "dataset": "Dataset",
    "figure": "Figure",
    "table": "Table",
    "paper_section": "PaperSection",
    "paper": "Paper",
    "decision": "Decision",
    "risk": "Risk",
    "blocker": "Blocker",
    "task": "Task",
    "release": "Release",
    "agent": "Agent",
    "process": "Process",
    "external": "ExternalApplication",
    "document": "Document",
}


def node_id(kind: str, key: str) -> str:
    return f"{kind.lower()}_{hashlib.sha256(key.encode('utf-8')).hexdigest()[:16]}"


def _node(kind: str, key: str, label: str, path: str = "", **attrs: Any) -> dict[str, Any]:
    return {"id": node_id(kind, key), "type": kind, "key": key, "label": label, "path": path, **attrs}


def _edge(source: str, target: str, relation: str, **attrs: Any) -> dict[str, Any]:
    return {"source": source, "target": target, "type": relation, **attrs}


de

## src/seion_core/canonical/health.py

"""Repository observability metrics; no synthetic aggregate health score."""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def _count(root: Path, relative: str, suffixes: set[str] | None = None) -> int:
    path = root / relative
    if not path.exists():
        return 0
    return sum(1 for item in path.rglob("*") if item.is_file() and (suffixes is None or item.suffix in suffixes))


def collect_health(root: Path) -> dict[str, object]:
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True).splitlines()
    return {
        "schema_version": 1,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd=root, text=True).strip(),
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
        "dirty_path_count": len(status),
        "metrics": {
            "source_file_count": _count(root, "src", {".py"}),
            "test_file_count": _count(root, "tests", {".py"}),
            "docs_file_count": _count(root, "docs"),
            "claim_file_count": _count(root, "claims"),
            "run_directory_count": sum(1 for item in (root / "artifacts" / "runs_v3").glob("*") if item.is_dir()) if (root / "artifacts" / "runs_v3").exists() else 0,
            "context_pack_count": sum(1 for item in (root / ".ai" / "packs").rglob("context_manifest.json")) if (root / ".ai" / "packs").exists() else 0,
            "graph_orphan_count": 0,
            "duplicate_authority_count": 0,
            "failed_ru

## src/seion_core/canonical/models.py

"""Typed, serializable domain records used by the canonical services."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import IntEnum
from typing import Any, Mapping


class AuthorityLevel(IntEnum):
    HUMAN_FORMAL = 0
    EXACT_VALIDATED = 1
    DETERMINISTIC_OBSERVED = 2
    DERIVED = 3
    COMPILED_CONTEXT = 4
    DECLARED_PROPOSED = 5


class EvidenceKind(str):
    PROOF = "proof"
    EXACT_CERTIFICATE = "exact_certificate"
    VALIDATED_INTERVAL = "validated_interval"
    NUMERICAL_RUN = "numerical_run"
    TEST = "test"
    REVIEW = "review"
    DERIVED_TABLE = "derived_table"
    DERIVED_FIGURE = "derived_figure"
    CONTEXT = "context"


@dataclass(frozen=True)
class EvidenceEvent:
    """Append-only event linking a repository action to its authority."""

    event_id: str
    event_type: str
    subject_id: str
    authority_level: int
    actor: str
    status: str
    source_paths: tuple[str, ...] = ()
    artifact_hashes: Mapping[str, str] = field(default_factory=dict)
    timestamp_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["source_paths"] = list(self.source_paths)
        value["authority_level"] = int(self.authority_level)
        return value


@dataclass(frozen=True)
class RepositoryState:
    branch: str
    commit: str
    dirty: bool
    memory_status: str
    graph_status: str
    tests_passed: int
    blockers: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(

## src/seion_core/canonical/security.py

"""Small, deterministic local security and provenance checks."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path


SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*['\"][^'\"]{12,}['\"]"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
]


def scan_secrets(root: Path) -> dict[str, object]:
    findings = []
    for path in root.rglob("*"):
        if not path.is_file() or any(part in {".git", "node_modules", "build", "dist", "__pycache__"} for part in path.parts):
            continue
        if path.suffix.lower() not in {".py", ".yaml", ".yml", ".json", ".md", ".toml", ".ps1", ".sh", ".tex"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for number, line in enumerate(text.splitlines(), 1):
            if any(pattern.search(line) for pattern in SECRET_PATTERNS) and "example" not in path.name.lower() and "placeholder" not in line.lower():
                findings.append({"path": str(path.relative_to(root)), "line": number})
    return {"schema_version": 1, "generated_utc": datetime.now(timezone.utc).isoformat(), "findings": findings, "status": "PASS" if not findings else "BLOCKED_SECRET_FINDINGS"}


def build_sbom(root: Path, output: Path) -> dict[str, object]:
    dependencies = []
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8")
        dependencies = [line.strip().strip('"').strip("'").rstrip(",") for line in text.splitlines() if line.strip().startswith('"') an

## src/seion_core/canonical/services.py

"""Application services for canonical SEION mutations."""

from __future__ import annotations

import hashlib
import json
import uuid
from pathlib import Path
from typing import Any, Mapping

from .atomic import append_jsonl, atomic_write_json, sha256_bytes
from .models import EvidenceEvent, utc_now


class CanonicalServiceError(RuntimeError):
    pass


class CanonicalRepositoryService:
    """The only supported boundary for canonical memory/evidence writes."""

    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.memory = self.root / ".ai"
        self.backups = self.memory / "runtime" / "backups"
        self.ledger = self.root / "claims" / "evidence_ledger.jsonl"
        self.events = self.memory / "evidence" / "ledger.jsonl"

    def _path(self, relative: str | Path) -> Path:
        path = (self.root / relative).resolve()
        if self.root not in path.parents and path != self.root:
            raise CanonicalServiceError(f"Path escapes repository: {relative}")
        return path

    def write_derived_json(self, relative: str | Path, value: Any) -> str:
        path = self._path(relative)
        return atomic_write_json(path, value, backup_dir=self.backups)

    def append_event(self, event: EvidenceEvent) -> str:
        payload = event.to_dict()
        for key in ("event_id", "event_type", "subject_id", "actor", "status"):
            if not payload.get(key):
                raise CanonicalServiceError(f"Missing event field: {key}")
        line_hash = append_jsonl(self.events, payload)
        append_jsonl(self.ledger, {**payload, "ledger_line_hash": line_hash})
        return line_hash

    d

## src/seion_core/canonical/state_machines.py

"""Fail-closed state machines for claims, experiments, development, papers, and releases."""

from __future__ import annotations

from dataclasses import dataclass


class TransitionError(ValueError):
    pass


TRANSITIONS: dict[str, dict[str, set[str]]] = {
    "claim": {
        "PROPOSED": {"FORMALIZED", "OPEN", "SUPERSEDED"},
        "FORMALIZED": {"PRIOR_ART_PENDING", "PROOF_IN_PROGRESS", "OPEN", "SUPERSEDED"},
        "PRIOR_ART_PENDING": {"PROOF_IN_PROGRESS", "OPEN", "SUPERSEDED"},
        "PROOF_IN_PROGRESS": {"PROVED", "PROVED_UNDER_ASSUMPTIONS", "REFUTED", "OPEN", "SUPERSEDED"},
        "PROVED": {"IMPLEMENTED", "HUMAN_REVIEWED", "PAPER_CANDIDATE", "SUPERSEDED"},
        "PROVED_UNDER_ASSUMPTIONS": {"IMPLEMENTED", "HUMAN_REVIEWED", "PAPER_CANDIDATE", "SUPERSEDED"},
        "REFUTED": {"SUPERSEDED", "OPEN"},
        "OPEN": {"FORMALIZED", "PROOF_IN_PROGRESS", "SUPERSEDED"},
        "IMPLEMENTED": {"VERIFIED", "SUPERSEDED"},
        "VERIFIED": {"HUMAN_REVIEWED", "PAPER_CANDIDATE", "SUPERSEDED"},
        "HUMAN_REVIEWED": {"PAPER_CANDIDATE", "PUBLISHED", "SUPERSEDED"},
        "PAPER_CANDIDATE": {"PUBLISHED", "SUPERSEDED"},
        "PUBLISHED": {"SUPERSEDED"},
        "SUPERSEDED": set(),
    },
    "experiment": {
        "PROPOSED": {"ACCEPTED", "ARCHIVED"},
        "ACCEPTED": {"BUDGETED", "ARCHIVED"},
        "BUDGETED": {"QUEUED", "ARCHIVED"},
        "QUEUED": {"RUNNING", "INTERRUPTED", "ARCHIVED"},
        "RUNNING": {"COMPLETE", "COMPLETE_WITH_WARNINGS", "INTERRUPTED", "FAILED_RUNTIME", "FAILED_NUMERICAL_GATE", "FAILED_MATHEMATICAL_GATE"},
        "INTERRUPTED": {"QUEUED", "ARCHIVED"},
        "FAILED_RUNTIME": {"QUEUED", "ARCHIV

## src/seion_core/certification/__init__.py

from .runner import certify_config, run_profile
from .artifact_hashes import hash_artifacts
from .matrix import run_canonical_matrix

__all__ = ["certify_config", "run_profile", "run_canonical_matrix", "hash_artifacts"]


## src/seion_core/certification/artifact_hashes.py

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hash_artifacts(directory: str | Path) -> dict[str, str]:
    directory = Path(directory)
    hashes = {}
    for path in sorted(p for p in directory.rglob("*") if p.is_file() and p.name != "artifact_hashes.json"):
        hashes[str(path.relative_to(directory)).replace("\\", "/")] = hash_file(path)
    (directory / "artifact_hashes.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    return hashes



## src/seion_core/certification/claims.py

from __future__ import annotations

import json
from pathlib import Path

import yaml


ALLOWED_CLAIM_STATUSES = {
    "definition", "proved", "proved_under_assumptions", "symbolically_verified",
    "numerically_verified", "empirical", "heuristic", "conjecture", "open", "refuted", "superseded",
}


def load_yaml_registry(path: str | Path) -> list[dict]:
    value = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if value is None:
        return []
    if isinstance(value, dict) and "claims" in value:
        value = value["claims"]
    if not isinstance(value, list):
        raise ValueError(f"registry {path} must contain a list or claims key")
    for record in value:
        if record.get("status") not in ALLOWED_CLAIM_STATUSES:
            raise ValueError(f"unsupported claim status: {record.get('status')}")
    return value


def claims_lint(repo_root: str | Path) -> dict:
    root = Path(repo_root)
    registry = load_yaml_registry(root / "claims" / "claims_registry.yaml")
    return {"claims": len(registry), "invalid_statuses": [], "passed": True}



## src/seion_core/certification/schemas.py

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CertificateStatus:
    code: str
    reason: str
    epistemic_status: str


VALID_STATUSES = {
    "COMPLETE",
    "COMPLETE_WITH_WARNINGS",
    "FAILED_MATHEMATICAL_GATE",
    "FAILED_NUMERICAL_GATE",
    "FAILED_RUNTIME",
    "INTERRUPTED",
    "RECOVERED",
    "NONCOMPARABLE",
}



## src/seion_core/cli/__init__.py



