# Deterministic SEION context pack

Task: SEION v4 release context
Category: release
Estimated tokens: 17965/18000

## .ai/CURRENT_STATE.md

# Current state

## Observation

- Observed on **2026-07-29** from branch `master` at commit
  `247de089a5fea826fa87f9b9e791c20a5a6fd1b6`.
- The worktree was already dirty before the governance bootstrap. Existing
  generated artifacts, figures, indexes, and `.obsidian/` content are retained
  as user-owned state; this bootstrap must not be attributed to those changes.
- The repository contains typed finite-dimensional algebra modules, claim and
  theorem registries, canonical experiment configurations, run artifacts,
  deterministic generators, and a compiled-paper workflow.

## Scientific status

- The legacy `paper/main.tex` remains a broad finite-dimensional release note;
  its registered formal results are the curvature/associator expansion and
  finite cohomology descent under explicit hypotheses.
- A separate working-paper source now exists at
  `papers/foundations/main.tex`. It states and proves, within the declared
  finite-dimensional hypotheses, exact invariant reduction, a tree-level
  approximate-closure bound, associator stability, and spectral snapping with
  a no-gap counterexample. It is not yet an independently reviewed or
  release-approved mathematical contribution.
- Projector recovery, convergence, precision, and CP results are finite
  numerical observations unless their registry says otherwise.

## Operational status

- The new governance contract is local to this repository.
- Run deduplication and claim/evidence audits are required before release
  claims.
- The paper/software split has independent sources at
  `papers/foundations/main.tex` and `papers/software/main.tex`; both compile
  and render through `scripts/build_companions.ps1`.
- The latest structural audit is yellow and passes only in non-strict mode:
  all required files and run contracts are present, but duplicate historical
  runs and the paper quality flag keep release fail-closed.

## Latest postflight observation

- Obse

## .ai/KNOWN_BLOCKERS.md

# Known blockers

| ID | Blocker | Impact | Evidence | Resolution condition |
|---|---|---|---|---|
| B-0001 | The current paper's theorem program is too modest for a competitive research paper. | Research-paper release is blocked. | `paper/quality/paper_quality_report.*`, `claims/theorem_registry.yaml` | A nontrivial central theorem is proved with complete assumptions and counterexamples. |
| B-0002 | Historical run indexes contain repeated executions of identical configurations. | Naive aggregate statistics are invalid. | `artifacts/index/run_index.csv` | Use `seion-core governance dedupe-runs` and report unique-instance counts. |
| B-0003 | Several figures are diagnostic or illustrative rather than dense multi-seed experiments. | Quantitative visual claims are limited. | `paper/generated/figures/`, `claims/claims_registry.yaml` | Rebuild figures from registered multi-seed runs with uncertainty and provenance. |
| B-0004 | Author ORCID and contact metadata are not available in the repository. | Submission metadata is incomplete. | `paper/metadata.tex`, `CITATION.cff` | Add verified author metadata explicitly. |

These blockers are not silently downgraded by successful software tests.

## V3 strict-gate blockers

| ID | Blocker | Impact | Evidence | Resolution condition |
|---|---|---|---|---|
| B-0005 | Fixed-eta sharpness is open for several nodewise, associator, FI/GJI, and signed-forest constants. | Sharp/optimal theorem language is blocked. | `claims/theorem_registry_v3.yaml`, `artifacts/index/optimality_gaps_v3.csv` | Supply matching constructions or downgrade every affected claim. |
| B-0006 | The bounded prior-art review does not establish theorem-level novelty. | Submission-grade novelty claims are blocked. | `claims/prior_art_registry_v3.yaml`, `docs/prior_art_v3.md` | Independent comprehensive review establishes a genuine difference, or the work remains a draft. |
| B-0007 | Not every declared small 

## .ai/MEMORY_MANIFEST.yaml

version: 4
canonical_scope: C:/Documents/metamaths/seion-math-core
other_repositories: read_only_inspiration
source_of_truth: domain_scoped
required_files:
  - .ai/PROJECT_IDENTITY.md
  - .ai/CURRENT_STATE.md
  - .ai/TASKS.md
  - .ai/KNOWN_BLOCKERS.md
  - .ai/DECISIONS.md
  - .ai/RUN_HISTORY.md
  - governance/AUTHORITY_LADDER.yaml
  - claims/claims_registry.yaml
  - claims/theorem_registry.yaml
  - artifacts/reference_audit/adaptation_matrix.csv
derived_outputs:
  - .ai/machine/repository_graph.json
  - .ai/machine/context_index.json
  - .ai/packs/proof/context.md
  - .ai/packs/experiment/context.md
  - .ai/packs/paper/context.md
  - .ai/packs/release/context.md
integrity: source_hashes_required


## .ai/TASKS.md

# Tasks

## Active

- [x] Connect the exact invariant-subspace reduction theorem draft to the
  v2 theorem/claim registries and reference/accelerated implementations.
- [x] Prove and test the tree-level approximate-closure recurrence for the
  declared projected-evaluation convention.
- [x] Execute five-seed projector, CP, spectral-gap, closure, and CPU/GPU
  parity experiments with registered summaries and tightness ratios.
- [x] Replace the v2 paper figures with registered multi-seed data,
  uncertainty, vector output, and centralized styling.
- [ ] Establish a genuinely new theorem-level contribution beyond the
  standard restriction and perturbation consequences, or keep the work as a
  technical/preprint draft.
- [ ] Obtain verified author email and ORCID metadata.
- [ ] Obtain independent human mathematical and numerical review before any
  submission claim.

## Operational

- [x] Run `seion-core governance audit --strict`; it correctly fails closed
  while scientific warnings remain.
- [x] Review and generate the deduplicated run index before using historical
  aggregates.
- [ ] Fill author contact and ORCID metadata only from an explicit source.

## Completed in this bootstrap

- [x] Establish local governance, memory, lifecycle, authority, and research/
  software split contracts.
- [x] Draft and compile independent mathematical and reproducibility
  manuscripts with vector-capable PDF sources and render checks.
- [x] Expand the prior-art matrix and bibliography with conservative primary
  and official sources.
- [x] Pass the full Python test suite: 39 tests.
- [x] Generate and audit separate v2 foundations/software PDFs, nine vector
  figure pairs, claim/evidence matrices, and adversarial review records.

## V3 nodewise tree constants

- [x] Freeze the pre-v3 state and create the dedicated
  `research/nodewise-tree-constants-v3` branch.
- [x] Implement the typed-tree mathematical kernel and all require

## .ai/CONTEXT_RECOVERY.md

# Context recovery contract

When a session is interrupted, recover in this order:

1. `AGENTS.md` and `governance/PROJECT_MANIFEST.yaml` for scope;
2. `.ai/CURRENT_STATE.md`, `.ai/TASKS.md`, and `.ai/KNOWN_BLOCKERS.md` for
   durable state;
3. `.ai/DECISIONS.md` and `.ai/RISK_REGISTER.md` for constraints;
4. `claims/claims_registry.yaml` and `claims/theorem_registry.yaml` for
   epistemic status;
5. `artifacts/index/governance_audit.json`, if present, for the last structural
   audit;
6. the latest relevant run's `summary.md`, `final_metrics.json`, and
   `artifact_hashes.json`.

Runtime prompts, terminal scrollback, and generated context packs are not
canonical memory. If a fact cannot be recovered from these sources, mark it
unknown and create a blocker rather than guessing.


## .ai/DECISIONS.md

# Decisions

## D-0001 — Keep governance local to SEION Math Core

- **Date:** 2026-07-29
- **Decision:** The other repositories supplied workflow patterns only. No
  governance or integration files are written to them.
- **Reason:** SEION must remain self-contained and reproducible.
- **Evidence:** user scope clarification; `AGENTS.md`.
- **Status:** accepted

## D-0002 — Separate mathematical and software evidence

- **Date:** 2026-07-29
- **Decision:** Mathematical claims live in claims/theorem registries and proof
  files; software/reproducibility claims live in run manifests, schemas, and
  release records.
- **Reason:** A polished runner or artifact ledger cannot substitute for a
  mathematical theorem.
- **Evidence:** `governance/RESEARCH_SOFTWARE_SPLIT.yaml`.
- **Status:** accepted

## D-0003 — Preserve historical runs and deduplicate derived views

- **Date:** 2026-07-29
- **Decision:** Existing run indexes are not rewritten in place. A deterministic
  deduplicated index and audit report are generated alongside them.
- **Reason:** Repeated executions are useful operational history but are not
  independent scientific instances.
- **Evidence:** `artifacts/index/run_index.csv`; `governance/MEMORY_CONTRACT.yaml`.
- **Status:** accepted

## D-0004 — Keep v2 fail-closed until novelty and metadata gates pass

- **Date:** 2026-07-29
- **Decision:** The v2 foundations manuscript is delivered as a rigorously
  scoped draft/not-for-submission artifact, while the software companion is
  the reproducibility output. The strict research audit must remain false
  until a genuinely new theorem and verified author metadata exist.
- **Reason:** Exact invariant restriction, operadic identity inheritance, and
  the spectral gap estimate are standard consequences; a complete numerical
  matrix cannot substitute for theorem-level novelty.
- **Evidence:** `claims/theorem_registry_v2.yaml`,
  `claims/claim_evidence_matrix_v2.c

## .ai/HANDOFF.md

# Handoff

## Resume sequence

1. Read `AGENTS.md`, `.ai/CURRENT_STATE.md`, `.ai/TASKS.md`, and
   `.ai/KNOWN_BLOCKERS.md`.
2. Run `python -m seion_core.cli.main governance context --task "..."`.
3. Inspect the relevant claim/theorem/run registries before editing.
4. Run the smallest relevant test gate.
5. Run governance audit and postflight with exact command and commit details.

## Do not infer

- Do not infer independent experiments from repeated run rows.
- Do not infer theorem novelty from a new name or a generated figure.
- Do not infer current health from a historical pass.
- Do not infer release approval from a green structural audit.

## Latest postflight: governance and manuscript reconstruction

- Timestamp: 2026-07-29T13:02:42.140869+00:00
- Outcome: **tests and PDF builds passed; non-strict audit passed yellow; strict release gate correctly failed closed**
- Validation: 23 tests passed; paper and companion PDF renders passed; audit yellow without errors
- Resume from commit: `247de089a5fea826fa87f9b9e791c20a5a6fd1b6` on `master`
- Limitation: The strict release gate remains blocked by B-0001 through B-0004; no mathematical novelty or universal claim is approved.

## Latest postflight: final verification

- Timestamp: 2026-07-29T13:03:05.869746+00:00
- Outcome: **24 tests passed; audit remains yellow and non-strict pass; release stays fail-closed**
- Validation: python -m pytest -q: 24 passed
- Resume from commit: `247de089a5fea826fa87f9b9e791c20a5a6fd1b6` on `master`
- Limitation: Final audit reports 75 historical runs, 9 unique scientific instances, 8 duplicate groups, and 66 duplicate records.

## Latest postflight: Research v2 structure-preserving reduction and reproducibility split

- Timestamp: 2026-07-29T15:49:15.967635+00:00
- Outcome: **COMPLETE_WITH_SCIENTIFIC_BLOCKERS**
- Validation: 39 pytest tests passed; 180/180 v2 runs complete; 100 unique scientific instances; 60/60 bound rows respect

## .ai/LESSONS.md

# Lessons registry

- Numerical residuals do not upgrade a claim to `PROVED`.
- Repeated runs of one matrix row are executions, not independent scientific instances.
- Generated tables and figures must retain source hashes and a registered run family.
- Human approval is an external decision and cannot be self-issued by automation.


## .ai/MEMORY_GOVERNANCE.md

# Memory governance

Durable memory is a controlled interface between sessions, not a transcript.

## Write rules

- Write only durable conclusions, decisions, blockers, and exact recovery
  instructions.
- Every current-state assertion names when it was observed, how it was checked,
  and what it does not establish.
- Append corrections and mark superseded records; do not erase history.
- Generated context packs and runtime scratch are disposable.
- Claims and theorem status remain in `claims/`; `.ai/` records navigation and
  project state, not mathematical authority.

## Health rule

Memory is healthy only when the manifest, ownership matrix, recovery contract,
and required registries exist and the governance audit can reconstruct the
project state without terminal history.


## .ai/MEMORY_OWNERSHIP_MATRIX.md

# Memory ownership matrix

| Surface | Canonical owner | Agent write mode | Evidence required |
|---|---|---|---|
| Implementation behavior | `src/` and tests | additive code/test change | executed tests |
| Mathematical claim status | `claims/claims_registry.yaml` | explicit registry edit | proof or scoped experiment |
| Theorem dependencies | `claims/theorem_registry.yaml` and generated matrix | registry + generator | proof/counterexample links |
| Experiment design | `experiments/` | registered config/matrix edit | declared hypotheses and controls |
| Run facts | `artifacts/runs/` | runner only | manifest, metrics, certificate, hashes |
| Aggregate indexes | `artifacts/index/` | generator only | source artifacts and command |
| Current project state | `.ai/CURRENT_STATE.md` | postflight/review | command, commit, limitation |
| Decisions | `.ai/DECISIONS.md` | append/supersede | reason and evidence |
| Tasks and blockers | `.ai/TASKS.md`, `.ai/KNOWN_BLOCKERS.md` | explicit planning update | owner/status/resolution condition |
| Paper prose | `paper/` | research-editor workflow | claim mapping and citations |
| Governance policy | `governance/` | explicit policy change | decision record and tests |


## .ai/PROJECT_IDENTITY.md

# Project identity

SEION Math Core is the canonical finite-dimensional mathematical and computational core of the Kernel-Integrated Laws program. The canonical scope is this repository only. Other repositories are read-only inspiration and are never dependencies or edit targets.

Owner: Eliuth Chavero Jasso (identity metadata intentionally remains unverified until supplied by the author).


## .ai/PROJECT_REFERENCE_MANIFEST.yaml

version: 1
project_id: seion-math-core
observed_at: 2026-07-29
observed_by: Codex
observation_command: "git rev-parse HEAD; git branch --show-current; git status --porcelain"
git_commit: 247de089a5fea826fa87f9b9e791c20a5a6fd1b6
branch: master
worktree_state: dirty_before_governance_bootstrap
purpose: >-
  Canonical finite-dimensional environment for defining, proving, testing,
  falsifying, numerically certifying, and documenting the SEION mathematical
  nucleus.
current_release: 0.1.0
mathematical_scope:
  primary: finite-dimensional typed n-ary laws and ternary composition defects
  supporting: projectors, kernels, variational diagnostics, finite cohomology
  excluded_from_core: [KGE, LLM compression, BIM, cosmology, trading, universal physics]
research_tracks:
  mathematical_research:
    source: paper/main.tex
    status: release_note_needing_stronger_central_theorem
  software_reproducibility:
    source: scripts/
    status: executable_finite_dimensional_suite
authority:
  mathematical_status: claims/claims_registry.yaml
  theorem_status: claims/theorem_registry.yaml
  numerical_status: artifacts/runs/**/final_metrics.json
  generated_provenance: artifacts/index/
known_limitations:
  - repeated rows in historical run indexes require deduplication before scientific aggregation
  - current paper has modest theorem depth and must not be represented as a universal theory
  - external author ORCID and contact metadata are not inferred


## .ai/README.md

# SEION durable memory

`.ai/` is the canonical durable memory for the SEION repository. It records
decisions, current state, risks, tasks, handoffs, and the recovery contract. It
does not replace source code, theorem proofs, claim registries, or run
artifacts; it points to them and records their provenance.

The memory tiers are:

- **durable**: the tracked Markdown/YAML files in this directory;
- **evidence**: immutable or append-only records under `claims/` and
  `artifacts/`;
- **derived**: `.ai/machine/` and `.ai/packs/`, rebuildable from canonical
  sources;
- **runtime**: `.ai/runtime/`, disposable and never a source of truth.

Use `seion-core governance context` before work and the postflight contract
after work. Every state assertion must include an observation date, command or
artifact source, commit when available, and a limitation.


## .ai/RISK_REGISTER.md

# Risk register

| ID | Risk | Likelihood | Impact | Control |
|---|---|---:|---:|---|
| R-0001 | Numerical evidence is described as proof. | medium | high | claim-language lint; authority/epistemic separation. |
| R-0002 | Duplicate runs inflate apparent sample size. | high | high | deterministic run deduplication and unique-seed reporting. |
| R-0003 | Generated paper output is edited manually and loses provenance. | medium | high | regenerate tables/figures from artifacts; hash release outputs. |
| R-0004 | Existing dirty artifacts are attributed to a later session. | medium | medium | record baseline commit/worktree state in `.ai/CURRENT_STATE.md`. |
| R-0005 | External applications expand the mathematical scope without proof. | medium | high | scope contract and research/software split. |


## .ai/RUN_HISTORY.md

# Run history

This file is append-only. Each entry must be produced or reviewed after an
executed command and must include command, date, branch, commit, outcome,
changed paths, and limitations. Historical artifact runs remain under
`artifacts/runs/` and are not replaced by this summary.

## 2026-07-29 — governance bootstrap

- Command: repository inventory and governance bootstrap
- Branch/commit: `master` / `247de089a5fea826fa87f9b9e791c20a5a6fd1b6`
- Outcome: local contracts created; verification pending
- Changed paths: `AGENTS.md`, `.ai/`, `governance/`, `schemas/`, `src/seion_core/governance/`, tests and CLI integration
- Limitation: this entry records setup, not a claim that the full test or paper gates passed.

## 2026-07-29T13:02:42.140869+00:00 — governance and manuscript reconstruction

- Command: `python -m pytest -q; scripts/build_paper.ps1; scripts/build_companions.ps1; governance audit --json`
- Branch/commit: `master` / `247de089a5fea826fa87f9b9e791c20a5a6fd1b6`
- Outcome: **tests and PDF builds passed; non-strict audit passed yellow; strict release gate correctly failed closed**
- Summary: Implemented local SEION governance, durable memory, evidence controls, deduplicated run index, theorem-focused research paper, and software reproducibility companion.
- Validation: 23 tests passed; paper and companion PDF renders passed; audit yellow without errors
- Changed files:
  - `papers/foundations/main.tex`
  - `papers/software/main.tex`
  - `scripts/build_companions.ps1`
  - `governance/RESEARCH_SOFTWARE_SPLIT.yaml`
- Limitations:
  - The strict release gate remains blocked by B-0001 through B-0004; no mathematical novelty or universal claim is approved.
  - All external inspiration repositories remain outside the edit scope.

## 2026-07-29T13:03:05.869746+00:00 — final verification

- Command: `python -m pytest -q; python -m seion_core.cli.main governance audit --json`
- Branch/commit: `master` / `2

## .ai/TEST_MATRIX.md

# Test and evidence matrix

| Gate | Command | Evidence output | Authority | Notes |
|---|---|---|---|---|
| Unit/symbolic/numerical | `python -m pytest -q` | pytest output | observed/verified | Must be executed for current status. |
| Claims lint | `python -m seion_core.cli.main audit` | `artifacts/index/claims_report.json` | verified | Registry status and language constraints. |
| Governance audit | `python -m seion_core.cli.main governance audit --strict` | `artifacts/index/governance_audit.json` | verified | Structural and provenance gate. |
| Run deduplication | `python -m seion_core.cli.main governance dedupe-runs` | `artifacts/index/run_index_deduplicated.csv` | observed | Derived view; historical index preserved. |
| Fast profile | `.\scripts\run_fast.ps1` | `artifacts/index/profile_fast.json` | observed | CPU-safe vertical slice. |
| Full profile | `.\scripts\run_full_blackwell.ps1` | profile/matrix artifacts | observed | Hardware fallback must be recorded. |
| Paper build | `.\scripts\build_paper.ps1` | `paper/build/main.pdf` | observed | Compile and log inspection. |
| Render inspection | `python scripts/inspect_paper.py` | `artifacts/paper_render/render_report.json` | observed | Automated gate plus manual review. |
| Release | `.\scripts\release_bundle.ps1` | `artifacts/release/` | approved only after review | Never infer approval from automation. |
| V3 canonical | `.\scripts\run_tree_constants_v3_full.ps1` | `artifacts/research_v3/full_execution_manifest.json` | observed/verified | Exit is nonzero when publication correctly fails closed. |
| V3 tests/CUDA | `python -m pytest -q` | `artifacts/qa_v3/pytest_v3.xml` | verified | Current result: 69 passed, including CUDA parity. |
| V3 exact enumeration | `python scripts/tree_constants_v3_pipeline.py enumerate` | `artifacts/index/tree_instances_v3.parquet` | verified | 81,445 occurrences; 80,870 unique hashes. |
| V3 base matrix | `python scripts/tree_c

## .ai/WORKSTREAMS.md

# Workstreams

## Mathematical research

Owns definitions, theorem statements, proofs, assumptions, counterexamples,
prior-art positioning, and mathematically meaningful experiments. Canonical
surfaces: `src/seion_core/`, `docs/theorems/`, `claims/`, `paper/`.

## Software and reproducibility

Owns schemas, runners, hardware/environment manifests, artifact hashes,
deduplicated run views, generated figures/tables, build scripts, and release
bundles. Canonical surfaces: `schemas/`, `experiments/`, `scripts/`,
`artifacts/`.

## Shared gate

The software workstream can show that a declared computation ran and is
traceable. Only the mathematical workstream can change a theorem's status, and
only an explicit review can approve a release.


## .ai/evidence/README.md

# Governance evidence ledger

`ledger.jsonl` is an append-only operational ledger emitted by the local
governance controls. It records audit and postflight events with authority,
commit, artifacts, and limitations. Mathematical evidence remains in
`claims/evidence_ledger.jsonl`; the two ledgers must not be conflated.


## .ai/machine/artifact_drift.csv

path,status
.ai/machine/repository_graph.json,generated


## .ai/machine/artifact_orphans.csv

artifact,reason
,none detected by scoped graph builder


## .ai/machine/drift_report.json

{
  "schema_version": 1,
  "generated_utc": "2026-07-30T02:45:41.671007+00:00",
  "node_count": 1239,
  "edge_count": 2727,
  "orphan_node_count": 0,
  "duplicate_authority_count": 0,
  "status": "PASS_WITH_SCOPED_GRAPH"
}


## .ai/packs/bugfix/context_manifest.json

{
  "candidate_count": 189,
  "category": "bugfix",
  "estimated_tokens": 17994,
  "schema_version": 1,
  "selected_count": 43,
  "task": "SEION v4 bugfix context",
  "token_budget": 18000,
  "workstream": "bugfix"
}


## .ai/packs/bugfix/source_hashes.json

{
  ".ai/KNOWN_BLOCKERS.md": "670013c5ad5790f8b322be325c05eac7faa3b9e84f40eb166807ee66ee4e7d8c",
  "docs/incidents/INC-V4-001.md": "549a3fa8fff9c6f13348a19c524e2e19395a995b01e4ee0ff5390312d4907e73",
  "docs/incidents/INC-V4-002.md": "bb52c4b3af5e972dc5adec41d6c21f3118ddb9ffd2ece1b5014cfd4a787886ab",
  "docs/incidents/INC-V4-003.md": "e1ea2ca54b19095257ebdff644dd7cee7929fd5e8ba4726ea6c38bc6fb9b9e39",
  "docs/incidents/INC-V4-004.md": "9c7e93b5b154b18862fc8968b45858b7d13071a506f0b0b534c09ecd3ca6d24e",
  "docs/incidents/INC-V4-005.md": "325489c70246882fc9af37ffae9c8e6940d5ffbf9d63b2a0d1c532bfaa2daed7",
  "docs/incidents/INC-V4-006.md": "d18b796794d9499467f50ee60ca1acf7c203c817161147085e639e3088c48d5b",
  "docs/incidents/INC-V4-007.md": "b078c3e166298eef68a0c3c6c6e16a2319443172d3b473dba82c29897cd17f2c",
  "docs/incidents/INC-V4-008.md": "35e13a4ec176e57c55c5061e82f8f6064d24ce8b0bcaf6e58a6eca6e9029e544",
  "docs/incidents/INC-V4-009.md": "4250f606d6ce91d1cb25f65237bf3a715d1d23bac1837e212287859f40334e55",
  "docs/incidents/INC-V4-010.md": "f1030d951b9d9a7243c1328b8179f2ddaab8c66b6140b05c9b5d7badde1edebf",
  "docs/incidents/INC-V4-011.md": "4377c89621d5a1c50528e1108f44238b192323b64a6f4eaec1cf1008d010b665",
  "docs/incidents/INC-V4-012.md": "7a0cc9caae698a3768b5d0a6dfbef8a039c70dabac33cdc8058053c6098f4571",
  "docs/incidents/INC-V4-013.md": "19ff3655368e515e73138a4330067ee18a1d7e81f139ce1778d66a1c91d5b7c6",
  "docs/incidents/INC-V4-014.md": "8762f193c06698595d2245ed7626fc77ef15cc3a276807a9b4020ea94d1db87b",
  "src/seion_core/__init__.py": "60a27ffd5c4dfa22b4fd2d91d1622680b144d52feaef651aff77d41558097976",
  "src/seion_core/algebra/__init__.py": "378d129f569d9edb93a4f274bf458ed09eff99974c4ea366f352e9824f0c9c69",
  "src/seion_core/algebra/akivis.py": "05387b61afa2116156273b08bcd1a99aab140d910b4f852b3e72002610973c31",
  "src/seion_core/algebra/associators.py": "aa2e072450cf3f645e68de3a172946ad0fc9e77a6420e8851e9d1695a7cc73

## .ai/packs/experiment/context_manifest.json

{
  "candidate_count": 78,
  "category": "experiment",
  "estimated_tokens": 17944,
  "schema_version": 1,
  "selected_count": 27,
  "task": "SEION v4 experiment context",
  "token_budget": 18000,
  "workstream": "experiment"
}


## .ai/packs/experiment/source_hashes.json

{
  "artifacts/research_v3/audit_v3.json": "84522548a5241ce7377831223c1620d19b8d2e39ccf05b8be46ce3c72e1340b3",
  "artifacts/research_v3/audit_v3.md": "30a5a8f6e4035093eec382d5cb067183197414b72e25cf1b832e3a2bb3fa8c80",
  "artifacts/research_v3/block_A_summary.json": "d4da4255c88c7011b61f2628c87772fcf66a8c63b104e26a26bfa58d48c14e28",
  "artifacts/research_v3/block_B_summary.json": "17f862574abf3b67d49a307a94eb94e9dcfa226fe94bcb7036139658cef50770",
  "artifacts/research_v3/block_C_summary.json": "bb06fbcba70a69616ccaaff7275582f2173988b5b1864b6ce7e4cd0a211100ad",
  "artifacts/research_v3/block_D_summary.json": "3b34129fb0db9723c5cd41ac18a19202f2339e195b38c423357744a9874cc0fe",
  "artifacts/research_v3/block_E.csv": "de7ce92375342d0a67d7212327f77caebfd0589dfddd8f37b2b6ff5171c1c004",
  "artifacts/research_v3/block_E_summary.json": "193ba51a942ab727fa9c02156de6329a408d8102f5c0afb1b5eef08ef2db0ac5",
  "artifacts/research_v3/block_F.csv": "a75dd32bf649807227a3fd4df0dc10f2f35cff6eef9152e623ba5f471ed6f62f",
  "artifacts/research_v3/block_F_summary.json": "71b0168970d24437bc06cbd4952953ed34baa8f27b5dcee6a4dcc5bf22d24397",
  "artifacts/research_v3/block_G.csv": "b9710157b01eea7a908e3009e89a2cbab3d2e79b9f384f03eebd871431f29eb4",
  "artifacts/research_v3/block_G_summary.json": "1944b9efd252de7ab8e6db211a967233a51dab211b9ee9c363e2c0e321e89419",
  "artifacts/research_v3/block_H_summary.json": "c63cdf359b9c2fa5fb4f19d68d1193d22270ecab03af2320bb77dd3d3beebecb",
  "artifacts/research_v3/block_I.csv": "ec7431cc1c993b084bd8bf7f80a503121f3656f6a79efa670863503cafed5565",
  "artifacts/research_v3/block_I_summary.json": "399dbe56b455b05bf5d65e89a6595174cee7f7ef39c7a0d6805061cd0c1e276d",
  "artifacts/research_v3/computational_scaling.csv": "9cc76a20145b9783380c529a4c664fe9e8bca75d8a9761afe80f8bc518b32266",
  "artifacts/research_v3/computational_scaling_summary.json": "ea56900f2802983f6dc2b76b190e91916927323882ed8dd9846d2f95c7ffe5b7",
  "a

## .ai/packs/onboarding/context_explain.json

{
  "excluded": [],
  "included": [
    {
      "estimated_tokens": 214,
      "included": true,
      "path": ".ai/README.md",
      "reason": "direct task-category match: onboarding",
      "sha256": "c3c253c93e5b43eee00954187b92925a5d4a910841751e629e4a2aedb0bb81c1"
    },
    {
      "estimated_tokens": 1142,
      "included": true,
      "path": "README.md",
      "reason": "direct task-category match: onboarding",
      "sha256": "f210a60ad370e9f7ee05616eb1175f087361ec9cf9a9f941405076d672362027"
    },
    {
      "estimated_tokens": 81,
      "included": true,
      "path": "docs/maps/SEION_STRUCTURE_MAP.md",
      "reason": "within relevant workstream path: docs/maps",
      "sha256": "f8231d7256a807f0be0eeefb2944a4b7e7cfc19151ab42bf1ebebb79262ca859"
    },
    {
      "estimated_tokens": 41,
      "included": true,
      "path": "docs/maps/agent_map.md",
      "reason": "within relevant workstream path: docs/maps",
      "sha256": "9391f55aa8557493076a8d8421749dc435233443f0ce754151bd760853567385"
    },
    {
      "estimated_tokens": 44,
      "included": true,
      "path": "docs/maps/artifact_map.md",
      "reason": "within relevant workstream path: docs/maps",
      "sha256": "0fc48ee05ce612a89a3425d309d08978e0a0fb055fe2623c54c77c2f34cc7f51"
    },
    {
      "estimated_tokens": 47,
      "included": true,
      "path": "docs/maps/authority_map.md",
      "reason": "within relevant workstream path: docs/maps",
      "sha256": "c3572af8edfe5d2573da8e53c25b940b9a2ca38f06d5c7addb8a91f80a23cac3"
    },
    {
      "estimated_tokens": 46,
      "included": true,
      "path": "docs/maps/claim_map.md",
      "reason": "within relevant workstream path: docs/maps",
      "sha256": "c9fb14e09d31f220065d5ac12a15eeb1c9f94b8a024b9c5d239d025acd0534ae"
    },
    {
      "estimated_tokens": 44,
      "included": true,
      "path": "docs/maps/experiment_map.md",
      "reason": "within relevant workstream path: 

## .ai/packs/onboarding/context_manifest.json

{
  "candidate_count": 39,
  "category": "onboarding",
  "estimated_tokens": 6834,
  "schema_version": 1,
  "selected_count": 39,
  "task": "SEION v4 onboarding context",
  "token_budget": 18000,
  "workstream": "onboarding"
}


## .ai/packs/onboarding/source_hashes.json

{
  ".ai/README.md": "c3c253c93e5b43eee00954187b92925a5d4a910841751e629e4a2aedb0bb81c1",
  "README.md": "f210a60ad370e9f7ee05616eb1175f087361ec9cf9a9f941405076d672362027",
  "docs/maps/SEION_STRUCTURE_MAP.md": "f8231d7256a807f0be0eeefb2944a4b7e7cfc19151ab42bf1ebebb79262ca859",
  "docs/maps/agent_map.md": "9391f55aa8557493076a8d8421749dc435233443f0ce754151bd760853567385",
  "docs/maps/artifact_map.md": "0fc48ee05ce612a89a3425d309d08978e0a0fb055fe2623c54c77c2f34cc7f51",
  "docs/maps/authority_map.md": "c3572af8edfe5d2573da8e53c25b940b9a2ca38f06d5c7addb8a91f80a23cac3",
  "docs/maps/claim_map.md": "c9fb14e09d31f220065d5ac12a15eeb1c9f94b8a024b9c5d239d025acd0534ae",
  "docs/maps/experiment_map.md": "a29cd1425b36dec468cf172714974cd6332ffca0c6b424e663d456fc421c7548",
  "docs/maps/memory_map.md": "c1e5718edfda599003975e0b77d97f55e150ff1d71146b16627bd46de575aa92",
  "docs/maps/paper_map.md": "37e0dc3bbbb51f63c1a1e9c4f1f8883c0cb3fad78b5c706395924cdbf08c3035",
  "docs/maps/release_map.md": "01e01e7b6f80bcbce15810937a9f8861db2eed21340b4d4b04315fe2de2fd037",
  "docs/maps/repository_map.md": "2f6088a36c4d2d735b4b23e345bd0f9c7a3fc6cf4c8bb771a1553245ec9cafff",
  "governance/ACTION_POLICY.yaml": "6028c5b5c5b960d2820f6f931be141002341e16b53feab43ebbef7af7ee8b18d",
  "governance/AUTHORITY_LADDER.yaml": "50d8985dfc1c3d3c9779ca5f2e2fc9eaa058159ff0f3155f9b42827b31236a30",
  "governance/BRANCH_PR_RELEASE_STANDARD.md": "5b83b554d1ea800862b366c60bd33404a4b646d1df7b81134a9063fbe5c67844",
  "governance/DEFINITION_OF_DONE.yaml": "448a81a8ae45300848b44e00c31ba4ff5640de389e8cbc29af33bc3f139df36d",
  "governance/DEVELOPMENT_LIFECYCLE.md": "e1f1ff9eee980b4a7ee0e91fd9837b94ea11c0934f36f6246381651d3c2a1450",
  "governance/DEVELOPMENT_LIFECYCLE.yaml": "4a28edb4ad83d047ed519368dc35eb935143517e42706092d6b6b6c5a1b8b226",
  "governance/MEMORY_CONTRACT.yaml": "2b0112ea94822ffb6bdfba75bdb507bf9b84a52ad2fe479ac2856bc8f9d20e50",
  "governance/PROJECT_MANIF

## .ai/packs/paper/context_manifest.json

{
  "candidate_count": 44,
  "category": "paper",
  "estimated_tokens": 17999,
  "schema_version": 1,
  "selected_count": 25,
  "task": "SEION v4 paper context",
  "token_budget": 18000,
  "workstream": "paper"
}


## .ai/packs/paper/source_hashes.json

{
  "artifacts/qa_v3/hardware_v3.json": "f3cde80f0e0a01d69e4d276811f983d5f83c2d07973c11e374843e3f0a44e9a1",
  "artifacts/qa_v3/pdf_manifest_v3.json": "bb0f271762708a3993118bb72c5228e672a1097040773ea0af1169d9030efdd5",
  "artifacts/qa_v3/visual_inspection_v3.json": "1c4defcc6bf0b8ad997268b9dd6ff59cf593c5e8370d0294670f3821af1a3a13",
  "claims/claim_evidence_matrix_v2.csv": "751b77fe16de8b4f7db88b67b0a548f9ac774dd68fca0c80a20132efdcf2a9ec",
  "claims/claim_evidence_matrix_v3.csv": "ed144d9479e573be1e24380b6a2a9dae84f575f32084ca14c551b0bd08d18c83",
  "claims/claims_registry.yaml": "2971f8ec5a8444153c3c81f70d76fb04fd25d3259c5eecc4b40549a38ecc1d0d",
  "claims/conjecture_registry.yaml": "96845e35bfbc7ad1f685c634c215a9d9e0864c0c435ae32a3927cd6de15a0523",
  "claims/counterexample_registry.yaml": "49da5c9720d8b3de44326767cd58c55b0f81e86acb6be58b42b31d15e90c4861",
  "claims/counterexample_registry_v2.yaml": "d67988c7fca7ca69c1798fe86e31337cbcb57b6595b06783c6f8fd98acc514d0",
  "claims/novelty_registry.yaml": "e7528db465bf765f702700134dc6eddf8bc296e2ed7a94797fe36b0a62995c72",
  "claims/prior_art_registry.yaml": "70bb9d4948faada7b289e188f4e57af519fffa8ebd886204f3be3a6397b00cae",
  "claims/prior_art_registry_v3.yaml": "f2285cc17c6982097c1165dc6290ef9b83aee605e4992dbd7bca9c7569f59c9c",
  "claims/scope_registry_v4.yaml": "4cdda0dc582f72f9fbf24dee73140d8ebf9c96010368d4d2181251ccb0b35174",
  "claims/scope_registry_v4.yaml.json": "7322f52abfb0379bdbd84fa3fea3a70d6ebdcc95b3d8d46555aaa9fbc06f21ee",
  "claims/theorem_dependency_matrix_v2.csv": "71c360dd020a72b47e9dffec9b835e643645f7d832cd3fec1e70a86abfdb69ae",
  "claims/theorem_dependency_matrix_v3.csv": "f57db210f795b71d5fabe42d312206a11e2e3557cd90ca8eef38e8d4e546ee8b",
  "claims/theorem_registry.yaml": "65679b142226de3252678806650dbefc1949cda9c4246d50e093616b73341ec1",
  "claims/theorem_registry_v2.yaml": "445a2467148d8f5aa3c2038e82938b77090b94d2631aa80fc3da4072902a32fe",
  "claims/

## .ai/packs/proof/context_manifest.json

{
  "candidate_count": 57,
  "category": "proof",
  "estimated_tokens": 17856,
  "schema_version": 1,
  "selected_count": 27,
  "task": "SEION v4 proof context",
  "token_budget": 18000,
  "workstream": "proof"
}


## .ai/packs/proof/source_hashes.json

{
  "claims/claim_evidence_matrix_v2.csv": "751b77fe16de8b4f7db88b67b0a548f9ac774dd68fca0c80a20132efdcf2a9ec",
  "claims/claim_evidence_matrix_v3.csv": "ed144d9479e573be1e24380b6a2a9dae84f575f32084ca14c551b0bd08d18c83",
  "claims/claims_registry.yaml": "2971f8ec5a8444153c3c81f70d76fb04fd25d3259c5eecc4b40549a38ecc1d0d",
  "claims/conjecture_registry.yaml": "96845e35bfbc7ad1f685c634c215a9d9e0864c0c435ae32a3927cd6de15a0523",
  "claims/counterexample_registry.yaml": "49da5c9720d8b3de44326767cd58c55b0f81e86acb6be58b42b31d15e90c4861",
  "claims/counterexample_registry_v2.yaml": "d67988c7fca7ca69c1798fe86e31337cbcb57b6595b06783c6f8fd98acc514d0",
  "claims/novelty_registry.yaml": "e7528db465bf765f702700134dc6eddf8bc296e2ed7a94797fe36b0a62995c72",
  "claims/prior_art_registry.yaml": "70bb9d4948faada7b289e188f4e57af519fffa8ebd886204f3be3a6397b00cae",
  "claims/prior_art_registry_v3.yaml": "f2285cc17c6982097c1165dc6290ef9b83aee605e4992dbd7bca9c7569f59c9c",
  "claims/scope_registry_v4.yaml": "4cdda0dc582f72f9fbf24dee73140d8ebf9c96010368d4d2181251ccb0b35174",
  "claims/scope_registry_v4.yaml.json": "7322f52abfb0379bdbd84fa3fea3a70d6ebdcc95b3d8d46555aaa9fbc06f21ee",
  "claims/theorem_dependency_matrix_v2.csv": "71c360dd020a72b47e9dffec9b835e643645f7d832cd3fec1e70a86abfdb69ae",
  "claims/theorem_dependency_matrix_v3.csv": "f57db210f795b71d5fabe42d312206a11e2e3557cd90ca8eef38e8d4e546ee8b",
  "claims/theorem_registry.yaml": "65679b142226de3252678806650dbefc1949cda9c4246d50e093616b73341ec1",
  "claims/theorem_registry_v2.yaml": "445a2467148d8f5aa3c2038e82938b77090b94d2631aa80fc3da4072902a32fe",
  "claims/theorem_registry_v3.yaml": "e19e321ac851a3d474867526c8e1bb2377efe55901ac1a721547d4a504f188c5",
  "docs/theorems_v3/README.md": "42997fff3f1cbc996d438718a8d55f877e2e169be33b4e39d83af6fe96f0fce1",
  "docs/theorems_v3/cp_projection_budget.md": "1d69797e9acc9ad236dadb4893a83681ac7bf6123512212650f491aa01093a72",
  "docs/theorems_v3/ex

## .ai/packs/release/context_manifest.json

{
  "candidate_count": 170,
  "category": "release",
  "estimated_tokens": 17992,
  "schema_version": 1,
  "selected_count": 36,
  "task": "SEION v4 release context",
  "token_budget": 18000,
  "workstream": "release"
}


## .github/ISSUE_TEMPLATE/research-question.md

---
name: Research question
about: Propose a falsifiable mathematical or computational question
---

## Question

## Exact object and convention

## Hypotheses

## Expected positive and negative controls

## Epistemic status



## .github/pull_request_template.md

## Scientific integrity checklist

- [ ] Mathematical definitions and type signatures are explicit.
- [ ] Claim statuses are updated.
- [ ] Numerical results include seed, dtype, normalization, and assumptions.
- [ ] Failed or negative controls are preserved.
- [ ] Tests and generated artifacts were regenerated.
- [ ] No numerical observation is described as a proof.



## .github/workflows/canonical-v4.yml

name: seion-canonical-v4
on: [push, pull_request]
jobs:
  governance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: '3.11'}
      - run: python -m pip install -e '.[test]'
      - run: python -m pytest -q
      - run: python scripts/build_v4_foundation.py
      - run: python scripts/audit_v4.py
      - run: python scripts/build_docs_v4.py
  packaging:
    runs-on: ubuntu-latest
    needs: governance
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: '3.11'}
      - run: python -m pip install build
      - run: python -m build


## .github/workflows/docs.yml

name: docs
on:
  push:
    branches: [main]
  workflow_dispatch:
jobs:
  docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m pip install mkdocs
      - run: mkdocs build --strict


