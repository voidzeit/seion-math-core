# Deterministic SEION context pack

Task: SEION v4 experiment context
Category: experiment
Estimated tokens: 17944/18000

## artifacts/research_v3/audit_v3.json

{
  "branch": "research/nodewise-tree-constants-v3",
  "commit": "91025b9dd1fbdc7348454f26d7af64adac9889a1",
  "data": {
    "block_counts": {
      "A": 4185,
      "B": 2880,
      "C": 3456,
      "D": 4320,
      "E": 96,
      "F": 24,
      "G": 28,
      "H": 480,
      "I": 24
    },
    "duplicate_scientific_hashes": 0,
    "expected_block_counts": {
      "A": 4185,
      "B": 2880,
      "C": 3456,
      "D": 4320,
      "E": 96,
      "F": 24,
      "G": 28,
      "H": 480,
      "I": 24
    },
    "failure_rows": 0,
    "leakage_masks": 1530,
    "maximum_certified_relative_gap": 1.0,
    "maximum_cpu_gpu_parity": 1.922112502494855e-08,
    "maximum_near_optimal_relative_gap": 8.333334022836425e-11,
    "negative_bound_violation_margins": {
      "bound_violation_margin": 0
    },
    "pass": true,
    "scientific_instances": 15493,
    "tree_occurrences": 81445,
    "unique_scientific_hashes": 15493,
    "unique_tree_hashes": 80870
  },
  "dependency_audit": {
    "cycles": [],
    "pass": true,
    "theorems": 8,
    "unknown_dependencies": []
  },
  "generated_utc": "2026-07-29T18:19:32.190335+00:00",
  "labels": {
    "duplicates": [],
    "label_count": 51,
    "pass": true
  },
  "latex": {
    "mathematical_paper": {
      "critical_overfull_boxes": [],
      "exists": true,
      "missing_inputs": [],
      "multiply_defined_labels": [],
      "overfull_boxes_pt": [],
      "pass": true,
      "path": "papers\\tree_stability_v3\\build\\main.log",
      "undefined_references_or_citations": []
    },
    "software_companion": {
      "critical_overfull_boxes": [],
      "exists": true,
      "missing_inputs": [],
      "multiply_defined_labels": [],
      "overfull_boxes_pt": [],
      "pass": true,
      "path": "papers\\software_v3\\build\\main.log",
      "undefined_references_or_citations": []
    }
  },
  "manifest_integrity": {
    "checked_outputs": 69,
    "failures": [],
    "pass": true
  },
  "missing_required_files": [],
  "pass": true,
  "pdf": {
    "current_hashes": {
      "mathematical_paper": "c67106c478e660741c1ac71d2fadc31ef270636141e36e5732896ce8533574eb",
      "software_companion": "6a4bdce3b504bf244b9514c7bcc76aa5b0aa6d84f78cb96b41803405417837b3"
    },
    "manifest": "artifacts\\qa_v3\\pdf_manifest_v3.json",
    "pass": true,
    "rendered_hashes": {
      "mathematical_paper": "c67106c478e660741c1ac71d2fadc31ef270636141e36e5732896ce8533574eb",
      "software_companion": "6a4bdce3b504bf244b9514c7bcc76aa5b0aa6d84f78cb96b41803405417837b3"
    },
    "visual_inspection": "artifacts\\qa_v3\\visual_inspection_v3.json"
  },
  "pytest": {
    "errors": 0,
    "exists": true,
    "

## artifacts/research_v3/audit_v3.md

# V3 technical audit

- Generated: 2026-07-29T18:19:32.190335+00:00
- Branch: research/nodewise-tree-constants-v3
- Commit: 91025b9dd1fbdc7348454f26d7af64adac9889a1
- Tests: 69
- Scientific instances: 15,493
- Tree occurrences: 81,445
- Validated run artifact sets: 22
- PDF/render/visual QA: PASS
- Overall technical audit: PASS

A technical pass does not establish novelty or authorize publication.


## artifacts/research_v3/block_A_summary.json

{
  "certified_lower_bounds": 4185,
  "certified_upper_bounds": 4185,
  "elapsed_seconds": 0.37491899996530265,
  "exact_zero_projected_cases": 30,
  "maximum_construction_to_upper_ratio": 1.0,
  "maximum_relative_gap": 1.0,
  "minimum_relative_gap": 0.0,
  "scientific_instances": 4185,
  "status": "COMPLETE",
  "tree_shapes": 93
}


## artifacts/research_v3/block_B_summary.json

{
  "block": "B",
  "scientific_instances": 2880,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_BASE_INSTANCE": 2880
  },
  "unique_instance_hashes": 2880
}


## artifacts/research_v3/block_C_summary.json

{
  "block": "C",
  "scientific_instances": 3456,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_BASE_INSTANCE": 3456
  },
  "unique_instance_hashes": 3456
}


## artifacts/research_v3/block_D_summary.json

{
  "block": "D",
  "scientific_instances": 4320,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_CERTIFICATE_INSTANCE": 4320
  },
  "unique_instance_hashes": 4320
}


## artifacts/research_v3/block_E.csv

block,type_count,arity_kind,internal_nodes,dimension_profile,rank_profile,control,scientific_instance_hash,tree_hash,validation,invalid_rejected_before_evaluation,seed_count_required,status
E,2,binary,3,"(2, 9)","(1, 4)",valid,288e5fb0715d4968ecf2393dbd10b6045217f0b3b417c7daa655c27f4e44e423,f2c2d920f41ed73393e06578a53b2b9da69b7f60c0ba38d04b0d97db94436948,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,binary,3,"(2, 9)","(1, 4)",invalid_edge,851018de987c55298fc5a2b2316abb44b7b1bebe12cd1ef29701b108a00942be,5710374a0a18c0db1febbc4bfe6ed452eec42be5d8d71ba64c0bd038702ef89a,REJECTED,True,0,VERIFIED_NEGATIVE_CONTROL
E,2,binary,6,"(2, 9)","(1, 4)",valid,1d9f96b8b6462f65bee44f5a764ebcc2a46e6faa25e3f0eac7982509bb849727,f0cc62058880e61c2c9a23f16f918a1b77cc06d22725ec984d121c4bc4b74106,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,binary,6,"(2, 9)","(1, 4)",invalid_edge,66680abb5f73b16c6084938c4797c208e92f34a24e4f7158c8e40c1bb4e22bf5,23456b7c9ffe593ee78f6c4d55921b975e3bda8d3ed48717040a86286529fe07,REJECTED,True,0,VERIFIED_NEGATIVE_CONTROL
E,2,binary,10,"(3, 10)","(1, 4)",valid,8ac73a20312807b670116c2827b2175999db057f7eb6435ab88dce30e063af8d,09e62d5f905e1e96441e30d04bd6bdddfcacc812e3f43ee89640b04cf85df000,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,binary,10,"(3, 10)","(1, 4)",invalid_edge,587625b9d08e6aff98924b91ee3703dc0459464df9778414efee0d3e7162601a,5c9814c2351c562fae18f0ae0ceaa2c8557b54e8f4fb310b328808fa5ace3448,REJECTED,True,0,VERIFIED_NEGATIVE_CONTROL
E,2,binary,16,"(3, 10)","(1, 4)",valid,f2784ed26b35d5fd1c8c63bcda8a9708f60e0f7428b175dd9e5dd8d1601785e6,4f5b9fdbb6dd278a07fa59a78e3138a1a7c8258af7f4ae3ab3c9b1605eb28cda,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,binary,16,"(3, 10)","(1, 4)",invalid_edge,d3c436c6430bfc24d593d11bbbd1612d5d94081e9f833c25c7d171bd482d6166,a130f129b923bc40e434edca8bd07bc29e3c6f72c33741632c7fe9ba45ad90cd,REJECTED,True,0,VERIFIED_NEGATIVE_CONTROL
E,2,ternary,3,"(2, 9)","(1, 4)",valid,6049ab90d40d04bbf2b574e38457ab3120f0d2ca9c1e9fa9c121d838cb179f47,9a3c0747819d764a9e6d7278048c5d7362aa978199453f2f4beaae7f929a54f0,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,ternary,3,"(2, 9)","(1, 4)",invalid_edge,c037d903db54de02eeda4916f17791e773993ed242be083adc69f0364d566e10,3cc968a7d8fea5227f4fc0f32441ef34ef7a506e71f9c34eedf8824cde3e13f0,REJECTED,True,0,VERIFIED_NEGATIVE_CONTROL
E,2,ternary,6,"(2, 9)","(1, 4)",valid,b6a5bbcdbd30667a7af7f155d1dfbfb595713dd2b0629facf9654e2f0d9de5ef,9a33bdcf0815eee69c74bda7a0bdbc1ebca4c5d02996ab5a538e438d9fbb311d,ACCEPTED,False,10,COMPLETE_TYPE_VALIDATION
E,2,ternary,6,"(2, 9)","(1, 4)",invalid_edge,7c75e31d7b58ea44f6b6302f34926ca87940722bde1597c062fc1ed7d1e5262d,d09b3e85b6a1c7e

## artifacts/research_v3/block_E_summary.json

{
  "block": "E",
  "scientific_instances": 96,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_TYPE_VALIDATION": 48,
    "VERIFIED_NEGATIVE_CONTROL": 48
  },
  "unique_instance_hashes": 96
}


## artifacts/research_v3/block_F.csv

block,internal_nodes,topology,eta,scientific_instance_hash,tree_hash,leakage_masks_executed,full_mask_projected_error,full_mask_ambient_error,sum_main_effects,sum_shapley,shapley_efficiency_residual,maximum_abs_pair_interaction,constructive_alignment,status
F,1,comb,0.1,5191796560cdc62a11a778ccddfe1cac22d60bbc7c153144449bd76dd9cbcb83,d753d020b326b296e24952e6449780937680175dff21ff3dab522f77b2d923ea,2,0.0,0.1,0.0,0.0,0.0,0.0,False,COMPLETE_ALL_LEAKAGE_MASKS
F,1,balanced,0.1,d0cf7d4bd81ce10d234e93dceb504e5c80b27eb2b65bf4fcb2de909c0b37503b,d753d020b326b296e24952e6449780937680175dff21ff3dab522f77b2d923ea,2,0.0,0.1,0.0,0.0,0.0,0.0,False,COMPLETE_ALL_LEAKAGE_MASKS
F,1,two_branch,0.1,d23149fb4a0c6ca6a4667d5d4e52fe183fa210bba0ed7d801335ba6cb234104a,d753d020b326b296e24952e6449780937680175dff21ff3dab522f77b2d923ea,2,0.0,0.1,0.0,0.0,0.0,0.0,False,COMPLETE_ALL_LEAKAGE_MASKS
F,2,comb,0.1,9cf7d8991672d6b8ce47982ca3a01979f9b5dab4f57e3eeb687944cdca608abb,e5568d69ce97d8e31cac256c37711124b90f1898ab444ad4714384d02c31f5da,4,0.010000000000000009,0.19924858845171275,0.0,0.010000000000000009,0.0,0.010000000000000009,False,COMPLETE_ALL_LEAKAGE_MASKS
F,2,balanced,0.1,2f36da1da4fd67c5d3b54771cca9788d9f9ef4a50c7ccf870aa7000362ac8dcf,e5568d69ce97d8e31cac256c37711124b90f1898ab444ad4714384d02c31f5da,4,0.010000000000000009,0.19924858845171275,0.0,0.010000000000000009,0.0,0.010000000000000009,False,COMPLETE_ALL_LEAKAGE_MASKS
F,2,two_branch,0.1,46c3031b7e3274198657ef4b9ab692c198e23024a4384b0390277f451f0e6ed1,a24dc0857504ae86635ee7d90963f7984987f7d6225182502c6f1cce8f466647,4,0.0,0.099498743710662,0.0,0.0,0.0,0.0,False,COMPLETE_ALL_LEAKAGE_MASKS
F,3,comb,0.1,aa6563beb2d87dfcbd79c30686e1cf101eeca431b623140e542c35dd760a16b6,038a9ec6f7cd5df5184b943fec3ad730920441b925da19ac30283a904b9ff2b9,8,0.02984962311319861,0.29750126050153136,0.0,0.02984962311319861,0.0,0.010000000000000009,False,COMPLETE_ALL_LEAKAGE_MASKS
F,3,balanced,0.1,2d585e2cb25b3bce896b9727c8ef5e9f8ddb901f7e428851252b13b9014cc227,f77fcc8e56b0d33238e712f1f870fcdb828dd685b804622ef1bf7414de093c28,8,0.009949874371066203,0.19824984237068136,0.0,0.009949874371066201,1.734723475976807e-18,0.010000000000000009,False,COMPLETE_ALL_LEAKAGE_MASKS
F,3,two_branch,0.1,a4b9e287879295e46370451fa6e807dfa607bac7db969fb00fbc9b9a4ebd104c,f77fcc8e56b0d33238e712f1f870fcdb828dd685b804622ef1bf7414de093c28,8,0.009949874371066203,0.19824984237068136,0.0,0.009949874371066201,1.734723475976807e-18,0.010000000000000009,False,COMPLETE_ALL_LEAKAGE_MASKS
F,4,comb,0.1,46333b4e7e331c1ccb66c0a9cd2a45ce0f67e510c506f7e24127752f39656d78,da2fc02433f7988217c90dcd14662d3166942b3408905a7affb0b4eb34db7263,16,0.05929999999999991,0.394517236

## artifacts/research_v3/block_F_summary.json

{
  "block": "F",
  "scientific_instances": 24,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_ALL_LEAKAGE_MASKS": 24
  },
  "unique_instance_hashes": 24
}


## artifacts/research_v3/block_G.csv

block,expression,eta,scientific_instance_hash,triangle_upper,syntactic_cancellation_upper,observed_constant,observed_over_triangle,gradient_adversarial_constant,derivative_free_constant,certified_small_case_constant,optimizer_seeds_required,optimizer_status,status
G,five_input_ternary_associator,0.0001,6455432a2ede2b4e7880153e5305b503d41c84733f51e8d9c56945f9167a4c34,2.0,2.0,0.00010000000050247593,5.0000000251237964e-05,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,five_input_ternary_associator,0.01,9bb007d4e5a2076ccbb514122403961b9ef8850072c0ca4c769d2b305852bc02,2.0,2.0,0.009999999999998899,0.004999999999999449,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,five_input_ternary_associator,0.1,f433d3e9d43b74d1f98be846a2f6bea18020983e6c9d4cd5ad52db28d1e3211d,2.0,2.0,0.10000000000000009,0.050000000000000044,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,five_input_ternary_associator,0.5,7605778e45f6d3751b82d21e36d5fc1257bc5303fa265db6f9b61941ef2ea465,2.0,2.0,0.5,0.25,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,all_ternary_insertions,0.0001,add553a4161750e68a4970c7391f89e4539cf4d45c4c580d8ef6046f1e2aac48,2.0,2.0,0.00010000000050247593,5.0000000251237964e-05,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,all_ternary_insertions,0.01,823102e929418d7145de704966ce35cc80656ba55c09b1411baba4a6f2bc7519,2.0,2.0,0.009999999999998899,0.004999999999999449,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,all_ternary_insertions,0.1,d3fe56e1d150821449a8425901d9920cdf18f9dc2f805edfe2f2b81b6f9b6042,2.0,2.0,0.10000000000000009,0.050000000000000044,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,all_ternary_insertions,0.5,53c289909688600657df451412972ab4d3a5f4a6d571f16295988d4c36cefbe3,2.0,2.0,0.5,0.25,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,anchored_associator,0.0001,a87e551974a8965421899a6e473ad76590283dced65c6b0e1c1a45d47d41ec93,2.0,2.0,0.00010000000050247593,5.0000000251237964e-05,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,anchored_associator,0.01,2bda9a28c100420ef3ea859cc30fb27f40f83bbb9ab93058d99a8e01e72e5f85,2.0,2.0,0.009999999999998899,0.004999999999999449,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,anchored_associator,0.1,7737552e1decaa47aff8497dbf3dbab621efe18ed7d751ac7dac8c70372a2d69,2.0,2.0,0.10000000000000009,0.050000000000000044,,,,20,EXTENDED_PENDING_RESOURCE_GATE,COMPLETE_REGISTERED_FOREST_EVALUATION
G,anchored_associa

## artifacts/research_v3/block_G_summary.json

{
  "block": "G",
  "scientific_instances": 28,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_REGISTERED_FOREST_EVALUATION": 28
  },
  "unique_instance_hashes": 28
}


## artifacts/research_v3/block_H_summary.json

{
  "block": "H",
  "scientific_instances": 480,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_ANALYTIC_CP_BUDGET": 480
  },
  "unique_instance_hashes": 480
}


## artifacts/research_v3/block_I.csv

block,precision,case,scientific_instance_hash,field,eta,projected_error,residual,backward_error,condition_estimate,optimizer_stability,bound_violation_margin,cpu_gpu_parity,seed_count_required,status
I,float32,small_exact,f1138dda7f447fbd27bd4effb09817b397c1339aa209834ae559fb8259686720,real,0.1,0.05930000069946617,6.994662626880199e-10,6.994662626880199e-10,10.0,,0.24069999930053387,1.120220038952624e-08,10,COMPLETE_PRECISION_INSTANCE
I,float32,ill_conditioned,3d46f0b28a1850e8f36ee0e1d089359a6d9e9f788fa302e878ef26c149b235a8,real,1e-08,6.661338147750939e-16,0.0,0.0,100000000.0,,2.999999933386619e-08,0.0,10,COMPLETE_PRECISION_INSTANCE
I,float32,near_bound,84501c7335b343f6c35793ad302988b9ad7175b44707648491b678399ba42725,real,0.001,5.999993847871643e-06,8.47877323906232e-13,8.47877323906232e-13,1000.0,,0.0029940000061521284,1.3642420526593924e-12,10,COMPLETE_PRECISION_INSTANCE
I,float32,optimizer_stability,464dbab32a63eac9b38c663e03857b173236fa89c49644f75a6f5d7ba8411d01,real,0.5,1.0624999596164795,4.0383520527598193e-08,3.8008019320092415e-08,2.0,,0.4375000403835205,1.922112502494855e-08,10,COMPLETE_PRECISION_INSTANCE
I,float64,small_exact,8b968826b7cf2f3cbbaaabccfd8511863fe2e9d615e123055a858edc2698749a,real,0.1,0.05929999999999991,0.0,0.0,10.0,,0.24070000000000014,0.0,10,COMPLETE_PRECISION_INSTANCE
I,float64,ill_conditioned,cb6d55416674a8b9b6668eb9173059725f6ddf68c3a3f0372393b2ac50b3704e,real,1e-08,6.661338147750939e-16,0.0,0.0,100000000.0,,2.999999933386619e-08,0.0,10,COMPLETE_PRECISION_INSTANCE
I,float64,near_bound,9fee9a56283b685c1a21abc02fd57e554b4d15f77626f879dce0c23be33ccf09,real,0.001,5.999992999994319e-06,0.0,0.0,1000.0,,0.0029940000070000057,0.0,10,COMPLETE_PRECISION_INSTANCE
I,float64,optimizer_stability,ba3864b10c4301e500ca77074e3985a37894d819931873da1b453a72e48f934d,real,0.5,1.0625,0.0,0.0,2.0,,0.4375,0.0,10,COMPLETE_PRECISION_INSTANCE
I,complex64,small_exact,244cf4e82570d63a19bc9f55466067d9635dbef7555755f0c536f55712c86498,complex,0.1,0.05930000069946617,6.994662626880199e-10,6.994662626880199e-10,10.0,,0.24069999930053387,1.120220038952624e-08,10,COMPLETE_PRECISION_INSTANCE
I,complex64,ill_conditioned,7f448a45dc254282b9cfa4902869f3dee1f524a1ae309afe3f8d85a511fdf3d3,complex,1e-08,6.661338147750939e-16,0.0,0.0,100000000.0,,2.999999933386619e-08,0.0,10,COMPLETE_PRECISION_INSTANCE
I,complex64,near_bound,639a06826de2c8745583e94eea492f003da6eec23dc3fcaceed5e5046c8c9661,complex,0.001,5.999993847871643e-06,8.47877323906232e-13,8.47877323906232e-13,1000.0,,0.0029940000061521284,1.3642420526593924e-12,10,COMPLETE_PRECISION_INSTANCE
I,complex64,optimizer_stability,2eaf4fd87cff428f47d98e0ad74733c027a337bc518412ac5ba238b3

## artifacts/research_v3/block_I_summary.json

{
  "block": "I",
  "scientific_instances": 24,
  "status": "COMPLETE",
  "status_counts": {
    "COMPLETE_PRECISION_INSTANCE": 24
  },
  "unique_instance_hashes": 24
}


## artifacts/research_v3/computational_scaling.csv

backend,internal_nodes,arity,dimension,calls_per_repeat,repeats,median_seconds_per_tree,minimum_seconds_per_tree,maximum_seconds_per_tree,throughput_internal_nodes_per_second,peak_traced_ram_bytes,peak_vram_bytes,max_abs_difference_to_numpy,scientific_instance_hash,status
reference_python,1,2,2,30,5,0.00013353999820537866,0.00012453333280670146,0.00014666999923065304,7488.393091499401,36846,0,0.0,dac81f92569bcf4c5b67438f76ddf4a4ec253276fc34ba004859757cff28a4de,COMPLETE
numpy_cpu,1,2,2,30,5,0.00023243000032380223,0.00020332666657244165,0.0002597499988041818,4302.370600210312,39042,0,0.0,75eea041a4167c01984af988a2651dc118d03c0b0d5551c334f98407b3789f5a,COMPLETE
torch_cuda,1,2,2,30,5,0.00037257333363716804,0.00027045666744622093,0.0005039199992703894,2684.0353555036063,36222,33608704,0.0,48b892ee0832d2a52a6a791d94c73eecb4d8598a13528a7d21c020b6af4e7df3,COMPLETE
reference_python,2,2,2,30,5,0.00024519333383068445,0.00023560333453739684,0.0002553833338121573,8156.828608485245,45600,0,0.0,19171ba9998a6617252502db7bf965f4f663deeea564355ebff9c8731d880483,COMPLETE
numpy_cpu,2,2,2,30,5,0.0004784999997355044,0.00044744666665792466,0.0005000999992868552,4179.728319969739,50818,0,0.0,a37ce93bf6144be3e131ffbf78763739303e58d7b65b16c61965425b73e33a9f,COMPLETE
torch_cuda,2,2,2,30,5,0.0005345433329542478,0.0005009299997861187,0.000787679998514553,3741.51144856049,39720,33629696,0.0,4777d341440cac7a8743f20d16cf5c69399363ac27bab14137b3768936a4edfe,COMPLETE
reference_python,4,2,2,30,5,0.0005151266658989091,0.0004787266661878675,0.0005358100015049179,7765.080444864757,66832,0,0.0,202f31d58ed641611192b7e29961ae5c345ba4ef8bb9c2163a80e4b4bba8629c,COMPLETE
numpy_cpu,4,2,2,30,5,0.0008879299993471552,0.0008816133330886562,0.0009711366670671851,4504.859620624345,78658,0,0.0,289206c6e156852e3d2a424c785c5d973d12780ce8e8c8fc817c975b87eaefdb,COMPLETE
torch_cuda,4,2,2,30,5,0.0009720266660830627,0.0008081300009507685,0.0010424600002200653,4115.113442431206,45477,33669632,0.0,55b29237e44a97ab0bd44bb19c400b65ea64748d7205e20114d0a6ace5794770,COMPLETE
reference_python,8,2,2,15,5,0.001124626665841788,0.001001266665601482,0.001223746663890779,7113.471735095277,61696,0,0.0,7ec3e1d3b10583ee2ee116ff54b308b145d63ed96bf3159cf13abe49afb218ba,COMPLETE
numpy_cpu,8,2,2,15,5,0.0021564599980289736,0.001988919998984784,0.002368373334563027,3709.783630260743,74426,0,0.0,a3c7d247e944145e44af6e1727487cff3950f749a8a464a7b5886992a625622e,COMPLETE
torch_cuda,8,2,2,15,5,0.0021077200033081073,0.0020481266702214876,0.0023210200015455484,3795.5705631885853,35308,33707008,0.0,983722a95df012a4ea3c767ce63039b62470e3564c058b4bb3944ce2f2730d7a,COMPLETE
reference_python,12,2,2,15,5,0.00169

## artifacts/research_v3/computational_scaling_summary.json

{
  "backends": [
    "numpy_cpu",
    "reference_python",
    "torch_cuda"
  ],
  "csv_sha256": "9cc76a20145b9783380c529a4c664fe9e8bca75d8a9761afe80f8bc518b32266",
  "maximum_parity_error": 0.0,
  "maximum_peak_vram_bytes": 33757184,
  "rows": 15,
  "run_dir": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_scaling_88168e081820b588",
  "status": "COMPLETE"
}


## artifacts/research_v3/extended_optimizer_results_v3.csv

scientific_instance_hash,tree_hash,arity,internal_nodes,topology,eta,projected_upper,seed,restart,trajectory_id,stage,required_optimizer,status,empirical_lower_bound,certified_upper_bound,lower_to_upper_ratio,bound_violation_margin,optimizer,device,adam_steps,lbfgs_steps,wall_seconds,generated_utc,source_commit,epistemic_status
c17856b0c38e6a14b1634dcfa13d17fecba317a99711612bd2236f7f6a312e5c,771118e22e38c17b89fe5c2b9baa6acbc7633d8cd36ec18b1b27af704494ecb8,2,2,left_comb,1e-08,1.0,0,2,4614f7bbed1c5dc6a8e6f61634060a1940ac79e541541e32b7c83a1f69797a08,extended,Adam_then_LBFGS,COMPLETE,0.9999863962091299,1.0,0.9999863962091299,1.3603790870120314e-05,multistart Adam + L-BFGS,cuda,10,3,0.031538199982605875,2026-07-29T18:04:51.028585+00:00,cde6f3b345727e1d4cf9fb9ab50c8a5d05e20a26,EMPIRICAL_LOWER_BOUND
c17856b0c38e6a14b1634dcfa13d17fecba317a99711612bd2236f7f6a312e5c,771118e22e38c17b89fe5c2b9baa6acbc7633d8cd36ec18b1b27af704494ecb8,2,2,left_comb,1e-08,1.0,0,1,749ec1dea5425e9f50d810853f42883ec889e83e8b52a1f156b0031775793936,extended,Adam_then_LBFGS,COMPLETE,0.9999079954226294,1.0,0.9999079954226294,9.200457737057466e-05,multistart Adam + L-BFGS,cuda,10,3,0.0503943000221625,2026-07-29T18:04:50.966115+00:00,cde6f3b345727e1d4cf9fb9ab50c8a5d05e20a26,EMPIRICAL_LOWER_BOUND
c17856b0c38e6a14b1634dcfa13d17fecba317a99711612bd2236f7f6a312e5c,771118e22e38c17b89fe5c2b9baa6acbc7633d8cd36ec18b1b27af704494ecb8,2,2,left_comb,1e-08,1.0,0,0,be3cdd5b180c3c3e7e575c25ec383c1b69ed079c18facac780f61d751cffd979,extended,Adam_then_LBFGS,COMPLETE,0.9779867858028513,1.0,0.9779867858028513,0.022013214197148745,multistart Adam + L-BFGS,cuda,10,3,7.429452399956062,2026-07-29T18:04:50.884770+00:00,cde6f3b345727e1d4cf9fb9ab50c8a5d05e20a26,EMPIRICAL_LOWER_BOUND
c17856b0c38e6a14b1634dcfa13d17fecba317a99711612bd2236f7f6a312e5c,771118e22e38c17b89fe5c2b9baa6acbc7633d8cd36ec18b1b27af704494ecb8,2,2,left_comb,1e-08,1.0,0,3,e7ec4383e5b227f898ea1ea727df31cfb49eb719f5e79bae1e4780aba39245b5,extended,Adam_then_LBFGS,COMPLETE,0.9382533107111894,1.0,0.9382533107111894,0.06174668928881055,multistart Adam + L-BFGS,cuda,10,3,0.029662900022231042,2026-07-29T18:04:51.088986+00:00,cde6f3b345727e1d4cf9fb9ab50c8a5d05e20a26,EMPIRICAL_LOWER_BOUND


## artifacts/research_v3/extended_progress_v3.json

{
  "epistemic_note": "Completed optimizer trajectories are empirical lower bounds only; pending trajectories cannot support optimality or release claims.",
  "generated_utc": "2026-07-29T18:12:40.551467+00:00",
  "optimizer": {
    "completed_trajectories": 4,
    "completion_fraction": 8.680555555555556e-06,
    "failed_trajectories": 0,
    "pending_trajectories": 460796,
    "requested_trajectories": 460800,
    "results": "artifacts\\research_v3\\extended_optimizer_results_v3.parquet",
    "schedule": "artifacts\\research_v3\\extended_optimizer_schedule_v3.parquet"
  },
  "performance": {
    "completed_extended_instances": 0,
    "pending_extended_instances": 8400,
    "registered_calibration_cells": 15,
    "requested_scientific_instances": 8400,
    "schedule": "artifacts\\research_v3\\extended_performance_schedule_v3.parquet"
  },
  "release_status": "EXTENDED_PENDING_RESOURCE_GATE",
  "resource_gate": "TRIGGERED",
  "schema_version": 3,
  "source_commit": "b718f4e5178590d1f8b6a090fb696545eb3bfcd4"
}


## artifacts/research_v3/extended_progress_v3.md

# V3 extended execution status

- Source commit: b718f4e5178590d1f8b6a090fb696545eb3bfcd4
- Optimizer trajectories requested: **460,800**
- Optimizer trajectories completed: **4**
- Optimizer trajectories pending: **460,796**
- Optimizer failures: **0**
- Performance cells requested: **8,400**
- Registered benchmark calibration cells: **15**
- Release status: EXTENDED_PENDING_RESOURCE_GATE

The schedule is complete and resumable. Pending execution remains a release blocker; it is not silently sampled or relabeled as exhaustive.


## artifacts/research_v3/final_report_v3.json

{
  "associator_constant": "projected triangle coefficient 2; sharpness open",
  "base_wall_seconds": 20.619369499967434,
  "branch": "research/nodewise-tree-constants-v3",
  "certified_lower_bound_rows": 9945,
  "certified_upper_bound_rows": 9945,
  "commit": "91025b9dd1fbdc7348454f26d7af64adac9889a1",
  "cpu_gpu_parity": 1.922112502494855e-08,
  "exact_atlas_rows": 4185,
  "exact_cases_certified_global": 60,
  "fi_gji_constants": [
    {
      "expression": "five_input_ternary_associator",
      "observed_constant": 0.00010000000050247593,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "five_input_ternary_associator",
      "observed_constant": 0.009999999999998899,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "five_input_ternary_associator",
      "observed_constant": 0.10000000000000009,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "five_input_ternary_associator",
      "observed_constant": 0.5,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "all_ternary_insertions",
      "observed_constant": 0.00010000000050247593,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "all_ternary_insertions",
      "observed_constant": 0.009999999999998899,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "all_ternary_insertions",
      "observed_constant": 0.10000000000000009,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "all_ternary_insertions",
      "observed_constant": 0.5,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "anchored_associator",
      "observed_constant": 0.00010000000050247593,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "anchored_associator",
      "observed_constant": 0.009999999999998899,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "anchored_associator",
      "observed_constant": 0.10000000000000009,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "anchored_associator",
      "observed_constant": 0.5,
      "syntactic_cancellation_upper": 2.0,
      "triangle_upper": 2.0
    },
    {
      "expression": "jacobiator_variants",
      "observed_constant": 0.0,
      "syntactic_cancellation_u

## artifacts/research_v3/final_report_v3.md

# V3 final execution report

- Branch: research/nodewise-tree-constants-v3
- Commit: 91025b9dd1fbdc7348454f26d7af64adac9889a1
- Worktree: dirty
- Tests passed: 69
- Tree occurrences: 81,445
- Unique mathematical tree hashes: 80,870
- Scientific instances: 15,493
- Exact atlas rows: 4,185
- Independently global-certified atlas rows: 60
- Extended trajectories: 4 / 460,800
- Maximum CPU/GPU discrepancy: 1.922112502494855e-08
- Main mathematical-paper pages: 31
- Release gate: **FAIL_CLOSED_NOVELTY**

The complete technical research draft was generated. Submission is not authorized while the strict blockers remain.


## artifacts/research_v3/full_execution_manifest.json

{
  "block_counts": {
    "A": 4185,
    "B": 2880,
    "C": 3456,
    "D": 4320,
    "E": 96,
    "F": 24,
    "G": 28,
    "H": 480,
    "I": 24
  },
  "blocks_complete": [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I"
  ],
  "enumerated_tree_shapes": 81445,
  "full_core_base_matrix_status": "COMPLETE",
  "leakage_masks_executed": 1530,
  "maximum_cpu_gpu_parity_error": 1.922112502494855e-08,
  "maximum_lower_to_projected_upper_ratio": 1.0,
  "optimizer_grid_status": "EXTENDED_PENDING_RESOURCE_GATE",
  "optimizer_trajectories_executed_pilot": 5,
  "optimizer_trajectories_requested_extended": 460800,
  "release_impact": "fail closed on novelty, human review, and pending extended optimizer grid",
  "run_dirs": {
    "B": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_b_193c8f7077f24001",
    "C": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_c_e196eda9fd80b2ad",
    "D": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_d_304660bf79700d9f",
    "E": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_e_0e05fcaf5c695ae3",
    "F": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_f_85238b2a21c12d86",
    "G": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_g_668704fd7d61be98",
    "H": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_h_0af9e6a0a9074e22",
    "I": "C:\\Documents\\metamaths\\seion-math-core\\artifacts\\runs_v3\\v3_i_4f9e3e2588d8b40f"
  },
  "scientific_instances": 15493,
  "source_commit": "b718f4e5178590d1f8b6a090fb696545eb3bfcd4",
  "wall_seconds": 20.619369499967434
}


## artifacts/research_v3/prior_art_matrix.csv

id,area,established_result,closest_known_construction,exact_overlap,genuine_difference,theorem_level_novelty,computational_novelty,limitation
PA_V3_COLORED_OPERADS,"Yau, Colored Operads",Typed operations and rooted-tree partial composition are standard colored-operad semantics.,,The v3 type grammar and ordered tree model.,Orthogonal projection defects and quantitative nodewise certificates are additional analytic data.,STANDARD_RESTRICTION_RESULT,NOT_ESTABLISHED,
PA_V3_ALGEBRAIC_OPERADS,"Loday and Vallette, Algebraic Operads",Treewise composition and polynomial identities for algebras over operads.,,Signed forests and insertion-tree syntax.,Quantitative normal leakage is not the monograph's central problem.,KNOWN_BOUND_NEW_SPECIALIZATION,NOT_ESTABLISHED,
PA_V3_APPROXIMATE_HOMOMORPHISMS,"Johnson, Approximately multiplicative maps between Banach algebras",Approximate multiplicativity can imply proximity to exact homomorphisms under Banach-algebra hypotheses.,,Quantitative stability language for algebraic structure.,V3 propagates nodewise normal projection defects on a fixed finite tree rather than correcting a map globally.,NOVELTY_NOT_ESTABLISHED,NOT_ESTABLISHED,
PA_V3_BACKWARD_ERROR,"Higham, Accuracy and Stability of Numerical Algorithms",Compositional forward/backward error analysis and order-sensitive arithmetic bounds are standard.,,Local error propagation and evaluation-order comparisons.,Exact multilinear projector residuals and typed tree topology.,KNOWN_BOUND_NEW_SPECIALIZATION,NOT_ESTABLISHED,
PA_V3_LAYERED_LIPSCHITZ,"Combettes and Pesquet, Lipschitz Certificates for Layered Network Structures",Architecture-sensitive composition can improve products of individual Lipschitz bounds.,,Dynamic propagation of local operator summaries.,"V3 uses multilinear branching, normal/projected blocks, and source residuals.",NOVELTY_NOT_ESTABLISHED,NOT_ESTABLISHED,
PA_V3_ABSTRACT_INTERPRETATION,"Gehr et al., AI2",Sound compositional overapproximation through computational graphs.,,Nodewise abstract summaries and recursively propagated enclosures.,No neural activation or robustness property; exact multilinear projector decomposition.,NOVELTY_NOT_ESTABLISHED,NOT_ESTABLISHED,
PA_V3_HIERARCHICAL_TENSORS,"Hackbusch and Kuehn, A New Scheme for the Tensor Representation",Hierarchical tensor formats organize approximation by dimension trees.,,Topology-dependent finite tree calculations.,V3 studies recursive projection of law outputs rather than rank truncation of one tensor.,NOVELTY_NOT_ESTABLISHED,NOT_ESTABLISHED,
PA_V3_TREE_ADAPTIVE_TENSORS,"Ballani and Grasedyck, Tree Adaptive Approximation in the Hierarchical Tensor Format",Tree ch

## artifacts/research_v3/release_gate_v3.json

{
  "automation_can_approve_release": false,
  "blockers": [
    {
      "evidence": "claims/theorem_registry_v3.yaml",
      "id": 2,
      "name": "every sharpness claim has a matching construction",
      "pass": false
    },
    {
      "evidence": "claims/prior_art_registry_v3.yaml",
      "id": 4,
      "name": "prior art establishes theorem-level novelty",
      "pass": false
    },
    {
      "evidence": "artifacts/research_v3/block_A_exact_atlas.parquet",
      "id": 5,
      "name": "all declared small-case global optima independently certified",
      "pass": false
    },
    {
      "evidence": "artifacts/research_v3/extended_progress_v3.json",
      "id": 8,
      "name": "all mandatory base and extended matrix blocks complete",
      "pass": false
    },
    {
      "evidence": "git status --porcelain",
      "id": 11,
      "name": "worktree clean for final rerun",
      "pass": false
    },
    {
      "evidence": "artifacts/reviews_v3/review_summary_v3.json",
      "id": 14,
      "name": "four reviewers are at least acceptable as preprint",
      "pass": false
    }
  ],
  "branch": "research/nodewise-tree-constants-v3",
  "failed": 6,
  "gates": [
    {
      "evidence": "claims/theorem_registry_v3.yaml",
      "id": 1,
      "name": "projected-root k-1 proved or refuted",
      "pass": true
    },
    {
      "evidence": "claims/theorem_registry_v3.yaml",
      "id": 2,
      "name": "every sharpness claim has a matching construction",
      "pass": false
    },
    {
      "evidence": "artifacts/index/optimality_gaps_v3.csv",
      "id": 3,
      "name": "near-optimal claims have certified declared gaps",
      "pass": true
    },
    {
      "evidence": "claims/prior_art_registry_v3.yaml",
      "id": 4,
      "name": "prior art establishes theorem-level novelty",
      "pass": false
    },
    {
      "evidence": "artifacts/research_v3/block_A_exact_atlas.parquet",
      "id": 5,
      "name": "all declared small-case global optima independently certified",
      "pass": false
    },
    {
      "evidence": "artifacts/research_v3/smoke_calibration.json",
      "id": 6,
      "name": "multiple optimizer families executed",
      "pass": true
    },
    {
      "evidence": "artifacts/index/tree_instances_v3.parquet",
      "id": 7,
      "name": "exact tree enumeration complete",
      "pass": true
    },
    {
      "evidence": "artifacts/research_v3/extended_progress_v3.json",
      "id": 8,
      "name": "all mandatory base and extended matrix blocks complete",
      "pass": false
    },
    {
      "evidence": "artifacts/index/failures_v3.csv",
      "id": 9,
      "name": "no unexplained theo

## artifacts/research_v3/release_gate_v3.md

# V3 strict release gate

- Result: **FAIL_CLOSED_NOVELTY**
- Passed gates: 9/15
- Failed gates: 6/15

## Gate matrix

| Gate | Result | Requirement |
|---:|:---:|---|
| 1 | PASS | projected-root k-1 proved or refuted |
| 2 | FAIL | every sharpness claim has a matching construction |
| 3 | PASS | near-optimal claims have certified declared gaps |
| 4 | FAIL | prior art establishes theorem-level novelty |
| 5 | FAIL | all declared small-case global optima independently certified |
| 6 | PASS | multiple optimizer families executed |
| 7 | PASS | exact tree enumeration complete |
| 8 | FAIL | all mandatory base and extended matrix blocks complete |
| 9 | PASS | no unexplained theorem-bound violation |
| 10 | PASS | run artifacts carry immutable commit and input hashes |
| 11 | FAIL | worktree clean for final rerun |
| 12 | PASS | CPU/GPU float64 parity passes |
| 13 | PASS | every figure is registered and hash-valid |
| 14 | FAIL | four reviewers are at least acceptable as preprint |
| 15 | PASS | latexmk and page-by-page visual inspection pass |

Automation cannot convert this result into human publication approval.


## artifacts/research_v3/run_budget.md

# V3 run budget

Generated: 2026-07-30T02:42:48.290863+00:00
Source commit: `a39de8047d3d33314adb485f762c2b74c7af73fb`

## Declared counts

| Block | Scientific instances |
|---|---:|
| A | 4,185 |
| B | 2,880 |
| C | 3,456 |
| D | 4,320 |
| E | 96 |
| F | 24 |
| G | 28 |
| H | 480 |
| I | 24 |
| J | 8,400 |

Full core (A--I): **15,493** instances.
Extended performance (J): **8,400** instances.
Exact enumerator: **81,445** ordered shapes.
Nested requested executions: **558,725**.

## Calibration

```json
{
  "cpu_evaluations_per_second": 1083.6977720257225,
  "cpu_rotation_tree_evaluations": 200,
  "cpu_seconds": 0.18455329997232184,
  "gpu_calibration": "4096x32 float64 tanh-matmul",
  "gpu_name": "NVIDIA RTX PRO 5000 Blackwell Generation Laptop GPU",
  "gpu_seconds": 0.001961899979505688,
  "gpu_steps": 50,
  "gpu_steps_per_second": 25485.499017436043
}
```

## Resource gate

Triggered: **True**.
A naive per-instance layout would create about **402,818 files** and **12.3 GiB** at 32 KiB/file.
The optimistic single-device optimizer lower estimate is **17.7 h**.

All scientific axes remain registered.  The full core evaluates every base mathematical instance with rigorous upper bounds and explicit lower constructions.  The complete seed/restart adversarial grid is retained, unmodified, as a resumable extended workload.  This scheduling resolution does not permit an optimality claim.

Per-run artifacts are packaged by block; every master-index row retains its own configuration, tree, mathematical-object, and input hashes.

