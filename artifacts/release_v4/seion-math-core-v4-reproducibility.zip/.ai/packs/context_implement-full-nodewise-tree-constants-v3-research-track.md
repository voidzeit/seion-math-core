# SEION context pack

- Task: Implement full nodewise tree constants v3 research track
- Compiled UTC: 2026-07-29T16:27:13.406810+00:00
- Pack status: derived; rebuildable; not durable memory

## Recent run snapshot

- `finite_ternary_v1` / `20260729T162010Z-a36e269b3c99`: COMPLETE; seed=42; path=`artifacts/runs/certification/finite_ternary_v1/20260729T162010Z-a36e269b3c99`
- `finite_ternary_v1` / `20260729T155404Z-a36e269b3c99`: COMPLETE; seed=42; path=`artifacts/runs/certification/finite_ternary_v1/20260729T155404Z-a36e269b3c99`
- `finite_ternary_v1` / `20260729T154535Z-a36e269b3c99`: COMPLETE; seed=42; path=`artifacts/runs/certification/finite_ternary_v1/20260729T154535Z-a36e269b3c99`
- `finite_ternary_v1` / `20260729T130251Z-a36e269b3c99`: COMPLETE; seed=42; path=`artifacts/runs/certification/finite_ternary_v1/20260729T130251Z-a36e269b3c99`
- `finite_ternary_v1` / `20260729T130005Z-a36e269b3c99`: COMPLETE; seed=42; path=`artifacts/runs/certification/finite_ternary_v1/20260729T130005Z-a36e269b3c99`

## `AGENTS.md`

```text
# SEION Math Core agent contract

This file is the entry point for every coding, research, and release session in
this repository. Read it before changing code, claims, artifacts, or paper
sources.

## Scope

SEION Math Core is the finite-dimensional mathematical and computational core
of the Kernel-Integrated Laws program. The other repositories that may have
inspired its workflow are external references, not dependencies and not edit
targets. All governance, memory, development, evidence, and publication work
for this task stays in this repository.

## Required reading order

1. `AGENTS.md`
2. `.ai/MEMORY_MANIFEST.yaml`
3. `.ai/CURRENT_STATE.md`, `.ai/TASKS.md`, and `.ai/KNOWN_BLOCKERS.md`
4. the relevant file in `governance/`
5. the relevant claim, theorem, experiment, and artifact registries
6. source code and tests

Use `seion-core governance context --task "..."` to compile a bounded context
pack before a large change.

## Source-of-truth policy

Truth is scoped by domain rather than inferred from prose:

- executable behavior: `src/` and executed tests;
- mathematical status: `claims/claims_registry.yaml`,
  `claims/theorem_registry.yaml`, proof files, and counterexample records;
- executed numerical facts: a run's `run_manifest.json`, `final_metrics.json`,
  `certificate.json`, and `artifact_hashes.json`;
- experiment design: `experiments/` and its registered matrix;
- durable project state and decisions: `.ai/`;
- generated paper figures/tables: derived outputs with provenance, never manual
  authorities.

When sources disagree, record the conflict in `.ai/KNOWN_BLOCKERS.md` or
`.ai/DECISIONS.md`; do not silently rewrite history.

## Epistemic rules

- A numerical residual is an observation, not a proof.
- A theorem with hypotheses is conditional on those hypotheses.
- A symbolic or exhaustive finite check does not establish a continuum or
  universal statement.
- `declared`, `observed`, `verified`, and `approved` are governance authority
  levels; they do not replace the mathematical claim statuses.
- AI-generated suggestions remain advisory until a deterministic gate or human
  review accepts them. The agent cannot approve an official theorem, compliance
  result, or release by itself.
- Preserve failed runs and negative controls. Do not delete evidence or turn a
  historical pass into a current pass without a new executed command.

## Development lifecycle

Use the stages in `governance/DEVELOPMENT_LIFECYCLE.yaml`:

`intake -> context -> plan -> change -> verify -> evidence -> postflight -> release`

At postflight, record the command, environment, branch, commit, date, result,
changed files, and limitations. Run:

```powershell
python -m seion_core.cli.main governance audit --json
python -m seion_core.cli.main governance dedupe-runs
```

before claiming reproducibility or release readiness.

## Research/software split

The research paper and reproducibility/software companion have separate claim
budgets. The mathematical paper may cite the software, but repository
architecture and run orchestration are not mathematical novelty. See
`governance/RESEARCH_SOFTWARE_SPLIT.yaml`.

## Safe change rules

- Preserve unrelated dirty worktree changes.
- Prefer additive, reviewable edits and deterministic generators.
- Never use destructive Git history rewrites.
- Do not add credentials, secrets, or external-repository mutations.
- Update registries and provenance when adding a claim, theorem, experiment,
  figure, or table.
- Run the smallest relevant tests first, then the declared quality gates.

```

## `.ai/CURRENT_STATE.md`

```text
# Current state

## Observation

- Observed on **2026-07-29** from branch `master` at commit
  `247de089a5fea826fa87f9b9e791c20a5a6fd1b6`.
- The worktree was already dirty before the governance bootstrap. Existing
  generated artifacts, figures, indexes, and `.obsidian/` content are retained
  as user-owned state; this bootstrap must not be attributed to those changes.
- The repository contains typed finite-dimensional algebra modules, claim and
  theorem registries, canonical experiment configurations, run artifacts,
  deterministic generators, and a compiled-paper workflow.

## Scientific status

- The legacy `paper/main.tex` remains a broad finite-dimensional release note;
  its registered formal results are the curvature/associator expansion and
  finite cohomology descent under explicit hypotheses.
- A separate working-paper source now exists at
  `papers/foundations/main.tex`. It states and proves, within the declared
  finite-dimensional hypotheses, exact invariant reduction, a tree-level
  approximate-closure bound, associator stability, and spectral snapping with
  a no-gap counterexample. It is not yet an independently reviewed or
  release-approved mathematical contribution.
- Projector recovery, convergence, precision, and CP results are finite
  numerical observations unless their registry says otherwise.

## Operational status

- The new governance contract is local to this repository.
- Run deduplication and claim/evidence audits are required before release
  claims.
- The paper/software split has independent sources at
  `papers/foundations/main.tex` and `papers/software/main.tex`; both compile
  and render through `scripts/build_companions.ps1`.
- The latest structural audit is yellow and passes only in non-strict mode:
  all required files and run contracts are present, but duplicate historical
  runs and the paper quality flag keep release fail-closed.

## Latest postflight observation

- Observed on **2026-07-29T15:49:15Z** from branch
  `research/structure-preserving-reduction-v2` at commit
  `247de089a5fea826fa87f9b9e791c20a5a6fd1b6`; the worktree remains dirty.
- The v2 track now has separate foundations and software sources, theorem and
  counterexample registries, a conservative prior-art matrix, 180 registered
  runs, 100 unique scientific instances, nine vector figure pairs, and
  fail-closed audit output under `artifacts/research_audit/`.
- The v2 numerical gates pass for the declared finite regime: 39 tests pass,
  all 180 rows complete, all 60 closure-bound rows respect the bound, and the
  five CPU/GPU parity rows have maximum absolute error below `1.5e-14`.
- The v2 research gate remains blocked because theorem-level novelty has not
  been established and verified author email/ORCID metadata are absent. The
  foundations PDFs are drafts/not for submission; the software companion is
  the reproducibility deliverable.
- Other repositories remain inspiration-only and were not edited.

## Final postflight observation

- Observed on **2026-07-29T15:54:40Z** from the same v2 branch and commit;
  the worktree remains dirty by design.
- The one-command rebuild completed all generation, compilation, rendering,
  and audit checks. Its exit code is `2` solely because the strict research
  gate correctly remains fail-closed on the two scientific/editorial
  blockers.
- Final regression status is 39 tests passed, 180 complete v2 runs, 100
  unique scientific instances, 60 bound checks passed, and five CPU/GPU
  parity rows with maximum absolute error `1.4210854715202004e-14`.

## Update rule

This file is updated only by a postflight that records the command, environment,
commit, result, and limitation. Do not replace an old observation with an
unqualified present-tense statement.

```

## `.ai/TASKS.md`

```text
# Tasks

## Active

- [x] Connect the exact invariant-subspace reduction theorem draft to the
  v2 theorem/claim registries and reference/accelerated implementations.
- [x] Prove and test the tree-level approximate-closure recurrence for the
  declared projected-evaluation convention.
- [x] Execute five-seed projector, CP, spectral-gap, closure, and CPU/GPU
  parity experiments with registered summaries and tightness ratios.
- [x] Replace the v2 paper figures with registered multi-seed data,
  uncertainty, vector output, and centralized styling.
- [ ] Establish a genuinely new theorem-level contribution beyond the
  standard restriction and perturbation consequences, or keep the work as a
  technical/preprint draft.
- [ ] Obtain verified author email and ORCID metadata.
- [ ] Obtain independent human mathematical and numerical review before any
  submission claim.

## Operational

- [x] Run `seion-core governance audit --strict`; it correctly fails closed
  while scientific warnings remain.
- [x] Review and generate the deduplicated run index before using historical
  aggregates.
- [ ] Fill author contact and ORCID metadata only from an explicit source.

## Completed in this bootstrap

- [x] Establish local governance, memory, lifecycle, authority, and research/
  software split contracts.
- [x] Draft and compile independent mathematical and reproducibility
  manuscripts with vector-capable PDF sources and render checks.
- [x] Expand the prior-art matrix and bibliography with conservative primary
  and official sources.
- [x] Pass the full Python test suite: 39 tests.
- [x] Generate and audit separate v2 foundations/software PDFs, nine vector
  figure pairs, claim/evidence matrices, and adversarial review records.

```

## `.ai/KNOWN_BLOCKERS.md`

```text
# Known blockers

| ID | Blocker | Impact | Evidence | Resolution condition |
|---|---|---|---|---|
| B-0001 | The current paper's theorem program is too modest for a competitive research paper. | Research-paper release is blocked. | `paper/quality/paper_quality_report.*`, `claims/theorem_registry.yaml` | A nontrivial central theorem is proved with complete assumptions and counterexamples. |
| B-0002 | Historical run indexes contain repeated executions of identical configurations. | Naive aggregate statistics are invalid. | `artifacts/index/run_index.csv` | Use `seion-core governance dedupe-runs` and report unique-instance counts. |
| B-0003 | Several figures are diagnostic or illustrative rather than dense multi-seed experiments. | Quantitative visual claims are limited. | `paper/generated/figures/`, `claims/claims_registry.yaml` | Rebuild figures from registered multi-seed runs with uncertainty and provenance. |
| B-0004 | Author ORCID and contact metadata are not available in the repository. | Submission metadata is incomplete. | `paper/metadata.tex`, `CITATION.cff` | Add verified author metadata explicitly. |

These blockers are not silently downgraded by successful software tests.

```

## `.ai/DECISIONS.md`

```text
# Decisions

## D-0001 — Keep governance local to SEION Math Core

- **Date:** 2026-07-29
- **Decision:** The other repositories supplied workflow patterns only. No
  governance or integration files are written to them.
- **Reason:** SEION must remain self-contained and reproducible.
- **Evidence:** user scope clarification; `AGENTS.md`.
- **Status:** accepted

## D-0002 — Separate mathematical and software evidence

- **Date:** 2026-07-29
- **Decision:** Mathematical claims live in claims/theorem registries and proof
  files; software/reproducibility claims live in run manifests, schemas, and
  release records.
- **Reason:** A polished runner or artifact ledger cannot substitute for a
  mathematical theorem.
- **Evidence:** `governance/RESEARCH_SOFTWARE_SPLIT.yaml`.
- **Status:** accepted

## D-0003 — Preserve historical runs and deduplicate derived views

- **Date:** 2026-07-29
- **Decision:** Existing run indexes are not rewritten in place. A deterministic
  deduplicated index and audit report are generated alongside them.
- **Reason:** Repeated executions are useful operational history but are not
  independent scientific instances.
- **Evidence:** `artifacts/index/run_index.csv`; `governance/MEMORY_CONTRACT.yaml`.
- **Status:** accepted

## D-0004 — Keep v2 fail-closed until novelty and metadata gates pass

- **Date:** 2026-07-29
- **Decision:** The v2 foundations manuscript is delivered as a rigorously
  scoped draft/not-for-submission artifact, while the software companion is
  the reproducibility output. The strict research audit must remain false
  until a genuinely new theorem and verified author metadata exist.
- **Reason:** Exact invariant restriction, operadic identity inheritance, and
  the spectral gap estimate are standard consequences; a complete numerical
  matrix cannot substitute for theorem-level novelty.
- **Evidence:** `claims/theorem_registry_v2.yaml`,
  `claims/claim_evidence_matrix_v2.csv`,
  `papers/foundations_v2/RESEARCH_BLOCKED.md`,
  `artifacts/research_audit/v2_state.json`.
- **Status:** accepted

```

## `.ai/RISK_REGISTER.md`

```text
# Risk register

| ID | Risk | Likelihood | Impact | Control |
|---|---|---:|---:|---|
| R-0001 | Numerical evidence is described as proof. | medium | high | claim-language lint; authority/epistemic separation. |
| R-0002 | Duplicate runs inflate apparent sample size. | high | high | deterministic run deduplication and unique-seed reporting. |
| R-0003 | Generated paper output is edited manually and loses provenance. | medium | high | regenerate tables/figures from artifacts; hash release outputs. |
| R-0004 | Existing dirty artifacts are attributed to a later session. | medium | medium | record baseline commit/worktree state in `.ai/CURRENT_STATE.md`. |
| R-0005 | External applications expand the mathematical scope without proof. | medium | high | scope contract and research/software split. |

```

## `.ai/WORKSTREAMS.md`

```text
# Workstreams

## Mathematical research

Owns definitions, theorem statements, proofs, assumptions, counterexamples,
prior-art positioning, and mathematically meaningful experiments. Canonical
surfaces: `src/seion_core/`, `docs/theorems/`, `claims/`, `paper/`.

## Software and reproducibility

Owns schemas, runners, hardware/environment manifests, artifact hashes,
deduplicated run views, generated figures/tables, build scripts, and release
bundles. Canonical surfaces: `schemas/`, `experiments/`, `scripts/`,
`artifacts/`.

## Shared gate

The software workstream can show that a declared computation ran and is
traceable. Only the mathematical workstream can change a theorem's status, and
only an explicit review can approve a release.

```

## `governance/PROJECT_MANIFEST.yaml`

```text
version: 1
project_id: seion-math-core
name: SEION Math Core
purpose: >-
  Canonical finite-dimensional mathematical and computational verification
  environment for Kernel-Integrated N-Ary Laws.
scope:
  included:
    - typed finite-dimensional n-ary laws
    - ternary composition conventions and associators
    - algebraic/operator curvature definitions with assumptions
    - projectors, closure leakage, CP representations, kernels, and finite cohomology
    - falsification, numerical certificates, and reproducible paper artifacts
  excluded:
    - KGE
    - LLM compression
    - BIM
    - cosmology
    - trading
    - universal physical or continuum claims without separate proof
tracks:
  mathematical_research:
    canonical_source: paper/main.tex
    registries:
      - claims/claims_registry.yaml
      - claims/theorem_registry.yaml
      - claims/novelty_registry.yaml
    allowed_outputs: [definition, theorem, proof, counterexample, conjecture, open_problem]
  software_reproducibility:
    canonical_source: scripts/
    registries:
      - experiments/matrices/canonical_run_matrix.yaml
      - schemas/run_manifest.schema.json
      - schemas/certificate.schema.json
    allowed_outputs: [run, certificate, figure, table, manifest, release_bundle]
source_of_truth:
  behavior: [src/, tests/]
  mathematical_status: [claims/, docs/theorems/, docs/counterexamples/]
  experiment_design: [experiments/, schemas/]
  executed_evidence: [artifacts/runs/, artifacts/index/]
  durable_memory: [.ai/]
  generated_publication: [paper/generated/, paper/build/]
commands:
  install: python -m pip install -e .
  tests: python -m pytest -q
  audit: python -m seion_core.cli.main governance audit --strict
  context: python -m seion_core.cli.main governance context --task "describe task"
  dedupe: python -m seion_core.cli.main governance dedupe-runs
  fast: .\scripts\run_fast.ps1
  full: .\scripts\run_full_blackwell.ps1
  paper: .\scripts\build_paper.ps1
  release: .\scripts\release_bundle.ps1
release_policy:
  requires_human_review: true
  requires_clean_or_explained_worktree: true
  requires_complete_provenance: true
  requires_no_unresolved_critical_gate: true
  requires_scientific_blockers_report: true

```

## `governance/AUTHORITY_LADDER.yaml`

```text
version: 1
description: >-
  Governance authority records how strongly an operational statement is
  supported. It is separate from mathematical epistemic status.
levels:
  declared:
    rank: 0
    meaning: registered in a plan, config, claim, or paper draft
    permits: [planning, context compilation]
    does_not_permit: [claiming execution, claiming proof, release approval]
  observed:
    rank: 1
    meaning: produced by an executed command with captured output and environment
    permits: [reporting a scoped observation]
    requires: [command, timestamp, environment, artifact path]
    does_not_permit: [universal inference, theorem status change]
  verified:
    rank: 2
    meaning: passed a deterministic, symbolic, exact, or schema gate
    permits: [verification claim within declared scope]
    requires: [observed evidence, reproducible gate, limitations]
    does_not_permit: [continuum or universal inference without proof]
  approved:
    rank: 3
    meaning: explicitly accepted for a named release or decision
    permits: [release or decision within scope]
    requires: [verified evidence, named reviewer or deterministic policy, decision record]
    does_not_permit: [upgrading mathematical epistemic status]
separate_epistemic_statuses:
  - DEFINITION
  - PROVED
  - PROVED_UNDER_ASSUMPTIONS
  - COMPUTER_ALGEBRA_VERIFIED
  - FINITE_DIMENSION_EXHAUSTIVE
  - NUMERICALLY_TESTED
  - EMPIRICAL
  - HEURISTIC
  - CONJECTURE
  - OPEN_PROBLEM
  - REFUTED
  - SUPERSEDED
rules:
  - AI output is advisory until accepted by a named gate.
  - A green audit is not release approval.
  - A numerical certificate cannot upgrade a conjecture to a theorem.

```

## `governance/DEVELOPMENT_LIFECYCLE.yaml`

```text
version: 1
stages:
  intake:
    purpose: define the requested outcome and scope
    required: [task_id, affected_workstream, risk_level, expected_outputs]
    gate: no external repository mutation; no scope expansion by inference
  context:
    purpose: recover durable state and relevant evidence
    required: [AGENTS.md, .ai/CURRENT_STATE.md, .ai/TASKS.md, relevant registries]
    command: python -m seion_core.cli.main governance context --task "..."
    gate: unresolved blockers are visible
  plan:
    purpose: map each intended change to a source, test, and evidence output
    required: [plan, claim_impact, test_plan, rollback_or_preservation_note]
  change:
    purpose: implement additive changes in source, schemas, docs, or generators
    required: [changed_files, no_secrets, preserved_user_changes]
    gate: no generated artifact is hand-edited as a source of truth
  verify:
    purpose: execute relevant tests and mathematical gates
    required: [command, exit_code, environment, branch, commit, limitations]
    gate: stale historical output cannot stand in for current execution
  evidence:
    purpose: connect claims to run artifacts, proofs, figures, and tables
    required: [run_id_or_proof_location, artifact_hashes, provenance]
    gate: repeated runs are deduplicated before aggregate interpretation
  postflight:
    purpose: update durable memory and handoff state
    required: [summary, outcome, validation, changed_files, limitations]
    command: python -m seion_core.cli.main governance postflight --task "..." --summary "..."
  release:
    purpose: create a reproducible release candidate
    required: [strict_governance_audit, tests, paper_build, render_report, blocker_report, human_approval]
    gate: automation may recommend; it cannot approve by itself
state_transitions:
  allowed: [declared, in_progress, verified, blocked, superseded, released]
  forbidden:
    - failed_to_complete_without_evidence
    - historical_pass_to_current_pass_without_execution
    - numerical_observation_to_proved

```

## `governance/RESEARCH_SOFTWARE_SPLIT.yaml`

```text
version: 1
principle: >-
  Mathematical novelty and software reproducibility are coupled by evidence
  links but are not the same contribution.
mathematical_research:
  proposed_title: "Structure-Preserving Reduction of Finite-Dimensional N-Ary Laws: Exact Functoriality, Associator Stability, and Projection Error Bounds"
  canonical_source: papers/foundations/main.tex
  legacy_release_note: paper/main.tex
  claims_allowed: [definition, theorem, proof, conditional_theorem, counterexample, conjecture, open_problem]
  central_program:
    - exact invariant-subspace reduction
    - preservation of operadic partial compositions and polynomial identities
    - explicit approximate-closure bounds
    - spectral snapping stability under a gap
    - counterexamples without invariance or gap
  cannot_claim:
    - repository architecture is mathematical novelty
    - numerical agreement is a proof
    - finite results imply continuum or universal results
software_reproducibility:
  proposed_title: "SEION Math Core: A Reproducible Verification Suite for Finite-Dimensional N-Ary Algebra"
  canonical_source: [papers/software/main.tex, scripts/, schemas/, artifacts/, docs/reproducibility/]
  claims_allowed: [implementation, schema_conformance, executed_run, artifact_traceability, reproducible_build]
  required_outputs:
    - run manifest and environment
    - deduplicated run index
    - claim/evidence matrix
    - figure/table provenance
    - build and render reports
    - unresolved blocker list
  cannot_claim:
    - software pass establishes theorem truth
    - reproducibility establishes novelty
    - a release bundle removes scientific limitations
link_contract:
  every_math_claim_has: [claim_id, epistemic_status, assumptions, proof_or_experiment, limitations]
  every_numeric_claim_has: [run_id, seed_or_exactness, precision, metric_definition, uncertainty_or_scope]
  every_paper_figure_has: [source_artifact, generator, run_identifiers, caption_scope]

```

## `claims/claims_registry.yaml`

```text
claims:
  - id: DEF_NARY_LAW_V1
    title: Typed finite-dimensional n-ary law
    status: definition
    statement: "A structural tensor K of shape (d_out,d_1,...,d_n) defines an n-linear map with explicit input and output dimensions."
    assumptions: [finite-dimensional coordinate spaces, numeric field]
    evidence: [src/seion_core/algebra/nary_law.py, tests/unit/test_nary_law.py]
  - id: DEF_ASSOCIATOR_CONVENTIONS_V1
    title: Distinct ternary composition conventions
    status: definition
    statement: "The five-input, anchored binary, and operadic partial-composition objects are represented by separate functions and recorded conventions."
    assumptions: [ternary arity for specialized formulas]
    evidence: [src/seion_core/algebra/ternary_law.py, tests/unit/test_associators.py]
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    title: Standard left-action curvature expansion
    status: proved
    statement: "For any bilinear product, [L_x,L_y]-L_[x,y] applied to z equals A(y,x,z)-A(x,y,z), with [x,y]=x circ y-y circ x."
    assumptions: [finite-dimensional bilinear product, stated commutator convention]
    proof: docs/theorems/curvature_associator.md
    symbolic_checks: [artifacts/symbolic/curvature_identity.json]
    counterexamples: [docs/counterexamples/curvature_without_symmetry.md]
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    title: Commuting finite operator descends to cohomology
    status: proved_under_assumptions
    statement: "If a finite operator commutes with the differential, it preserves cycles and boundaries and therefore induces a map on the quotient cohomology space."
    assumptions: [d squared equals zero, same-degree linear operator, exact commutation]
    proof: docs/theorems/cohomology_descent.md
    numerical_checks: [tests/unit/test_cohomology.py]
  - id: NUM_KNOWN_INVARIANT_CLOSURE_V1
    title: Known block subspace closure
    status: numerically_verified
    statement: "For the declared block-supported example, the coordinate projector has zero closure leakage up to floating-point evaluation."
    assumptions: [example definition, finite samples, float64]
    evidence: [experiments/configs/finite_ternary_v1.yaml]
  - id: EMP_PROJECTOR_RECOVERY_V1
    title: Empirical closure-minimizing recovery
    status: empirical
    statement: "A small stochastic Stiefel search can reduce sampled closure leakage on some declared examples; no general recovery or superiority claim is made."
    assumptions: [seed, sample distribution, optimizer steps]
    evidence: [src/seion_core/variational/optimizers.py]
  - id: CONJ_CONTINUUM_LIMIT_V1
    title: Uniform continuum limit for kernel-integrated laws
    status: open
    statement: "A sequence of finite laws may converge in a specified topology under uniform estimates; this repository does not prove a general theorem."
    assumptions: [resolution sequence, topology, uniform bounds, compactness or convergence argument]
    evidence: [docs/open_problems/index.md]
  - id: REFUTED_SNAPPING_NO_GAP_V1
    title: Continuity of spectral snapping without a gap
    status: refuted
    statement: "Threshold snapping is not continuous when eigenvalues may cross the threshold."
    assumptions: [no uniform spectral gap]
    evidence: [src/seion_core/projectors/snapping.py, tests/numerical/test_snapping.py]


```

## `claims/theorem_registry.yaml`

```text
theorems:
  - id: THM_STANDARD_CURVATURE_ASSOCIATOR_DIFFERENCE_V1
    statement: "R_standard(x,y)z = A(y,x,z)-A(x,y,z)."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [finite-dimensional bilinear product, stated bracket]
    proof_location: docs/theorems/curvature_associator.md
    symbolic_verification: artifacts/symbolic/curvature_identity.json
    epistemic_status: PROVED
  - id: THM_COHOMOLOGY_DESCENT_FINITE_V1
    statement: "T d = d T implies a well-defined action on finite cohomology."
    dependencies: [DEF_NARY_LAW_V1]
    hypotheses: [d^2=0, degree-preserving T]
    proof_location: docs/theorems/cohomology_descent.md
    symbolic_verification: null
    epistemic_status: PROVED_UNDER_ASSUMPTIONS


```

## `experiments/matrices/canonical_run_matrix.yaml`

```text
version: "0.1"
status: registered_finite_execution_with_extended_rows_explicit
runs:
  - id: ALG_DENSE_FLOAT64
    claim: dense n-ary contraction preserves multilinearity
    implementation: seion_core.algebra.nary_law.NaryLaw
    example: random_dense
    dimension: 3
    arity: 3
    field: real
    representation: dense
    rank: null
    symmetry: unconstrained
    associator_convention: five_input
    projector_rank: null
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 32
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: multilinearity residual below tolerance
    failure_interpretation: implementation or numerical failure
    paper_target: representation_table
  - id: ALG_CP_RANK_ONE
    claim: CP-to-dense reconstruction is exact for rank-one factors
    implementation: seion_core.algebra.cp_law.CPLaw
    example: rank_one_cp
    dimension: 3
    arity: 3
    field: real
    representation: CP
    rank: 1
    symmetry: unconstrained
    associator_convention: five_input
    projector_rank: null
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 16
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: relative reconstruction error below tolerance
    failure_interpretation: CP contraction mismatch
    paper_target: cp_rank_sweep
  - id: ASSOC_FIVE_INPUT
    claim: five-input associator is a distinct typed composition convention
    implementation: seion_core.algebra.associators.sample_associator_defect
    example: associative_algebra
    dimension: 3
    arity: 3
    field: real
    representation: dense
    rank: null
    symmetry: full
    associator_convention: five_input
    projector_rank: null
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 64
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: zero residual for coordinatewise associative law
    failure_interpretation: associator convention or contraction error
    paper_target: associator_convention_table
  - id: CURVATURE_STANDARD_IDENTITY
    claim: standard operator curvature equals an associator difference
    implementation: seion_core.geometry.induced_curvature.standard_curvature_residual
    example: random_dense
    dimension: 3
    arity: 2
    field: real
    representation: dense
    rank: null
    symmetry: unconstrained
    associator_convention: anchored_binary
    projector_rank: null
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 32
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: exact finite-dimensional residual identity
    failure_interpretation: algebraic expansion mismatch
    paper_target: theorem_dependency_matrix
  - id: PROJECTOR_VERTICAL_SLICE
    claim: known invariant subspace has zero finite closure leakage
    implementation: seion_core.projectors.closure.closure_leakage
    example: known_invariant_subspace
    dimension: 4
    arity: 3
    field: real
    representation: dense
    rank: 2
    symmetry: unconstrained
    associator_convention: five_input
    projector_rank: 2
    precision: float64
    backend: auto
    device: auto
    seed: 42
    samples: 96
    optimizer: closure_minimizing_empirical
    maximum_steps: 30
    tolerance: 1.0e-10
    expected_result: known baseline passes; learned result is empirical
    failure_interpretation: failure is retained as evidence against recovery on this seed
    paper_target: closure_leakage_by_method
  - id: SNAP_GAP
    claim: spectral snapping is stable away from threshold gap
    implementation: seion_core.projectors.snapping.spectral_snap
    example: random_dense
    dimension: 4
    arity: 3
    field: real
    representation: matrix
    rank: 2
    symmetry: none
    associator_convention: none
    projector_rank: 2
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 0
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: rank locally stable with positive gap
    failure_interpretation: no-gap counterexample is expected
    paper_target: spectral_snapping_table
  - id: COHOMOLOGY_COMPATIBLE
    claim: a finite operator commuting with d descends to cohomology
    implementation: seion_core.cohomology.compatibility.descends_to_cohomology
    example: finite_chain_complex
    dimension: 3
    arity: 1
    field: real
    representation: matrix
    rank: null
    symmetry: none
    associator_convention: none
    projector_rank: null
    precision: float64
    backend: numpy
    device: cpu
    seed: 42
    samples: 0
    optimizer: none
    maximum_steps: 0
    tolerance: 1.0e-10
    expected_result: compatible operator passes; incompatible control fails
    failure_interpretation: finite commutator defect
    paper_target: cohomology_compatibility_table


```
