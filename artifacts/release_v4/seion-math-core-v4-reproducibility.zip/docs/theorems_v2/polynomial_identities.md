# Inheritance of operadic polynomial identities

Let \(F=\sum_{a=1}^m c_a T_a\) be a multilinear polynomial in one or more
operations, where each \(T_a\) is a finite ordered operadic tree and the
coefficients \(c_a\) belong to the base field. Under the exact invariant
reduction hypotheses of exact_reduction.md, tree induction gives

\[
QF_{\bar\mu}(z_1,\ldots,z_s)
 =F_\mu(Qz_1,\ldots,Qz_s). \tag{4}
\]

Consequently, if \(F_\mu=0\) on \(V\), then \(F_{\bar\mu}=0\) on \(W\).
This applies to associativity/associator identities, the Filippov
fundamental identity when its bracket is represented by the chosen operation,
generalized Jacobi identities, and any other identity whose operations and
composition tree have been explicitly declared.

The assertion is a formal consequence of the exact reduction theorem. It does
not assert that every identity in the literature has the same convention or
the same symmetry type; the identity must first be encoded with its arity,
slot order, signs, and coefficient field.

ESTABLISHED_KNOWN_RESULT; no independent novelty claim is made.
