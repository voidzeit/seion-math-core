# Reference-practice review

This audit was executed read-only on the five user-designated reference repositories. No files, formatting, commits, or generated outputs were written there.

Audit timestamp: `2026-07-30T02:27:46.097043+00:00`.

## Canonical decision

SEION adopts only practices that improve mathematical provenance, deterministic context recovery, reviewability, or release safety. It remains a Python modular monolith with file-backed evidence; product databases, cloud services, frontend stacks, and mobile platform scaffolds are rejected.

## Adopted or narrowly adapted


## Rejected or out of scope

- **PostgreSQL dashboard truth** from `ema-ai`: Product dashboard persistence is not needed for finite research evidence; JSONL and Parquet artifacts are canonical. Replacement: no database dependency.
- **Docker/Kubernetes microservices** from `aec-agentic`: Distributed deployment would add operational surface without improving theorem or artifact authority. Replacement: modular monolith.
- **frontend application shell** from `bluebim-web`: SEION only needs a local read-only graph viewer, not a product UI or authenticated server. Replacement: static HTML/JS viewer.
- **Flutter platform directories** from `pixelcity-smoke-test`: Mobile/desktop platform code is unrelated to finite-dimensional mathematics. Replacement: Python/LaTeX/Actions.
- **embedding/vector retrieval as authority** from `ai-memory-orchestrator`: Semantic retrieval can assist context but cannot supersede exact registries or proofs. Replacement: deterministic graph and path selection.

## Evidence files

- `artifacts/reference_audit/reference_repo_inventory.json`
- `artifacts/reference_audit/practice_catalog.csv`
- `artifacts/reference_audit/adaptation_matrix.csv`
- `artifacts/reference_audit/rejected_practices.csv`

The five reference repositories remain inspiration-only and are not dependencies.
